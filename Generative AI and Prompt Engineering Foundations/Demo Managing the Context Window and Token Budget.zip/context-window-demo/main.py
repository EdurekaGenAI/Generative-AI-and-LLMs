import os

from dotenv import load_dotenv
from groq import Groq

# ---------------------------------------------------------
# Load Environment Variables
# ---------------------------------------------------------

load_dotenv()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

MODEL = "llama-3.3-70b-versatile"

# ---------------------------------------------------------
# Large Context
# ---------------------------------------------------------

large_context = """
Artificial Intelligence (AI) enables machines to perform tasks that normally require
human intelligence, such as reasoning, learning, and problem solving.

Machine Learning is a branch of AI where systems learn patterns from data.

Deep Learning uses neural networks with multiple layers to solve complex tasks.

Natural Language Processing (NLP) focuses on enabling computers to understand
and generate human language.

Computer Vision allows machines to analyse and interpret images and videos.

Generative AI is capable of producing text, images, code, audio, and other forms
of content.

Large Language Models (LLMs) are trained on vast amounts of text to understand
patterns in language and generate meaningful responses.

Prompt engineering is the practice of designing prompts that help LLMs produce
accurate and useful outputs.

Every prompt submitted to an LLM is converted into tokens. Tokens may represent
words, parts of words, punctuation, or special characters.

Each model has a maximum context window that limits how many tokens it can
process in a single request.

The context window includes:
- System instructions
- User prompt
- Additional context
- Conversation history
- Model response

If the total number of tokens exceeds the model's context window, older
information may be removed or the request may fail depending on the model.

Providing unnecessary information increases token usage, slows processing,
and may distract the model from the most relevant information.

Good prompt engineering involves supplying only the context required for
the current task.

Keeping prompts concise improves efficiency, reduces cost, and often
produces more focused responses.
"""

# ---------------------------------------------------------
# Optimised Context
# ---------------------------------------------------------

optimised_context = """
A context window is the maximum amount of information an LLM can process
in one request.

Every input and output consumes tokens.

Providing only relevant information helps reduce token usage,
improves efficiency, lowers cost, and keeps the model focused.
"""

# ---------------------------------------------------------
# User Question
# ---------------------------------------------------------

question = (
    "Explain what a context window is and why "
    "managing the token budget is important."
)

# ---------------------------------------------------------
# Function
# ---------------------------------------------------------

def ask_llm(context, title):
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)

    prompt = f"""
Context:
{context}

Question:
{question}
"""

    print(f"\nApproximate Input Characters : {len(prompt)}")
    print(f"Approximate Words            : {len(prompt.split())}")

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are an AI tutor. Answer clearly and concisely "
                    "using the provided context."
                ),
            },
            {
                "role": "user",
                "content": prompt,
            },
        ],
        temperature=0.3,
        max_tokens=250,
    )

    print("\nLLM Response\n")
    print(response.choices[0].message.content)


# ---------------------------------------------------------
# Run Demo
# ---------------------------------------------------------

print("\n")
print("=" * 70)
print("MANAGING THE CONTEXT WINDOW AND TOKEN BUDGET")
print("=" * 70)

ask_llm(
    large_context,
    "Example 1 : Large Context",
)

ask_llm(
    optimised_context,
    "Example 2 : Optimised Context",
)

print("\n" + "=" * 70)
print("Summary")
print("=" * 70)

print("""
Large Context
-------------
• More information is supplied to the model.
• Higher token consumption.
• More processing time.
• Some information may be unnecessary.

Optimised Context
-----------------
• Only relevant information is supplied.
• Lower token usage.
• Faster processing.
• More focused responses.

Key Takeaway
------------
Managing the context window means providing only the information
needed for the current task. This reduces token usage, improves
efficiency, lowers API costs, and helps the model generate more
relevant responses.
""")