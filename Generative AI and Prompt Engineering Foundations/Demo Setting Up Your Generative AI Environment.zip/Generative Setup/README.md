# Setting Up Your Generative AI Environment
# Step 1: Install Visual Studio Code
Download and install the latest version of Visual Studio Code.
After installation, launch VS Code to verify it is working correctly.
---

# Step 2: Install Python
Download and install the latest stable version of Python.
During installation on Windows:

* Select Add Python to PATH
* Install pip
* Complete the installation

Verify the installation.

```bash
python --version
```

or

```bash
python3 --version
```
---

# Step 3: Verify pip
Check that the Python package manager is installed.

```bash
pip --version
```
---

# Step 4: Install Git
Download and install Git.
Verify the installation.

```bash
git --version
```
---

# Step 5: Create a Workspace
Create a folder to store your Generative AI projects.
Open this folder in Visual Studio Code.

---

# Step 6: Create a Virtual Environment

### Windows

```bash
python -m venv venv
```

Activate the environment.

```bash
venv\Scripts\activate
```

### macOS/Linux

```bash
python3 -m venv venv
```

Activate the environment.

```bash
source venv/bin/activate
```

When activated, your terminal should display the virtual environment name.
---

# Step 7: Upgrade pip
Upgrade pip to the latest version.

```bash
python -m pip install --upgrade pip
```

---

# Step 8: Create Project Files
Create the following project structure.

```text
GenAI-Workspace/
│
├── venv/
├── main.py
├── requirements.txt
├── .env
└── README.md
```

---

# Step 9: Add Required Dependencies
Create a `requirements.txt` file.
Install the dependencies.

```bash
pip install -r requirements.txt
```

---

# Step 10: Install Visual Studio Code Extensions
Install the following extensions from the VS Code Marketplace.

* Python
* Pylance
* Python Debugger
* Jupyter
* GitHub Copilot (Optional)
* Error Lens (Optional)
* Code Runner (Optional)

---

# Step 11: Verify the Environment
Run the following commands.

```bash
python --version
pip --version
git --version
```

Everything is configured correctly if:
* Python is installed successfully.
* pip is available.
* Git is installed.
* The virtual environment is active.
* Required packages are installed.
* Visual Studio Code detects the Python interpreter.
---