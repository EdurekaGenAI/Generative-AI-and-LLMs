# Measuring Semantic Similarity in Vector Space

## Overview

This project demonstrates how Large Language Model applications can measure the semantic similarity between sentences by converting text into vector embeddings. Instead of comparing words directly, embeddings capture the meaning of the text and allow us to compare sentences mathematically.

The demo uses the `sentence-transformers` library together with cosine similarity to identify how closely two sentences are related in meaning.

---

## Project Structure

```text
semantic-similarity-demo/
│
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

---

## Project Workflow

### Flowchart

```text
┌──────────────────────────┐
│        Start             │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│ Create Virtual           │
│ Environment               │
│ python -m venv venv      │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│ Activate Virtual         │
│ Environment               │
│ venv\\Scripts\\activate   │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│ Install Dependencies     │
│ pip install -r           │
│ requirements.txt         │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│ Run the Application      │
│ python main.py           │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│ Load Sentence            │
│ Transformer Model        │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│ Convert Sentences        │
│ into Vector Embeddings   │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│ Compute Cosine           │
│ Similarity               │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│ Display Similarity       │
│ Scores                    │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│           End            │
└──────────────────────────┘
```

