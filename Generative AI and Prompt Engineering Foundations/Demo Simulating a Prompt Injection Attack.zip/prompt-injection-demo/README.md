# Demo: Simulating a Prompt Injection Attack

## Overview

Prompt injection is one of the most important security challenges when building applications with Large Language Models (LLMs). It occurs when an attacker embeds malicious instructions within untrusted input, attempting to manipulate or override the model's intended behaviour.

In this project, you will simulate a prompt injection attack using the **Groq API** and the **Llama 3.3 70B Versatile** model. The demo compares two different prompting approaches:

- **Vulnerable Prompt** – Trusted instructions and untrusted content are combined without protection, allowing embedded instructions to potentially influence the model.
- **Secure Prompt** – Untrusted content is clearly separated from trusted instructions, reducing the risk of prompt injection and encouraging the model to treat the content purely as data.

By comparing the outputs of both approaches, you will gain a practical understanding of prompt injection attacks and the prompt engineering techniques used to mitigate them.

---

# Project Structure

```text
prompt-injection-demo/
│── main.py
│── requirements.txt
│── README.md
└── .gitignore
```

### File Description

- **main.py** – Implements the prompt injection simulation, sends prompts to the Groq API, and compares vulnerable and secure prompting strategies.
- **requirements.txt** – Contains the Python dependencies required for the project.
- **README.md** – Provides project documentation, setup instructions, and an explanation of the project workflow.
- **.gitignore** – Excludes unnecessary files such as virtual environments, cache files, and environment variables from version control.

---

# Project Workflow

```text
                         Start
                           │
                           ▼
             Load Environment Variables
                           │
                           ▼
              Initialise Groq API Client
                           │
                           ▼
          Define Trusted User Instruction
                           │
                           ▼
      Create an Untrusted Document with
         an Embedded Prompt Injection
                           │
                           ▼
         ┌────────────────────────────┐
         │    Vulnerable Prompt Flow   │
         └────────────────────────────┘
                           │
                           ▼
     Combine Instruction and Document
           into a Single Prompt
                           │
                           ▼
          Send Request to Groq API
                           │
                           ▼
   Model May Follow the Embedded Attack
          Instead of the Original Task
                           │
                           ▼
         ┌────────────────────────────┐
         │      Secure Prompt Flow     │
         └────────────────────────────┘
                           │
                           ▼
     Separate Trusted Instructions from
         Untrusted Document Content
                           │
                           ▼
     Clearly Specify That the Document
          Must Be Treated as Data
                           │
                           ▼
          Send Request to Groq API
                           │
                           ▼
     Model Ignores Embedded Instructions
       and Produces the Correct Summary
                           │
                           ▼
           Compare Both Responses
                           │
                           ▼
      Understand Prompt Injection and
       Secure Prompt Engineering
```