## Diagnosing and Improving a Weak RAG Pipeline

### Overview

This project demonstrates how to identify problems in a **Retrieval-Augmented Generation (RAG) pipeline** and improve retrieval quality using better retrieval engineering techniques.

The project compares:

* A **weak RAG pipeline** with poor chunking
* An **improved RAG pipeline** with:

  * Recursive chunking
  * Chunk overlap
  * Metadata enrichment
  * Simple re-ranking

---

### Project Structure

```text
diagnosing-weak-rag-pipeline/
├── README.md
├── requirements.txt
├── .gitignore
├── main.py
├── weak_rag.py
├── improved_rag.py
└── knowledge_base.txt
```

### Example Workflow

```text
User Query
     |
     v
Weak Chunking
     |
     v
Vector Search
     |
     v
Irrelevant Retrieval
     |
     v
Diagnosis
     |
     v
Better Chunking + Overlap
     |
     v
Metadata + Re-ranking
     |
     v
Improved Retrieval Results
```