# Self-Consistency with Multiple Paths

## Overview

This project demonstrates the **Self-Consistency Prompting** technique using the **Groq API** and a Large Language Model (LLM).

Instead of relying on a single reasoning path, the same prompt is sent to the model multiple times using a higher temperature. Since each response may follow a different reasoning path, the final answers are collected and compared.

The most frequently occurring answer is selected through **majority voting**, making the final result more reliable for reasoning-based tasks.

---

## Project Structure

```text
Self-Consistency-Demo/
│
├── main.py
├── requirements.txt
├── README.md
├── .gitignore
└── .env
```

---

## Project Workflow

```
                User Question
                      │
                      ▼
          Send the Same Prompt
            Multiple Times
                      │
                      ▼
      Generate Multiple Reasoning Paths
                      │
                      ▼
      Extract Final Answer from Each Path
                      │
                      ▼
          Count the Final Answers
                      │
                      ▼
             Majority Voting
                      │
                      ▼
      Most Consistent Final Answer
```

---
