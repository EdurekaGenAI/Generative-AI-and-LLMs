import os
from pathlib import Path

import torch
from PIL import Image
from transformers import ViltForQuestionAnswering, ViltProcessor


# Optional: hide Windows symlink warning
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"


# -----------------------------------------------------------------------------
# Load processor and model once
# -----------------------------------------------------------------------------
print("Initialising Visual Question Answering model...")

processor = ViltProcessor.from_pretrained(
    "dandelin/vilt-b32-finetuned-vqa"
)

model = ViltForQuestionAnswering.from_pretrained(
    "dandelin/vilt-b32-finetuned-vqa"
)


def ask_question(image_path: str, question: str) -> str:
    """
    Answer a natural language question about an image.

    Args:
        image_path: Path to the input image.
        question: Question related to the image.

    Returns:
        Predicted answer.
    """

    image_file = Path(image_path)

    if not image_file.exists():
        raise FileNotFoundError(f"Image not found: {image_file}")

    image = Image.open(image_file).convert("RGB")

    # Prepare multimodal inputs
    encoding = processor(images=image, text=question, return_tensors="pt")

    # Run inference
    with torch.no_grad():
        outputs = model(**encoding)

    # Get predicted answer
    predicted_id = outputs.logits.argmax(-1).item()
    answer = model.config.id2label[predicted_id]

    return answer


def main():
    """Run the VQA demo."""

    image_path = "images/sample.png"

    questions = [
        "What is in the image?",
        "What colour is the animal?",
        "Is the animal indoors or outdoors?"
    ]

    print("\nVisual Question Answering Demo")
    print("-" * 45)
    print(f"Image : {image_path}")

    for question in questions:
        print(f"\nQuestion : {question}")

        try:
            answer = ask_question(image_path, question)
            print(f"Answer   : {answer}")

        except Exception as error:
            print(f"Error    : {error}")


if __name__ == "__main__":
    main()