PROMPTS = [

    "Explain what Large Language Models are in 50 words.",

    "Write Python code to reverse a string.",

    "Summarize the importance of Artificial Intelligence.",

    "Explain recursion using a simple example."

]