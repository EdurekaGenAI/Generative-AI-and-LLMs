## Demo: Parent-Document and Self-Querying Retrievers

### Overview

This project demonstrates two advanced retrieval strategies used in **Retrieval-Augmented Generation (RAG)** systems:

* **Parent-Document Retriever** – retrieves small semantic chunks while returning the larger parent document for better contextual understanding.
* **Self-Querying Retriever** – enables metadata-aware retrieval using natural language style filtering based on attributes such as **topic** and **difficulty level**.

The demo uses **LangChain**, **ChromaDB**, and **Hugging Face embeddings** to build an offline-friendly retrieval system without requiring any paid API.

---

## Project Structure

```text
parent-self-query-retrievers/
├── .gitignore
├── README.md
├── requirements.txt
├── main.py
└── documents/
    ├── ai_search.txt
    ├── llm_memory.txt
    └── vector_databases.txt
```

### File Description

| File               | Purpose                                                          |
| ------------------ | ---------------------------------------------------------------- |
| `main.py`          | Implements Parent-Document and Self-Querying retrieval logic     |
| `requirements.txt` | Contains all required Python dependencies                        |
| `.gitignore`       | Excludes virtual environments, cache files, and ChromaDB storage |
| `documents/*.txt`  | Sample knowledge-base documents used for indexing and retrieval  |

---

## Project Workflow

```text
                +-------------------+
                |   Text Documents  |
                +---------+---------+
                          |
                          v
               +--------------------+
               | Parent Splitter    |
               | Large Context Docs |
               +---------+----------+
                         |
                         v
               +--------------------+
               | Child Splitter     |
               | Small Search Chunks|
               +---------+----------+
                         |
                         v
               +--------------------+
               | Embedding Model    |
               | MiniLM Embeddings  |
               +---------+----------+
                         |
                         v
               +--------------------+
               | Chroma Vector DB   |
               +---------+----------+
                         |
          +--------------+--------------+
          |                             |
          v                             v
+----------------------+    +------------------------+
| Parent Retriever     |    | Metadata Self-Query   |
| Semantic Search      |    | Filtered Retrieval    |
+----------+-----------+    +-----------+------------+
           |                            |
           +-------------+--------------+
                         |
                         v
               +--------------------+
               | Retrieved Context  |
               +--------------------+
```