## Indexing with LlamaIndex

This project demonstrates how to **load documents, create an index, and query the indexed data using LlamaIndex**.

The workflow uses:

* **LlamaIndex** for document indexing and retrieval
* **Groq Llama 3.3 70B** as the language model
* A simple text document as the data source

This is a beginner-friendly example for understanding **Retrieval-Augmented Generation (RAG)** concepts with LlamaIndex.

---

## Project Structure

```text
indexing-with-llamaindex/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
├── main.py
└── data/
    └── sample.txt
```

---

## Project Workflow

```text
        Start
           │
           ▼
   Load .env File
           │
           ▼
 Configure Groq LLM
           │
           ▼
 Read Documents from data/
           │
           ▼
 Create VectorStoreIndex
           │
           ▼
 Build Query Engine
           │
           ▼
 Ask Natural Language Question
           │
           ▼
 Retrieve Indexed Content
           │
           ▼
 Generate Final Answer
           │
           ▼
          End
```

## Expected Output

```text
Loaded 1 document(s).
Index created successfully!

Question: What is indexing in LlamaIndex?
Answer:
Indexing in LlamaIndex is the process of transforming raw documents into a structured representation that enables efficient retrieval and question answering.
```
