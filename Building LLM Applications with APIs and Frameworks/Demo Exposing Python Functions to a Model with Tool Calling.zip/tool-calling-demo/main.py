import json
import os

from dotenv import load_dotenv
from groq import Groq

# --------------------------------------------------
# Load environment variables
# --------------------------------------------------
load_dotenv()

client = Groq(api_key=os.getenv("GROQ_API_KEY"))


# --------------------------------------------------
# Python functions exposed to the model
# --------------------------------------------------
def get_weather(city: str):
    """Return mock weather data for a city."""
    weather_data = {
        "Bangalore": {"temperature": "24°C", "condition": "Cloudy"},
        "Delhi": {"temperature": "33°C", "condition": "Sunny"},
        "Mumbai": {"temperature": "29°C", "condition": "Rainy"},
    }

    return weather_data.get(
        city,
        {"temperature": "Unknown", "condition": "No data available"},
    )


def calculate_sum(a: int, b: int):
    """Return the sum of two numbers."""
    return {"result": a + b}


# --------------------------------------------------
# Tool definitions for the model
# --------------------------------------------------
tools = [
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get the current weather for a city",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "City name",
                    }
                },
                "required": ["city"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calculate_sum",
            "description": "Add two numbers together",
            "parameters": {
                "type": "object",
                "properties": {
                    "a": {"type": "integer"},
                    "b": {"type": "integer"},
                },
                "required": ["a", "b"],
            },
        },
    },
]


# --------------------------------------------------
# User query
# --------------------------------------------------
user_message = input("Ask something: ")

messages = [
    {
        "role": "system",
        "content": "You are a helpful assistant that can use tools when needed.",
    },
    {"role": "user", "content": user_message},
]


# --------------------------------------------------
# First model call
# --------------------------------------------------
response = client.chat.completions.create(
    model="llama-3.3-70b-versatile",
    messages=messages,
    tools=tools,
    tool_choice="auto",
)

assistant_message = response.choices[0].message


# --------------------------------------------------
# Execute tool if requested
# --------------------------------------------------
if assistant_message.tool_calls:
    messages.append(assistant_message)

    for tool_call in assistant_message.tool_calls:
        function_name = tool_call.function.name
        arguments = json.loads(tool_call.function.arguments)

        if function_name == "get_weather":
            result = get_weather(arguments["city"])

        elif function_name == "calculate_sum":
            result = calculate_sum(arguments["a"], arguments["b"])

        else:
            result = {"error": "Unknown function"}

        print(f"Tool Executed: {function_name}")
        print(f"Tool Result: {result}\n")

        messages.append(
            {
                "role": "tool",
                "tool_call_id": tool_call.id,
                "name": function_name,
                "content": json.dumps(result),
            }
        )

    # --------------------------------------------------
    # Second model call with tool results
    # --------------------------------------------------
    final_response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=messages,
    )

    print("Assistant:")
    print(final_response.choices[0].message.content)

else:
    print("Assistant:")
    print(assistant_message.content)