# Generated-Knowledge Prompting

## Overview

This project demonstrates **Generated-Knowledge Prompting**, an advanced prompt engineering technique where a Large Language Model (LLM) first generates relevant background knowledge before producing the final answer.

Instead of answering a question immediately, the model first creates useful facts and contextual information related to the question. It then uses this generated knowledge to produce a more comprehensive, accurate, and well-structured response.

This technique is particularly useful for questions that require additional context or domain knowledge, helping the model generate higher-quality answers.

---

# Project Structure

```text
Generated-Knowledge-Prompting/
│
├── main.py
├── requirements.txt
├── README.md
├── .gitignore
└── .env
```

---

# Project Workflow

```text
                User Question
                      │
                      ▼
      Generate Relevant Background Knowledge
                      │
                      ▼
      Review the Generated Knowledge
                      │
                      ▼
Combine Generated Knowledge with the Original Question
                      │
                      ▼
 Generate a More Informed and Detailed Answer
                      │
                      ▼
             Display Final Output
```

---

