import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)

from pathlib import Path

from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma
import ollama


# --------------------------------------------------
# Load documents
# --------------------------------------------------

knowledge_dir = Path("knowledge_base")

documents = []

for file_path in knowledge_dir.glob("*.txt"):
    loader = TextLoader(str(file_path), encoding="utf-8")
    documents.extend(loader.load())


# --------------------------------------------------
# Split documents into chunks
# --------------------------------------------------

splitter = RecursiveCharacterTextSplitter(
    chunk_size=300,
    chunk_overlap=50
)

chunks = splitter.split_documents(documents)

print(f"Loaded {len(documents)} documents")
print(f"Created {len(chunks)} chunks")


# --------------------------------------------------
# Create embeddings
# --------------------------------------------------

embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)


# --------------------------------------------------
# Store in ChromaDB
# --------------------------------------------------

vectorstore = Chroma.from_documents(
    documents=chunks,
    embedding=embeddings,
    persist_directory="chroma_db"
)


# --------------------------------------------------
# Create retriever
# --------------------------------------------------

retriever = vectorstore.as_retriever(search_kwargs={"k": 3})


# --------------------------------------------------
# Ask a question
# --------------------------------------------------

question = input("Ask a question: ")


# --------------------------------------------------
# Retrieve relevant documents
# --------------------------------------------------

retrieved_docs = retriever.invoke(question)

context = "\n\n".join(doc.page_content for doc in retrieved_docs)


# --------------------------------------------------
# Build grounded prompt
# --------------------------------------------------

prompt = f"""
You are a helpful knowledge assistant.

Answer the question using ONLY the provided context.
If the answer is not available in the context, say:
"I could not find that information in the knowledge base."

Context:
{context}

Question:
{question}

Answer:
"""


# --------------------------------------------------
# Generate response with Ollama
# --------------------------------------------------

response = ollama.chat(
    model="llama3.2",
    messages=[{"role": "user", "content": prompt}]
)

print("\nKnowledge Assistant Response\n")
print(response["message"]["content"])