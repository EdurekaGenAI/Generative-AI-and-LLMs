import os
import requests
from dotenv import load_dotenv
from google import genai
from groq import Groq
from openai import OpenAI


# ==================================================
# Load Environment Variables
# ==================================================
load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
NVIDIA_API_KEY = os.getenv("NVIDIA_API_KEY")


# ==================================================
# Create API Clients
# ==================================================
gemini_client = genai.Client(api_key=GEMINI_API_KEY)

groq_client = Groq(api_key=GROQ_API_KEY)

openrouter_client = OpenAI(
    api_key=OPENROUTER_API_KEY,
    base_url="https://openrouter.ai/api/v1"
)


# ==================================================
# Gemini 3.5 Flash
# ==================================================
def call_gemini(prompt):
    try:
        response = gemini_client.models.generate_content(
            model="gemini-3.5-flash",
            contents=prompt,
            config={
                "max_output_tokens": 1500,
                "temperature": 0.7
            }
        )

        if hasattr(response, "text") and response.text:
            return response.text.strip()

        return "Gemini Error: Empty response received"

    except Exception as e:
        return f"Gemini Error: {e}"


# ==================================================
# Groq - Llama 3.1
# ==================================================
def call_groq(prompt):
    try:
        response = groq_client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1500
        )

        return response.choices[0].message.content.strip()

    except Exception as e:
        return f"Groq Error: {e}"


# ==================================================
# OpenRouter - GPT OSS 20B
# ==================================================
def call_openrouter(prompt):
    try:
        response = openrouter_client.chat.completions.create(
            model="openai/gpt-oss-20b",
            messages=[
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1500
        )

        content = response.choices[0].message.content

        if not content:
            return "OpenRouter Error: Empty response received"

        return content.strip()

    except Exception as e:
        return f"OpenRouter Error: {e}"


# ==================================================
# NVIDIA NIM - MiniMax M3
# ==================================================
def call_minimax(prompt):
    try:
        url = "https://integrate.api.nvidia.com/v1/chat/completions"

        headers = {
            "Authorization": f"Bearer {NVIDIA_API_KEY}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": "minimaxai/minimax-m3",
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.7,
            "max_tokens": 1500
        }

        response = requests.post(url, headers=headers, json=payload)

        if response.status_code != 200:
            return f"MiniMax M3 Error: {response.status_code} - {response.text}"

        data = response.json()

        return data["choices"][0]["message"]["content"].strip()

    except Exception as e:
        return f"MiniMax M3 Error: {e}"


# ==================================================
# Display Helper
# ==================================================
def display_response(provider, response):
    print(f"\\n{'=' * 25} {provider} {'=' * 25}")
    print(response)


# ==================================================
# Main Application
# ==================================================
def main():

    print("=" * 90)
    print("MULTI-PROVIDER LLM DEMO")
    print("Gemini 3.5 Flash + Groq + OpenRouter GPT OSS 20B + MiniMax M3")
    print("=" * 90)

    prompt = input("\\nEnter your prompt: ")

    print("\\nGenerating responses from all providers...")

    responses = {
        "Gemini 3.5 Flash": call_gemini(prompt),
        "Groq (Llama 3.1)": call_groq(prompt),
        "OpenRouter (GPT OSS 20B)": call_openrouter(prompt),
        "MiniMax M3 (NVIDIA NIM)": call_minimax(prompt),
    }

    for provider, response in responses.items():
        display_response(provider, response)

    print("\\n" + "=" * 90)
    print("All provider calls completed successfully!")
    print("=" * 90)


if __name__ == "__main__":
    main() 