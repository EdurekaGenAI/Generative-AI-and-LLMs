from weak_rag import run_weak_pipeline
from improved_rag import run_improved_pipeline


def main():
    query = "How does re-ranking improve retrieval quality?"

    print("=" * 70)
    print("DIAGNOSING A WEAK RAG PIPELINE")
    print("=" * 70)

    run_weak_pipeline(query)

    print("\n" + "=" * 70)
    print("IMPROVING THE RAG PIPELINE")
    print("=" * 70)

    run_improved_pipeline(query)


if __name__ == "__main__":
    main()