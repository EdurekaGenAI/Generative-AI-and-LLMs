from langchain_text_splitters import CharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# --------------------------------------------------
# Load and split documents
# --------------------------------------------------

with open("knowledge_base.txt", "r", encoding="utf-8") as file:
    text = file.read()

splitter = CharacterTextSplitter(
    chunk_size=200,
    chunk_overlap=20
)

docs = splitter.create_documents([text])

# --------------------------------------------------
# Dense retrieval with embeddings
# --------------------------------------------------

embedding_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

vectorstore = Chroma.from_documents(
    documents=docs,
    embedding=embedding_model,
    persist_directory="chroma_db"
)

# --------------------------------------------------
# Keyword retrieval with TF-IDF
# --------------------------------------------------

texts = [doc.page_content for doc in docs]

tfidf = TfidfVectorizer()
tfidf_matrix = tfidf.fit_transform(texts)

# --------------------------------------------------
# Hybrid search function
# --------------------------------------------------

def hybrid_search(query, top_k=3):

    print("\n" + "=" * 60)
    print(f"Query: {query}")
    print("=" * 60)

    # --------------------------------------------------
    # Dense retrieval
    # --------------------------------------------------

    query_embedding = embedding_model.embed_query(query)

    dense_scores = cosine_similarity(
        [query_embedding],
        embedding_model.embed_documents(texts)
    )[0]

    # --------------------------------------------------
    # Keyword retrieval
    # --------------------------------------------------

    query_vec = tfidf.transform([query])

    keyword_scores = cosine_similarity(
        query_vec,
        tfidf_matrix
    ).flatten()

    # --------------------------------------------------
    # Combine dense and keyword scores
    # --------------------------------------------------

    combined_scores = []

    for i, text in enumerate(texts):

        dense_score = dense_scores[i]
        keyword_score = keyword_scores[i]

        hybrid_score = (
            0.6 * dense_score +
            0.4 * keyword_score
        )

        combined_scores.append(
            (text, dense_score, keyword_score, hybrid_score)
        )

    # --------------------------------------------------
    # Sort by hybrid score
    # --------------------------------------------------

    ranked = sorted(
        combined_scores,
        key=lambda x: x[3],
        reverse=True
    )[:top_k]

    # --------------------------------------------------
    # Display results
    # --------------------------------------------------

    print("\nTop Results:")

    for idx, (text, dense_score, keyword_score, hybrid_score) in enumerate(
        ranked,
        start=1
    ):

        print(f"\n{idx}. Hybrid Score: {hybrid_score:.3f}")
        print(f"   Dense Score:   {dense_score:.3f}")
        print(f"   Keyword Score: {keyword_score:.3f}")
        print(f"   Document: {text}")


# --------------------------------------------------
# Run demo
# --------------------------------------------------

if __name__ == "__main__":

    hybrid_search(
        "What is hybrid search in AI?"
    )

    hybrid_search(
        "exact keyword matching"
    )

    hybrid_search(
        "semantic vector retrieval"
    )