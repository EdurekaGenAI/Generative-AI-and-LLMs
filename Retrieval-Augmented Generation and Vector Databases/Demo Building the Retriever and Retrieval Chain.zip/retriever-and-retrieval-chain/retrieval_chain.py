def retrieval_chain(retriever, query):
    results = retriever.invoke(query)

    context = "\n\n".join([doc.page_content for doc in results])

    response = f"""
Retrieved Context:
{context}

Question: {query}

Answer: The response is generated using the retrieved context above.
"""

    return response