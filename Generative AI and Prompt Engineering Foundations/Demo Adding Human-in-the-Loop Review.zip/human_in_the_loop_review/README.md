# Demo: Adding Human-in-the-Loop Review

## Overview

Human-in-the-Loop (HITL) is a collaborative approach in Artificial Intelligence where a human reviews, validates, or modifies AI-generated outputs before they are finalized. This process improves the reliability, accuracy, and quality of AI systems by combining automated intelligence with human expertise.

In this project, the **Groq API** is used to generate responses using the **Llama 3.3 70B Versatile** model. Rather than directly presenting the AI-generated response, the application introduces a human review stage where the reviewer can **approve**, **edit**, or **reject** the generated content. This workflow demonstrates how Human-in-the-Loop systems are implemented in real-world AI applications.

---

# Project Structure

```text
human_in_the_loop_review/
│
├── main.py
├── requirements.txt
├── .env
├── .gitignore
└── README.md
```

### File Description

- **main.py** - Implements the complete Human-in-the-Loop review workflow using the Groq API.
- **requirements.txt** - Lists all required Python libraries.
- **.env** - Stores the Groq API key securely.
- **.gitignore** - Excludes unnecessary files from version control.
- **README.md** - Contains the project documentation.

---

# Project Workflow

```text
+----------------------+
|      User Prompt     |
+----------+-----------+
           |
           v
+----------------------+
|   Groq API Request   |
| (Llama 3.3 70B Model)|
+----------+-----------+
           |
           v
+----------------------+
| AI Generates Draft   |
|      Response        |
+----------+-----------+
           |
           v
+----------------------+
| Human Reviews Output |
+----------+-----------+
           |
   +-------+--------+-------+
   |                |       |
   v                v       v
Approve           Edit    Reject
   |                |       |
   +-------+--------+-------+
           |
           v
+----------------------+
| Final Reviewed       |
| Response Displayed   |
+----------------------+
```

---