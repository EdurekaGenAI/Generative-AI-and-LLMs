# Containerising a GenAI Application with Docker

## Overview

This project demonstrates how to containerise a Generative AI application using Docker. The application is built with FastAPI and connects to the Groq API to generate text using a large language model.

The project shows how application code, Python dependencies, and the runtime environment can be packaged into a Docker image and executed as an isolated container.

The application provides a simple REST API where users can submit a prompt and receive an AI-generated response. FastAPI provides the API layer, the Groq Python SDK connects the application to the Groq API, and Docker provides the containerised runtime environment.

The Groq API key is supplied through an environment file at runtime rather than being embedded inside the Docker image.

## Project Structure

```text
genai-docker-demo/
│
├── app.py
├── requirements.txt
├── Dockerfile
├── .dockerignore
├── .gitignore
├── .env
└── README.md
```


## Project Workflow

The application follows this workflow:

```text
User
  │
  │ Prompt
  ▼
FastAPI Application
  │
  │ Request Validation
  ▼
Groq Python SDK
  │
  │ API Request
  ▼
Groq API
  │
  ▼
Language Model
  │
  │ Generated Response
  ▼
Groq API
  │
  ▼
FastAPI Application
  │
  │ JSON Response
  ▼
User
```

Docker adds the containerisation layer around the application:

```text
Application Code
      │
      ▼
requirements.txt
      │
      ▼
Dockerfile
      │
      ▼
Docker Image
      │
      ▼
Docker Container
      │
      ├── FastAPI
      ├── Python Runtime
      ├── Dependencies
      └── GenAI Application
               │
               ▼
           Groq API
```
