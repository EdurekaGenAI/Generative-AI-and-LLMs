from app.utils import load_csv, print_section

from app.data_drift import (
    calculate_feature_drift,
    print_data_drift_report,
)

from app.model_drift import (
    simulate_baseline_predictions,
    simulate_current_predictions,
    calculate_model_drift,
    print_model_drift_report,
)


def main():
    print_section("DETECTING MODEL AND DATA DRIFT IN PRODUCTION")

    baseline_df = load_csv("data/baseline.csv")
    production_df = load_csv("data/production.csv")

    print_section("STEP 1 - DATA DRIFT ANALYSIS")

    data_drift_report = calculate_feature_drift(
        baseline_df,
        production_df,
        threshold=0.15,
    )

    print_data_drift_report(data_drift_report)

    print_section("STEP 2 - MODEL DRIFT ANALYSIS")

    baseline_predictions = simulate_baseline_predictions(
        len(baseline_df)
    )

    current_predictions = simulate_current_predictions(
        len(production_df)
    )

    model_drift_result = calculate_model_drift(
        baseline_predictions,
        current_predictions,
        threshold=0.12,
    )

    print_model_drift_report(model_drift_result)

    print_section("STEP 3 - FINAL MONITORING SUMMARY")

    data_drift_detected = any(
        item["status"] == "DRIFT DETECTED"
        for item in data_drift_report
    )

    model_drift_detected = (
        model_drift_result["status"] == "WARNING"
    )

    if data_drift_detected or model_drift_detected:
        print("ALERT: Drift detected in the production environment.")
        print("Recommended Action:")
        print(" - Review incoming production data")
        print(" - Validate model performance metrics")
        print(" - Consider retraining the model")
    else:
        print("Production system is stable.")

    print("\nMonitoring completed successfully.")


if __name__ == "__main__":
    main()