import os

from dotenv import load_dotenv
from groq import Groq

# ------------------------------------------------------------------
# Load Environment Variables
# ------------------------------------------------------------------

load_dotenv()

api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    raise ValueError(
        "GROQ_API_KEY not found. Please add it to your .env file."
    )

client = Groq(api_key=api_key)

MODEL = "llama-3.3-70b-versatile"


# ------------------------------------------------------------------
# Display Header
# ------------------------------------------------------------------

def print_header():
    print("=" * 70)
    print("Demo: Adding Human-in-the-Loop Review")
    print("=" * 70)


# ------------------------------------------------------------------
# Generate AI Response
# ------------------------------------------------------------------

def generate_response(prompt, feedback=None):
    """
    Generate a response using the Groq API.

    If feedback is provided, the model revises
    its previous response based on the review.
    """

    messages = [
        {
            "role": "system",
            "content": (
                "You are a professional AI assistant."
                " Generate accurate, well-structured,"
                " and concise responses."
            ),
        }
    ]

    if feedback:

        messages.append(
            {
                "role": "user",
                "content": (
                    f"""
Original Request:

{prompt}

Reviewer Feedback:

{feedback}

Please generate an improved response
that addresses the review comments.
"""
                ),
            }
        )

    else:

        messages.append(
            {
                "role": "user",
                "content": prompt,
            }
        )

    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        temperature=0.4,
    )

    return response.choices[0].message.content


# ------------------------------------------------------------------
# Human Review Stage
# ------------------------------------------------------------------

def review_response():

    print("\nReview Options")
    print("-" * 70)
    print("1. Approve")
    print("2. Request Revision")
    print("3. Reject")

    while True:

        choice = input("\nSelect an option (1-3): ").strip()

        if choice in ["1", "2", "3"]:
            return choice

        print("Invalid choice. Please try again.")


# ------------------------------------------------------------------
# Main Program
# ------------------------------------------------------------------

def main():

    print_header()

    prompt = input("\nEnter your prompt:\n> ")

    ai_response = generate_response(prompt)

    while True:

        print("\n" + "=" * 70)
        print("AI GENERATED RESPONSE")
        print("=" * 70)
        print(ai_response)

        decision = review_response()

        if decision == "1":

            print("\n" + "=" * 70)
            print("FINAL APPROVED RESPONSE")
            print("=" * 70)
            print(ai_response)
            break

        elif decision == "2":

            feedback = input(
                "\nEnter reviewer feedback:\n> "
            )

            print("\nGenerating an improved response...\n")

            ai_response = generate_response(
                prompt,
                feedback
            )

        else:

            print("\n" + "=" * 70)
            print("RESPONSE REJECTED")
            print("=" * 70)
            print(
                "The AI-generated response was rejected by the reviewer."
            )
            break


# ------------------------------------------------------------------
# Entry Point
# ------------------------------------------------------------------

if __name__ == "__main__":
    main()