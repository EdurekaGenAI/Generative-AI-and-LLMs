import os
from groq import Groq
from dotenv import load_dotenv

# -----------------------------------
# Load environment variables
# -----------------------------------
load_dotenv()

# -----------------------------------
# Create Groq client
# -----------------------------------
client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

# -----------------------------------
# User prompt
# -----------------------------------
prompt = "Explain streaming responses and token usage in large language models in simple terms."

print("\nStreaming response...\n")

# -----------------------------------
# Send streaming request
# -----------------------------------
stream = client.chat.completions.create(
    model="llama-3.3-70b-versatile",
    messages=[
        {"role": "user", "content": prompt}
    ],
    temperature=0.7,
    stream=True
)

# Store the complete streamed response
full_response = ""

# -----------------------------------
# Receive and print streamed chunks
# -----------------------------------
for chunk in stream:
    content = chunk.choices[0].delta.content

    if content:
        print(content, end="", flush=True)
        full_response += content

# -----------------------------------
# Estimate token usage
# -----------------------------------
# Simple approximation:
# 1 token ≈ 4 characters
prompt_tokens = max(1, len(prompt) // 4)
completion_tokens = max(1, len(full_response) // 4)
total_tokens = prompt_tokens + completion_tokens

# -----------------------------------
# Estimate API cost
# -----------------------------------
# Example pricing (illustrative only)
PRICE_PER_MILLION_TOKENS = 0.37  # USD

estimated_cost = (
    total_tokens / 1_000_000
) * PRICE_PER_MILLION_TOKENS

# -----------------------------------
# Display final usage report
# -----------------------------------
print("\n" + "-" * 40)
print("TOKEN USAGE AND COST REPORT")
print("-" * 40)

print(f"Prompt Tokens      : {prompt_tokens}")
print(f"Completion Tokens  : {completion_tokens}")
print(f"Total Tokens       : {total_tokens}")

print()
print(f"Estimated Cost     : ${estimated_cost:.8f}")

print("-" * 40)