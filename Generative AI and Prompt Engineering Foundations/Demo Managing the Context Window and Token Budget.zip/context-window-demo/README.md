# Demo: Managing the Context Window and Token Budget

## Overview

Large Language Models (LLMs) have a limited context window, which determines how much information they can process in a single request. Every piece of text sent to the model consumes tokens, including instructions, context, user prompts, and the generated response.

In this project, you will explore how different amounts of context influence the quality, efficiency, and token usage of an LLM. Using the Groq API, the same question is asked with varying amounts of contextual information to demonstrate the importance of managing the context window and optimising the token budget.

---

# Project Structure

```text
context-window-token-budget/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

---

# Project Workflow

```text
                    Start
                      │
                      ▼
        Load Environment Variables
                      │
                      ▼
         Initialise Groq Client
                      │
                      ▼
      Define Large Context Document
                      │
                      ▼
     Create Optimised Context Version
                      │
                      ▼
        Define User Question
                      │
                      ▼
    Send Large Context to Groq API
                      │
                      ▼
        Receive First Response
                      │
                      ▼
  Send Optimised Context to Groq API
                      │
                      ▼
       Receive Second Response
                      │
                      ▼
 Compare Context Size and Responses
                      │
                      ▼
 Display Results in the Terminal
                      │
                      ▼
                     End
```
