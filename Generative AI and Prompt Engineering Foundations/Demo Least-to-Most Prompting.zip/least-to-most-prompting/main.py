import os
from dotenv import load_dotenv
from groq import Groq

# --------------------------------------------------
# Load Environment Variables
# --------------------------------------------------
load_dotenv()

api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    raise ValueError("GROQ_API_KEY not found. Please check your .env file.")

# --------------------------------------------------
# Initialise Groq Client
# --------------------------------------------------
client = Groq(api_key=api_key)

MODEL = "llama-3.3-70b-versatile"


def print_header():
    print("=" * 70)
    print("PROMPT ENGINEERING DEMO")
    print("Least-to-Most Prompting")
    print("=" * 70)


def generate_response(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        temperature=0.2,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response.choices[0].message.content


def main():
    print_header()

    problem = """
A school is organising a science exhibition.

There are 180 students participating.

• Each team must have exactly 6 students.
• Every team requires 2 display boards.
• Each display board costs ₹275.
• Every team also receives a science kit costing ₹450.

Calculate:

1. The total number of teams.
2. The total number of display boards required.
3. The total cost of the display boards.
4. The total cost of the science kits.
5. The overall expenditure for the exhibition.
"""

    print("\nProblem Statement")
    print("-" * 70)
    print(problem)

    prompt = f"""
You are an expert problem-solving assistant.

Solve the following problem using the Least-to-Most Prompting technique.

Follow this exact reasoning process.

Step 1:
Understand the problem and identify the final objective.

Step 2:
Extract all important numerical information.

Step 3:
Break the problem into smaller independent subproblems.

Step 4:
Solve each subproblem individually with calculations.

Step 5:
Use the intermediate answers to solve the remaining parts.

Step 6:
Summarise all calculations.

Step 7:
Provide the final answer in a clean and well-formatted manner.

Problem:

{problem}
"""

    print("\nGenerating response...\n")

    answer = generate_response(prompt)

    print(answer)


if __name__ == "__main__":
    main()