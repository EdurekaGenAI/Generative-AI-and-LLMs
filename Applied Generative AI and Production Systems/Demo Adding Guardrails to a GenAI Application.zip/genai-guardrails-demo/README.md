# README.md

# Adding Guardrails to a GenAI Application

## Overview

This project demonstrates how to **add guardrails to a Generative AI application** using Python.

The application includes multiple safety layers:

* **Input validation** to reject empty prompts.
* **Profanity filtering** for inappropriate language.
* **Prompt injection detection** using pattern matching.
* **Output validation** to prevent exposure of sensitive information.

The project simulates how real-world GenAI systems apply **safety checks before and after interacting with a language model**.

---

## Project Structure

```text
genai-guardrails-demo/
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

---

## Project Workflow

```text
Start
   |
   v
User enters prompt
   |
   v
Input Validation
   |
   +--> Empty input check
   |
   +--> Profanity filtering
   |
   +--> Prompt injection detection
   |
   v
Safe Input?
   |
   +--> No --> Block Request
   |
   v
Generate AI Response
   |
   v
Output Validation
   |
   +--> Sensitive data detection
   |
   v
Safe Output?
   |
   +--> No --> Block Output
   |
   v
Display Final Safe Response
   |
   v
End
```

---