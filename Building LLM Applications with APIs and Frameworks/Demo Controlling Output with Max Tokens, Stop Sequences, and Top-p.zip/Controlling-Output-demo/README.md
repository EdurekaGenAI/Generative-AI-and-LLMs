# Controlling Output Demo

## Overview

This project demonstrates how to control **Large Language Model (LLM)** responses using the **Groq API** with three important parameters:

- **Max Tokens** → limits the response length
- **Stop Sequences** → stops generation at a specific keyword or pattern
- **Top-p (Nucleus Sampling)** → controls creativity and diversity of the output

The demo helps understand how LLM output can be made **shorter, more structured, and more predictable** for real-world AI applications such as chatbots, summarisation tools, and content generators.

---

## Project Structure

```text
Controlling-Output-demo/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

## Project Workflow

```text
┌──────────────────────────────┐
│        Start Program         │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Load Environment Variables   │
│ (.env file)                  │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Create Groq API Client       │
│ using the API key            │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Receive User Prompt          │
│ from main.py                 │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Apply Max Tokens             │
│ Limit response length        │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Apply Stop Sequence          │
│ Stop at specific keyword     │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Apply Top-p Sampling         │
│ Control creativity & focus  │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Send Request to Groq Model   │
│ llama-3.3-70b-versatile      │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Generate Controlled Response │
│ based on all parameters      │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Display Output in Terminal   │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│         End Program          │
└──────────────────────────────┘
```