# Demo: Adding Retrieved Context to a Prompt

## Overview

In many real-world AI applications, a language model needs access to information that was not part of its original training data. Instead of relying solely on the model's internal knowledge, we can retrieve relevant information from an external source and include it in the prompt before generating a response.

In this demo, we build a simple retrieval pipeline that searches a local knowledge base, selects the most relevant content, and passes it to the Groq API. This demonstrates the fundamental concept behind **Retrieval-Augmented Generation (RAG)**.

---

## Project Structure

```text
retrieved-context-demo/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
├── knowledge_base.txt
└── main.py
```

---

## Project Workflow

```text
                User Question
                      │
                      ▼
         Load Knowledge Base
                      │
                      ▼
      Split into Individual Chunks
                      │
                      ▼
     Calculate Relevance Score
                      │
                      ▼
    Retrieve Top Matching Chunks
                      │
                      ▼
     Build Prompt with Context
                      │
                      ▼
      Send Prompt to Groq API
                      │
                      ▼
        Generate AI Response
                      │
                      ▼
          Display the Answer
```