# Adding and Swapping Task Adapters

## Overview

This project demonstrates how to build a simple **adapter-based AI architecture** in Python.

Instead of hardcoding task-specific logic, each task is implemented as a separate **adapter** that follows a common interface. The application can dynamically **add**, **swap**, or **replace** adapters without changing the core program.

The demo includes three task adapters:

* **Sentiment Analysis Adapter**
* **Summarization Adapter**
* **Translation Adapter**

---

## Project Structure

```text
task-adapter-demo/
├── adapters/
│   ├── sentiment_adapter.py
│   ├── summarization_adapter.py
│   └── translation_adapter.py
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

---

## Project Workflow

The application uses a **flowchart-based workflow** where the `TaskManager` dynamically swaps task adapters.

```text
┌─────────────────────┐
│     Start Program   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│   User Provides     │
│      Input Text     │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│     TaskManager     │
│ Receives Input Text │
└──────────┬──────────┘
           │
           ▼
┌──────────────────────────────┐
│ Select Task Adapter at       │
│ Runtime                      │
└───────┬─────────┬────────────┘
        │         │
   ┌────▼───┐ ┌───▼──────────┐
   │Sentiment│ │Summarization│
   │ Adapter │ │   Adapter   │
   └────┬────┘ └────┬────────┘
        │            │
        ▼            ▼
 ┌────────────┐ ┌────────────────┐
 │Positive /  │ │ Generate Short │
 │Negative    │ │    Summary     │
 └────┬───────┘ └──────┬─────────┘
      │                 │
      └────────┬────────┘
               │
               ▼
      ┌───────────────────┐
      │ TranslationAdapter│
      └─────────┬─────────┘
                │
                ▼
      ┌───────────────────┐
      │ Produce Translated│
      │       Text        │
      └─────────┬─────────┘
                │
                ▼
      ┌───────────────────┐
      │ Display Final     │
      │      Output       │
      └─────────┬─────────┘
                │
                ▼
      ┌───────────────────┐
      │        End        │
      └───────────────────┘
```

## Extending the System

To add a new adapter:

1. Create a new Python file inside the `adapters/` directory.
2. Implement a `process(text)` method.
3. Import and register the adapter in `main.py`.

Example:

```python
class KeywordAdapter:
    def process(self, text):
        return [word for word in text.split() if len(word) > 6]
```

Then activate it:

```python
manager.set_adapter(KeywordAdapter())
```

No changes are required in the existing adapters or the `TaskManager`.

This demonstrates the core advantage of the **Adapter Pattern**: new functionality can be introduced with minimal changes to the existing codebase.
