import time
import numpy as np
import faiss

# --------------------------------------------------
# Generate sample vectors
# --------------------------------------------------

num_vectors = 5000
dimension = 64

np.random.seed(42)

vectors = np.random.random((num_vectors, dimension)).astype(np.float32)

# Query vector
query = np.random.random((1, dimension)).astype(np.float32)

# ==================================================
# HNSW USING FAISS
# ==================================================

hnsw_index = faiss.IndexHNSWFlat(dimension, 16)
hnsw_index.hnsw.efConstruction = 200
hnsw_index.hnsw.efSearch = 50

hnsw_index.add(vectors)

start = time.time()
hnsw_distances, hnsw_indices = hnsw_index.search(query, 5)
hnsw_time = (time.time() - start) * 1000

# ==================================================
# IVF INDEX
# ==================================================

nlist = 50

quantizer = faiss.IndexFlatL2(dimension)

ivf_index = faiss.IndexIVFFlat(
    quantizer,
    dimension,
    nlist,
    faiss.METRIC_L2
)

ivf_index.train(vectors)
ivf_index.add(vectors)
ivf_index.nprobe = 10

start = time.time()
ivf_distances, ivf_indices = ivf_index.search(query, 5)
ivf_time = (time.time() - start) * 1000

# ==================================================
# DISPLAY RESULTS
# ==================================================

print("=" * 70)
print("FAISS HNSW vs IVF COMPARISON")
print("=" * 70)

print(f"{'Rank':<6}{'HNSW ID':<12}{'HNSW Dist':<15}{'IVF ID':<12}{'IVF Dist':<15}")
print("-" * 70)

for i in range(5):
    print(
        f"{i+1:<6}"
        f"{hnsw_indices[0][i]:<12}"
        f"{hnsw_distances[0][i]:<15.4f}"
        f"{ivf_indices[0][i]:<12}"
        f"{ivf_distances[0][i]:<15.4f}"
    )

print("-" * 70)
print(f"HNSW Search Time : {hnsw_time:.3f} ms")
print(f"IVF  Search Time : {ivf_time:.3f} ms")
print("=" * 70)