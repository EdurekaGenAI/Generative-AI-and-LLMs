## Building an LLM Application with Tool Integration

This project demonstrates how to build a **modular LLM application with external tool integration** using **Python** and the **Groq API**. The application combines a large language model with custom Python tools to perform tasks such as **mathematical calculations**, **real-time weather retrieval**, and **general conversational assistance**.

The main goal of this capstone is to show how an LLM can intelligently **route user requests to specialised tools** when needed, rather than relying only on text generation. This approach is commonly used in **AI agents, automation systems, and modern LLM-powered applications**.

### Key Features

* LLM-powered conversational assistant
* Mathematical calculator tool
* Real-time weather information
* Automatic query routing
* Modular and reusable Python architecture
* Interactive command-line interface

---

## Project Structure

```text
llm-tool-integration-capstone/
│
├── .gitignore
├── README.md
├── requirements.txt
├── main.py
│
├── app/
│   ├── __init__.py
│   ├── llm.py
│   └── router.py
│
└── tools/
    ├── __init__.py
    ├── calculator.py
    └── weather.py
```

### Structure Explanation

* **main.py** – Entry point of the application and interactive chat loop.
* **app/llm.py** – Handles communication with the Groq LLM API.
* **app/router.py** – Decides whether a user query should be processed by a tool or by the LLM.
* **tools/calculator.py** – Performs mathematical calculations.
* **tools/weather.py** – Retrieves live weather information from a public weather service.
* **requirements.txt** – Lists all required Python dependencies.
* **README.md** – Contains project documentation and usage instructions.
* **.gitignore** – Prevents unnecessary or sensitive files from being committed to version control.

---

## Project Workflow

```text
            User Input
                 |
                 v
        +------------------+
        |   Query Router   |
        +------------------+
            |          |
            |          |
            |          +------> Calculator Tool
            |
            +-----------------> Weather Tool
                 |
           Not handled
                 |
                 v
        +------------------+
        |     Groq LLM     |
        +------------------+
                 |
                 v
           Final Response
```