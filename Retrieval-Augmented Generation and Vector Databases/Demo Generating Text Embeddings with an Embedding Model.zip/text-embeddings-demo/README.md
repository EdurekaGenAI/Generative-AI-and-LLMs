# Generating Text Embeddings with an Embedding Model

## Overview

This project demonstrates how to generate **text embeddings** using a pre-trained **Sentence Transformers embedding model**.

Embeddings convert text into **numerical vectors** that capture semantic meaning. These vectors are widely used in:

- Semantic search
- Recommendation systems
- Document similarity
- Question answering
- Retrieval-Augmented Generation (RAG)

The project uses the lightweight **all-MiniLM-L6-v2** embedding model from Sentence Transformers.

---

## Project Structure

```text
text-embeddings-demo/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

---

## Project Workflow

```text
           ┌──────────────────────────────┐
           │        Start Program         │
           └──────────────┬───────────────┘
                          │
                          ▼
           ┌──────────────────────────────┐
           │ Load SentenceTransformer     │
           │   all-MiniLM-L6-v2 Model    │
           └──────────────┬───────────────┘
                          │
                          ▼
           ┌──────────────────────────────┐
           │   Define Input Sentences     │
           │  AI, Machine Learning, etc.  │
           └──────────────┬───────────────┘
                          │
                          ▼
           ┌──────────────────────────────┐
           │     Generate Embeddings      │
           │   model.encode(texts)        │
           └──────────────┬───────────────┘
                          │
                          ▼
           ┌──────────────────────────────┐
           │ Display Embedding Dimension  │
           │  and Sample Vector Values    │
           └──────────────┬───────────────┘
                          │
                          ▼
           ┌──────────────────────────────┐
           │ Compute Cosine Similarity    │
           │ Between Sentence Embeddings  │
           └──────────────┬───────────────┘
                          │
                          ▼
           ┌──────────────────────────────┐
           │ Compare Similarity Scores    │
           │  Related vs Unrelated Text   │
           └──────────────┬───────────────┘
                          │
                          ▼
           ┌──────────────────────────────┐
           │      Display Final Output    │
           │  Similarity Results Printed  │
           └──────────────┬───────────────┘
                          │
                          ▼
           ┌──────────────────────────────┐
           │            End               │
           └──────────────────────────────┘
```
