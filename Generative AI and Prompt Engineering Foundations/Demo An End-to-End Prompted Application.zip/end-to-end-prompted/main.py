import os
from dotenv import load_dotenv
from groq import Groq

# =====================================================
# Load Environment Variables
# =====================================================

load_dotenv()

api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    raise ValueError("GROQ_API_KEY not found in .env file.")

client = Groq(api_key=api_key)

MODEL = "llama-3.3-70b-versatile"


# =====================================================
# Utility Functions
# =====================================================

def print_header(title):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)


def ask_llm(system_prompt, user_prompt, temperature=0.7):

    response = client.chat.completions.create(
        model=MODEL,
        temperature=temperature,
        messages=[
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": user_prompt
            }
        ]
    )

    return response.choices[0].message.content.strip()


# =====================================================
# Step 1
# Content Generation
# =====================================================

def generate_article(topic):

    system_prompt = """
You are a professional technical content writer.

Write a high-quality article.

Requirements:
- Clear introduction
- Explain the topic
- Benefits
- Challenges
- Real-world applications
- Conclusion

Length:
Around 450 words.

Use headings.
"""

    return ask_llm(system_prompt, topic)


# =====================================================
# Step 2
# AI Review
# =====================================================

def review_article(article):

    system_prompt = """
You are a senior editor.

Review the article.

Evaluate:

1. Clarity
2. Grammar
3. Technical accuracy
4. Flow
5. Missing information

Return concise bullet-point feedback only.
"""

    return ask_llm(system_prompt, article)


# =====================================================
# Step 3
# Improve Article
# =====================================================

def improve_article(article, feedback):

    system_prompt = """
You are an expert editor.

Rewrite the article by applying every suggestion.

Requirements:

- Improve readability
- Improve structure
- Add missing details
- Keep professional tone

Return only the improved article.
"""

    prompt = f"""
Original Article

{article}

Reviewer Feedback

{feedback}
"""

    return ask_llm(system_prompt, prompt)


# =====================================================
# Step 4
# Generate Title
# =====================================================

def generate_title(article):

    system_prompt = """
Generate one professional title.

Rules:

Maximum 10 words.

Return only the title.
"""

    return ask_llm(system_prompt, article)


# =====================================================
# Step 5
# Generate Tags
# =====================================================

def generate_tags(article):

    system_prompt = """
Generate 8 relevant tags.

Return comma-separated tags only.
"""

    return ask_llm(system_prompt, article)


# =====================================================
# Step 6
# Executive Summary
# =====================================================

def generate_summary(article):

    system_prompt = """
Summarize the article.

Return exactly five bullet points.
"""

    return ask_llm(system_prompt, article)


# =====================================================
# Step 7
# Social Media Post
# =====================================================

def generate_social_post(article):

    system_prompt = """
Create a LinkedIn post promoting this article.

Requirements:

- Professional
- 120-150 words
- End with a question
- Include 5 hashtags
"""

    return ask_llm(system_prompt, article)


# =====================================================
# Main Application
# =====================================================

def main():

    print_header("END-TO-END PROMPTED APPLICATION")

    topic = input("Enter a topic: ").strip()

    if not topic:
        print("Topic cannot be empty.")
        return

    print("\nGenerating article...")
    article = generate_article(topic)

    print("Reviewing article...")
    feedback = review_article(article)

    print("Improving article...")
    improved_article = improve_article(article, feedback)

    print("Generating title...")
    title = generate_title(improved_article)

    print("Generating summary...")
    summary = generate_summary(improved_article)

    print("Generating tags...")
    tags = generate_tags(improved_article)

    print("Generating LinkedIn post...")
    social_post = generate_social_post(improved_article)

    print_header("FINAL TITLE")
    print(title)

    print_header("EXECUTIVE SUMMARY")
    print(summary)

    print_header("TAGS")
    print(tags)

    print_header("FINAL ARTICLE")
    print(improved_article)

    print_header("LINKEDIN POST")
    print(social_post)

    print_header("AI REVIEW FEEDBACK")
    print(feedback)

    print("\nApplication completed successfully.")


if __name__ == "__main__":
    main()