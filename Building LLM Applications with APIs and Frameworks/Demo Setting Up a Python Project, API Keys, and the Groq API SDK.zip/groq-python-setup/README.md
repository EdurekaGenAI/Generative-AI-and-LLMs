# Setting Up a Python Project, API Keys, and the Groq API SDK

## Overview

This project demonstrates how to build a clean and professional Python project for working with **Groq-hosted Large Language Models (LLMs)**. It covers the complete setup process, including creating a virtual environment, managing dependencies, storing API keys securely, and sending prompts to the Groq API using the official Python SDK.

By completing this project, you will learn how to:

- Create a well-organised Python project structure
- Use a virtual environment to isolate dependencies
- Store API keys securely with a `.env` file
- Install required libraries using `requirements.txt`
- Connect to the Groq API from Python
- Send prompts and receive AI-generated responses

This setup can be used as the foundation for **chatbots, AI assistants, summarisation tools, coding assistants, and other Generative AI applications**.

---

## Project Structure

```
groq-python-setup/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

### File Description

- **.env** → Stores the Groq API key securely.
- **.gitignore** → Prevents sensitive and unnecessary files from being committed to Git.
- **README.md** → Contains project documentation and setup instructions.
- **requirements.txt** → Lists all Python dependencies required for the project.
- **main.py** → Main application file that connects to the Groq API and generates responses.

---

## Project Workflow

```text
┌──────────────────────────┐
│   Create Project Folder  │
└────────────┬─────────────┘
             ↓
┌──────────────────────────┐
│ Create Virtual Environment│
└────────────┬─────────────┘
             ↓
┌──────────────────────────┐
│  Activate Environment    │
└────────────┬─────────────┘
             ↓
┌──────────────────────────┐
│ Install Dependencies     │
│ (requirements.txt)       │
└────────────┬─────────────┘
             ↓
┌──────────────────────────┐
│ Add GROQ_API_KEY to .env │
└────────────┬─────────────┘
             ↓
┌──────────────────────────┐
│        Run main.py       │
└────────────┬─────────────┘
             ↓
┌──────────────────────────┐
│  Send Prompt to Groq API │
└────────────┬─────────────┘
             ↓
┌──────────────────────────┐
│ Receive AI-generated     │
│ Response from the Model  │
└──────────────────────────┘
```

---

## Expected Result

When the project runs successfully, the application will:

1. Load the API key from the `.env` file.
2. Create a connection to the Groq API.
3. Send the user prompt to the selected LLM.
4. Receive and display the generated response in the terminal.

### Example Output

```text
Groq Response:

Virtual environments are useful in Python because they create isolated environments for each project, preventing dependency conflicts and improving reproducibility.
```

This workflow demonstrates a **real-world Python + Generative AI project setup** that follows professional development practices and is suitable for learning, portfolio projects, and production-ready AI applications.