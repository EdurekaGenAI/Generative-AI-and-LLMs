import os
from dotenv import load_dotenv
from groq import Groq

# ----------------------------------------------------
# Load Environment Variables
# ----------------------------------------------------

load_dotenv()

api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    raise ValueError("GROQ_API_KEY not found. Please check your .env file.")

# ----------------------------------------------------
# Initialize Groq Client
# ----------------------------------------------------

client = Groq(api_key=api_key)

MODEL_NAME = "llama-3.3-70b-versatile"

print("Loading model...")

# ----------------------------------------------------
# Input Prompt
# ----------------------------------------------------

prompt = input("\nEnter a prompt: ")

# ----------------------------------------------------
# Function to Generate Response
# ----------------------------------------------------

def generate_response(prompt, temperature, top_p):

    messages = [
        {
            "role": "system",
            "content": (
                "You are a helpful AI assistant. "
                "Provide a complete and well-structured response. "
                "Do not stop in the middle of a sentence or section. "
                "Finish the entire answer before ending."
            )
        },
        {
            "role": "user",
            "content": prompt
        }
    ]

    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=messages,
        temperature=temperature,
        top_p=top_p,
        max_completion_tokens=1200
    )

    return response.choices[0].message.content


# ----------------------------------------------------
# TEMPERATURE ANALYSIS
# ----------------------------------------------------

temperatures = [0.2, 0.7, 1.2]

print("\n" + "=" * 80)
print("TEMPERATURE ANALYSIS")
print("=" * 80)

for temperature in temperatures:

    print(f"\nTemperature = {temperature}")
    print("-" * 80)

    try:
        print(generate_response(prompt, temperature, 1.0))
    except Exception as error:
        print(f"Error: {error}")


# ----------------------------------------------------
# SAMPLING ANALYSIS
# ----------------------------------------------------

sampling_methods = [

    (
        "Greedy Decoding",
        {
            "temperature": 0.0,
            "top_p": 1.0
        }
    ),

    (
        "Top-p Sampling (0.8)",
        {
            "temperature": 0.7,
            "top_p": 0.8
        }
    ),

    (
        "Top-p Sampling (0.9)",
        {
            "temperature": 0.7,
            "top_p": 0.9
        }
    ),

    (
        "Top-p Sampling (1.0)",
        {
            "temperature": 0.7,
            "top_p": 1.0
        }
    )

]

print("\n" + "=" * 80)
print("SAMPLING ANALYSIS")
print("=" * 80)

for name, parameters in sampling_methods:

    print(f"\n{name}")
    print("-" * 80)

    try:
        print(
            generate_response(
                prompt,
                parameters["temperature"],
                parameters["top_p"]
            )
        )
    except Exception as error:
        print(f"Error: {error}")


# ----------------------------------------------------
# Completed
# ----------------------------------------------------

print("\n" + "=" * 80)
print("Analysis Completed Successfully!")
print("=" * 80)