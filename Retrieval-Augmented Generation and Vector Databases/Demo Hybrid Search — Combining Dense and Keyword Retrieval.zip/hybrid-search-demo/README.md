## Hybrid Search — Combining Dense and Keyword Retrieval

This project demonstrates **Hybrid Search**, a retrieval technique that combines **Dense Vector Retrieval** and **Keyword-Based Retrieval** to improve search accuracy.

Traditional keyword search works well for exact word matches, while dense retrieval understands the **semantic meaning** of a query using embeddings. By combining both approaches, hybrid search can retrieve documents that are:

* **Semantically relevant** to the query
* **Lexically relevant** through exact keyword matches
* More accurate than using either retrieval method alone

The project uses:

* **LangChain** for document processing
* **ChromaDB** for vector storage and semantic retrieval
* **Hugging Face Sentence Transformers** for generating embeddings
* **Scikit-learn TF-IDF** for keyword-based retrieval

This architecture is commonly used in **Retrieval-Augmented Generation (RAG)** systems, enterprise search engines, AI assistants, and document question-answering applications.

---

## Project Structure

```text
hybrid-search-demo/
├── .gitignore
├── README.md
├── requirements.txt
├── main.py
└── knowledge_base.txt
```

## Project Workflow

```text
                User Query
                     │
         ┌───────────┴───────────┐
         │                       │
         ▼                       ▼
 Dense Embedding Search    Keyword TF-IDF Search
         │                       │
         └───────────┬───────────┘
                     ▼
              Score Combination
                     ▼
              Ranked Documents
                     ▼
                Final Results
```


## Retrieval Pipeline Summary

```text
Documents
   │
   ▼
Chunking
   │
   ├──► Embeddings ─► ChromaDB ─► Dense Retrieval
   │
   └──► TF-IDF Index ───────────► Keyword Retrieval
                                      │
                                      ▼
                           Hybrid Score Fusion
                                      │
                                      ▼
                               Ranked Results
```