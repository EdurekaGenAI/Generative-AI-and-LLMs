# Demo: Scoring Generation Faithfulness and Relevance with RAGAS

## Overview

This project demonstrates how to evaluate **Retrieval-Augmented Generation (RAG)** outputs using **RAGAS**. The system retrieves relevant information from a local knowledge base, generates a grounded response, and evaluates the response using automatic RAGAS metrics.

The project integrates:

* **RAGAS** for evaluation
* **Groq Llama 3.1** as the evaluation LLM
* **HuggingFace Sentence Transformers** for embeddings
* **Chroma** as the vector database
* **LangChain** for orchestration

---

## Evaluation Metrics

### Faithfulness

Measures whether the generated answer is supported by the retrieved context.

### Answer Relevancy

Measures whether the generated answer directly addresses the user’s question.

---

## Project Structure

```text
ragas-evaluation-demo/
│
├── .env
├── README.md
├── requirements.txt
├── .gitignore
├── knowledge_base.txt
└── main.py
```

---

## Project Workflow

```text
            ┌────────────────────┐
            │ knowledge_base.txt │
            └─────────┬──────────┘
                      │
                      ▼
           ┌──────────────────────┐
           │ Load Documents       │
           └─────────┬────────────┘
                     │
                     ▼
           ┌──────────────────────┐
           │ Split into Chunks    │
           └─────────┬────────────┘
                     │
                     ▼
           ┌──────────────────────┐
           │ Create Embeddings    │
           │ (HuggingFace)        │
           └─────────┬────────────┘
                     │
                     ▼
           ┌──────────────────────┐
           │ Create Chroma Store  │
           └─────────┬────────────┘
                     │
                     ▼
           ┌──────────────────────┐
           │ Retrieve Context     │
           └─────────┬────────────┘
                     │
                     ▼
           ┌──────────────────────┐
           │ Generate Answer      │
           │ (Groq Llama 3.1)     │
           └─────────┬────────────┘
                     │
                     ▼
           ┌──────────────────────┐
           │ Evaluate with RAGAS  │
           │ • Faithfulness       │
           │ • Answer Relevancy   │
           └─────────┬────────────┘
                     │
                     ▼
           ┌──────────────────────┐
           │ Display Final Scores │
           └──────────────────────┘
```



## Expected Output

```text
============================================================
RAGAS EVALUATION DEMO (GROQ)
============================================================

Question:
What is Retrieval-Augmented Generation?

Generated Answer:
Retrieval-Augmented Generation combines information retrieval with a language model to generate grounded responses using external knowledge sources.

Retrieved Context:

Context 1:
Retrieval-Augmented Generation (RAG) combines a retriever with a language model so that responses are generated using external knowledge sources.

RAG improves factual grounding by retrieving relevant documents before generating an answer.

Context 2:
Vector databases such as ChromaDB store embeddings that enable semantic search across documents.

Faithfulness measures whether a generated answer is supported by the retrieved context.

Answer relevancy measures whether the generated answer directly addresses the user’s question.

------------------------------------------------------------
RAGAS EVALUATION SCORES
------------------------------------------------------------
Faithfulness      : 1.0000
Answer Relevancy  : 1.0000
------------------------------------------------------------
```

---

## Technologies Used

| Component            | Technology                             |
| -------------------- | -------------------------------------- |
| Evaluation Framework | RAGAS                                  |
| LLM                  | Groq Llama 3.1                         |
| Embeddings           | sentence-transformers/all-MiniLM-L6-v2 |
| Vector Database      | Chroma                                 |
| Framework            | LangChain                              |
| Language             | Python 3.11                            |

---