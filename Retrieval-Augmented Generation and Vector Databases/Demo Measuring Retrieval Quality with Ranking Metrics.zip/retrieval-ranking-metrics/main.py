from math import log2


# ==================================================
# Example Retrieval Results
# ==================================================

# Documents returned by the retriever in ranked order
retrieved_docs = [101, 105, 103, 108, 110]

# Ground-truth relevant documents
relevant_docs = {103, 110, 115}


# ==================================================
# Precision@k
# ==================================================

def precision_at_k(retrieved, relevant, k):
    """Return the proportion of relevant documents in the top-k results."""
    top_k = retrieved[:k]
    relevant_found = sum(doc in relevant for doc in top_k)
    return relevant_found / k


# ==================================================
# Recall@k
# ==================================================

def recall_at_k(retrieved, relevant, k):
    """Return the proportion of relevant documents retrieved in the top-k results."""
    top_k = retrieved[:k]
    relevant_found = sum(doc in relevant for doc in top_k)
    return relevant_found / len(relevant)


# ==================================================
# Mean Reciprocal Rank (MRR)
# ==================================================

def reciprocal_rank(retrieved, relevant):
    """Return the reciprocal rank of the first relevant document."""
    for rank, doc in enumerate(retrieved, start=1):
        if doc in relevant:
            return 1 / rank
    return 0.0


# ==================================================
# Discounted Cumulative Gain (DCG)
# ==================================================

def dcg(retrieved, relevant, k):
    """Compute Discounted Cumulative Gain for the top-k results."""
    score = 0.0

    for rank, doc in enumerate(retrieved[:k], start=1):
        relevance = 1 if doc in relevant else 0
        score += relevance / log2(rank + 1)

    return score


# ==================================================
# Normalized DCG (NDCG@k)
# ==================================================

def ndcg(retrieved, relevant, k):
    """Compute Normalized Discounted Cumulative Gain."""

    # Actual ranking quality
    actual_dcg = dcg(retrieved, relevant, k)

    # Ideal ranking (all relevant documents appear first)
    ideal_ranking = list(relevant)
    ideal_dcg = dcg(ideal_ranking, relevant, k)

    if ideal_dcg == 0:
        return 0.0

    return actual_dcg / ideal_dcg


# ==================================================
# Evaluation Runner
# ==================================================

def evaluate_retrieval(retrieved, relevant, k=5):
    """Evaluate retrieval quality using multiple ranking metrics."""

    print("\n" + "=" * 55)
    print("RETRIEVAL QUALITY EVALUATION")
    print("=" * 55)

    print(f"Retrieved Documents : {retrieved}")
    print(f"Relevant Documents  : {sorted(relevant)}")
    print(f"Evaluation Depth    : Top-{k}\n")

    print("Ranking Metrics")
    print("-" * 55)

    print(f"Precision@{k} : {precision_at_k(retrieved, relevant, k):.2f}")
    print(f"Recall@{k}    : {recall_at_k(retrieved, relevant, k):.2f}")
    print(f"MRR           : {reciprocal_rank(retrieved, relevant):.2f}")
    print(f"NDCG@{k}      : {ndcg(retrieved, relevant, k):.2f}")

    print("-" * 55)


# ==================================================
# Main Entry Point
# ==================================================

if __name__ == "__main__":
    evaluate_retrieval(retrieved_docs, relevant_docs, k=5)