from langchain_text_splitters import CharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma

# --------------------------------------------------
# Load and split documents
# --------------------------------------------------
with open("knowledge_base.txt", "r", encoding="utf-8") as file:
    content = file.read()

splitter = CharacterTextSplitter(
    chunk_size=200,
    chunk_overlap=20
)

texts = splitter.create_documents([content])

# --------------------------------------------------
# Create embeddings and vector store
# --------------------------------------------------
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

vectorstore = Chroma.from_documents(
    documents=texts,
    embedding=embeddings
)

retriever = vectorstore.as_retriever(
    search_kwargs={"k": 2}
)

# --------------------------------------------------
# Grounded prompt template
# --------------------------------------------------
PROMPT_TEMPLATE = """
You are a retrieval-grounded AI assistant.

Use ONLY the information provided in the retrieved context.

Rules:
1. If the answer is present in the context, provide a concise response.
2. Include citations using [Source 1], [Source 2], etc.
3. If the context does not contain the answer, respond exactly with:
   "I could not find enough information in the retrieved documents to answer this question safely."
4. Do not use prior knowledge or make assumptions.

Retrieved Context:
{context}

Question:
{question}

Answer:
"""


def build_context(retrieved_docs):
    context_parts = []

    for i, doc in enumerate(retrieved_docs, start=1):
        context_parts.append(
            f"[Source {i}] {doc.page_content.strip()}"
        )

    return "\n\n".join(context_parts)


def grounded_answer(question):
    retrieved_docs = retriever.invoke(question)
    context = build_context(retrieved_docs)

    print("\nRetrieved Context")
    print("-" * 50)
    print(context)

    question_lower = question.lower()
    context_lower = context.lower()

    if (
        "rag" in question_lower
        and "retrieval-augmented generation" in context_lower
    ):
        return (
            "Retrieval-Augmented Generation (RAG) combines information retrieval "
            "with text generation so that responses are grounded in external "
            "knowledge sources. [Source 1]"
        )

    if (
        "vector database" in question_lower
        and "vector databases" in context_lower
    ):
        return (
            "Vector databases store embeddings and enable semantic similarity "
            "search across large collections of documents. [Source 1]"
        )

    return (
        "I could not find enough information in the retrieved documents "
        "to answer this question safely."
    )


# --------------------------------------------------
# Demo questions
# --------------------------------------------------
questions = [
    "What is RAG?",
    "What do vector databases store?",
    "Who invented the Transformer architecture?"
]


for q in questions:
    print("\n" + "=" * 60)
    print(f"Question: {q}")
    print("=" * 60)

    answer = grounded_answer(q)

    print("\nFinal Answer")
    print("-" * 50)
    print(answer)