# Inspecting Behaviour with Temperature and Sampling

## Project Structure

```text
temperature-sampling/
├── .env
├── .gitignore
├── main.py
├── README.md
└── requirements.txt
```

## Installation

It is recommended to use a **Python virtual environment** before installing the required packages. This helps keep project dependencies isolated and avoids conflicts with other Python projects.

Create a virtual environment:

```bash
python -m venv .venv
```

Activate the virtual environment:

**Windows**

```bash
.venv\Scripts\activate
```

**macOS / Linux**

```bash
source .venv/bin/activate
```

Install the required Python packages:

```bash
pip install -r requirements.txt
```

## Configure the API Key

Create a file named `.env` in the project folder and add your Groq API key:

```text
GROQ_API_KEY=your_api_key_here
```

## Run the Project

Run the application:

```bash
python main.py
```

## Project Workflow

When you run the application, it will:

1. Load the Groq client using your API key.
2. Prompt you to enter a text prompt.
3. Perform **Temperature Analysis** using multiple temperature values.
4. Perform **Sampling Analysis** using different sampling settings.
5. Display the generated responses for comparison.

## Example Prompt

```text
Describe the future of artificial intelligence.
```

## Concepts Covered

- Temperature
- Sampling
- Greedy Decoding
- Top-p (Nucleus) Sampling
- Deterministic Text Generation
- Stochastic Text Generation

## Expected Outcome

By the end of this project, you should be able to observe that:

- Lower temperature values produce more focused and consistent responses.
- Higher temperature values produce more varied and creative responses.
- Greedy Decoding generates the most likely response.
- Top-p (Nucleus) Sampling introduces controlled randomness while maintaining response quality.
- Different generation settings produce different outputs for the same prompt.