# Building a GenAI API with FastAPI

## Overview

This project demonstrates how to build a **Generative AI API using FastAPI**.

The API accepts a text prompt from a client, processes it, and returns a simulated AI-generated response in JSON format. It provides a simple backend structure that can later be connected to real Large Language Models such as **OpenAI, Gemini, Hugging Face, or Ollama**.

This project is useful for learning:

- FastAPI fundamentals
- REST API development
- Request and response validation using Pydantic
- JSON-based communication
- Preparing a backend for GenAI applications

---

## Project Structure

```text
genai-fastapi-api/
├── app/
│   ├── main.py          # FastAPI application and API endpoints
│   └── models.py        # Request and response data models
├── requirements.txt     # Project dependencies
├── README.md            # Project documentation
└── .gitignore           # Ignored files and folders
```

---

## Project Workflow

```text
Start
   |
   v
Client Sends Prompt
   |
   v
POST /generate Request
   |
   v
FastAPI Receives Request
   |
   v
Pydantic Validates Input
   |
   v
Process Prompt
(Simulated GenAI Logic)
   |
   v
Create JSON Response
   |
   v
Return AI Response to Client
   |
   v
End
```

---

## Running the Project

### Create Virtual Environment

```bash
python -m venv .venv
```

### Activate Virtual Environment

#### Windows

```bash
.venv\Scripts\activate
```

#### Linux / macOS

```bash
source .venv/bin/activate
```

### Install Dependencies

```bash
pip install -r requirements.txt
```

### Start the FastAPI Server

```bash
uvicorn app.main:app --reload
```

---

## API Endpoint

### Generate AI Response

**POST** `/generate`

### Request Body

```json
{
  "prompt": "Explain FastAPI in simple words."
}
```

### Example Response

```json
{
  "prompt": "Explain FastAPI in simple words.",
  "generated_text": "AI Response: This is a simulated response for the prompt: 'Explain FastAPI in simple words.'. In a real application, this is where a Generative AI model would generate the answer."
}
```

---

## Interactive API Documentation

After starting the server, open:

```text
http://127.0.0.1:8000/docs
```

FastAPI automatically provides a **Swagger UI** where you can test the API directly from the browser.

---

## Expected Output

Terminal output:

```text
Uvicorn running on http://127.0.0.1:8000
```

Browser output at `/`:

```json
{
  "message": "GenAI FastAPI API is running"
}
```

---