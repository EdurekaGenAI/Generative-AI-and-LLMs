# Demo: Giving the Model Memory Across Turns

## Overview

Large Language Models (LLMs) are stateless by default, meaning they do not automatically remember previous interactions. To create natural, context-aware conversations, applications must maintain a conversation history and include it with every new request sent to the model.

In this project, we use the **Groq API** to build a simple conversational AI assistant that remembers information shared by the user during the current session. By storing every user message and assistant response in a conversation history, the model can reference earlier interactions and provide more coherent, personalized responses.

---

# Project Structure

```
memory-across-turns/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

---

# Project Workflow

```text
                    Start
                      │
                      ▼
           Load Environment Variables
                      │
                      ▼
        Create Groq Client & Select Model
                      │
                      ▼
      Initialize Conversation History
        (System Prompt + Empty History)
                      │
                      ▼
           Wait for User Input
                      │
                      ▼
     Add User Message to Conversation
                      │
                      ▼
 Send Complete Conversation History
        to the Groq LLM API
                      │
                      ▼
       Model Generates Response
                      │
                      ▼
 Store Assistant Response in Memory
                      │
                      ▼
 Display Response to the User
                      │
                      ▼
       Continue Conversation?
              │             │
            Yes             No
              │             │
              └──────► Exit Program
```
