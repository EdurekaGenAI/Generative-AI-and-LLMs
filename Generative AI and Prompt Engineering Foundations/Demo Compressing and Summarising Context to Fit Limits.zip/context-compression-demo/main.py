import os

from dotenv import load_dotenv
from groq import Groq

# ==========================================================
# Load Environment Variables
# ==========================================================

load_dotenv()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

MODEL = "llama-3.3-70b-versatile"

# ==========================================================
# Sample Long Context
# ==========================================================

LONG_CONTEXT = """
Artificial Intelligence applications often process large amounts of information,
including lengthy reports, research papers, documentation, meeting transcripts,
and customer conversations. Large Language Models (LLMs) can only process a
limited amount of text at once, known as the context window.

As the context grows, token usage increases significantly. This can lead to
higher API costs, slower response times, and eventually exceed the model's
maximum context limit.

One practical solution is context compression. Rather than repeatedly sending
the complete document to the model, an application first generates a concise
summary containing only the most relevant information.

This compressed summary becomes the new context for future interactions.
Although much shorter, it preserves the important ideas required for accurate
responses.

Context compression offers several advantages. It reduces token consumption,
lowers operational costs, improves inference speed, and enables applications
to work with documents that would otherwise exceed the context window.

Many real-world AI systems rely on this technique, including Retrieval-
Augmented Generation (RAG) pipelines, enterprise knowledge assistants,
customer support chatbots, legal document analysis systems, healthcare
assistants, and AI-powered search engines.

By compressing context before sending prompts to an LLM, developers can build
applications that are faster, more scalable, and capable of handling
significantly larger datasets while maintaining high-quality responses.
"""

# ==========================================================
# Compress Context
# ==========================================================


def compress_context(context):

    prompt = f"""
You are an AI assistant responsible for compressing long context.

Summarise the following document while preserving the important
information.

Guidelines:
- Keep the summary under 150 words.
- Remove unnecessary repetition.
- Preserve the key concepts.
- Produce only the summary.

Document:

{context}
"""

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0.3
    )

    return response.choices[0].message.content.strip()


# ==========================================================
# Question Answering
# ==========================================================


def answer_question(summary, question):

    prompt = f"""
You are provided with a compressed summary.

Answer the question using ONLY the information
contained in the summary.

Summary:

{summary}

Question:

{question}
"""

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0.2
    )

    return response.choices[0].message.content.strip()


# ==========================================================
# Main Program
# ==========================================================


def main():

    print("=" * 70)
    print("CONTEXT COMPRESSION & SUMMARISATION DEMO")
    print("=" * 70)

    print("\nCompressing long context...\n")

    summary = compress_context(LONG_CONTEXT)

    print("-" * 70)
    print("ORIGINAL CONTEXT")
    print("-" * 70)
    print(LONG_CONTEXT)

    print("\nOriginal Length :", len(LONG_CONTEXT), "characters")
    print("Compressed Length :", len(summary), "characters")

    reduction = (
        (len(LONG_CONTEXT) - len(summary))
        / len(LONG_CONTEXT)
    ) * 100

    print(f"Compression Achieved : {reduction:.2f}%")

    print("\n" + "=" * 70)
    print("COMPRESSED SUMMARY")
    print("=" * 70)
    print(summary)

    question = input(
        "\nEnter your question about the document: "
    )

    print("\nGenerating answer...\n")

    answer = answer_question(summary, question)

    print("=" * 70)
    print("AI RESPONSE")
    print("=" * 70)
    print(answer)


if __name__ == "__main__":
    main()