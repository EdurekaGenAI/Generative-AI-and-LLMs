# Memory-Efficient Fine-Tuning with QLoRA

## Overview

This project demonstrates **QLoRA (Quantised Low-Rank Adaptation)**, a technique for fine-tuning large language models using **4-bit quantisation** and **LoRA adapters**.

QLoRA allows models to be fine-tuned on consumer GPUs by dramatically reducing memory usage while maintaining strong performance.

---

## Project Structure

```text
qlora-memory-efficient-finetuning/
├── data/
│   └── sample_instructions.jsonl
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```


## Expected Output

```text
Map: 100%|████████████████| 4/4
...
QLoRA fine-tuning complete.
```

After training, a new folder named **qlora-adapter/** will contain the trained LoRA adapter weights.

---

## Project Workflow

```text
Load Instruction Dataset
          │
          ▼
Format Prompt and Response Pairs
          │
          ▼
Load Tokenizer
          │
          ▼
Load Base Model in 4-bit Precision
          │
          ▼
Attach QLoRA Adapters
          │
          ▼
Configure Training Arguments
          │
          ▼
Fine-Tune Lightweight Adapter Weights
          │
          ▼
Save Trained QLoRA Adapter
```

---

## Why QLoRA Is Memory Efficient

Traditional full fine-tuning updates **all model parameters**, which requires a large amount of GPU memory.

QLoRA reduces memory usage by:

| Technique | Benefit |
|-----------|---------|
| 4-bit Quantisation | Stores model weights using only 4 bits |
| Double Quantisation | Compresses quantisation statistics |
| LoRA Adapters | Trains only small low-rank matrices |
| Frozen Base Model | Avoids storing gradients for all parameters |

This makes it possible to fine-tune **billion-parameter models on GPUs with limited VRAM**.

---

## Key Configuration

### 4-bit Quantisation

```python
BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16,
)
```

### LoRA Adapter

```python
LoraConfig(
    r=8,
    lora_alpha=16,
    lora_dropout=0.05,
)
```