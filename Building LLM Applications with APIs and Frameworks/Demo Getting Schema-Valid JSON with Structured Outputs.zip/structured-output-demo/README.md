# Getting Schema-Valid JSON with Structured Outputs

## Overview

This project demonstrates how to generate **schema-valid JSON** using the **Groq API** and **Structured Outputs**.

Instead of receiving unpredictable free-form text, the model is constrained to return JSON that follows a predefined schema. This ensures that the response is reliable, machine-readable, and easy to parse in Python applications.

### What You Will Learn

- How to define a JSON schema for LLM responses
- How to request structured outputs from the Groq API
- How to generate consistent and valid JSON
- How to safely parse AI-generated JSON using Python
- How structured outputs improve reliability in automation and API workflows

---

## Project Structure

```text
structured-output-demo/
│
├── .env                # Stores the Groq API key
├── .gitignore          # Prevents sensitive and unnecessary files from being committed
├── README.md           # Project documentation
├── requirements.txt    # Python dependencies
└── main.py             # Main application file
```

---

## Project Workflow

```text
┌──────────────┐
│    Start     │
└──────┬───────┘
       │
       ▼
┌──────────────────────────┐
│ Load Environment File    │
│ (.env)                   │
└──────┬───────────────────┘
       │
       ▼
┌──────────────────────────┐
│ Initialize Groq Client   │
└──────┬───────────────────┘
       │
       ▼
┌──────────────────────────┐
│ Define JSON Schema       │
│ (fields, types, rules)   │
└──────┬───────────────────┘
       │
       ▼
┌──────────────────────────┐
│ Create User Prompt       │
└──────┬───────────────────┘
       │
       ▼
┌──────────────────────────┐
│ Send Request to Groq API │
│ with response_format     │
└──────┬───────────────────┘
       │
       ▼
┌──────────────────────────┐
│ Model Generates          │
│ Schema-Valid JSON        │
└──────┬───────────────────┘
       │
       ▼
┌──────────────────────────┐
│ Parse JSON using         │
│ json.loads()             │
└──────┬───────────────────┘
       │
       ▼
┌──────────────────────────┐
│ Pretty Print Structured  │
│ JSON Output              │
└──────┬───────────────────┘
       │
       ▼
┌──────────────┐
│     End      │
└──────────────┘
```
