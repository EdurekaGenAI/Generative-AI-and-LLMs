# Fine-Tuning a Model with LoRA on Hugging Face

## Overview

This project demonstrates **parameter-efficient fine-tuning (PEFT)** using **LoRA (Low-Rank Adaptation)** with the Hugging Face ecosystem.

Instead of updating all model weights, LoRA trains a small number of **adapter parameters**, making fine-tuning much faster and more memory efficient.

The demo uses:

* **DistilGPT-2** as the base model
* **Hugging Face Transformers**
* **PEFT (LoRA)**
* **Datasets**
* **PyTorch**

---

## Project Structure

```text
lora-finetuning-demo/
├── data/
│   └── train.jsonl
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

---
## Project Workflow

The following workflow shows the complete process for fine-tuning a Hugging Face model using **LoRA (Low-Rank Adaptation)**.

```text
Start
  │
  ▼
Create Project Folder
  │
  ▼
Prepare Training Data (JSONL)
  │
  ▼
Create Virtual Environment
  │
  ▼
Install Dependencies
  │
  ▼
Load Dataset using Hugging Face Datasets
  │
  ▼
Load Pretrained Model (DistilGPT-2)
  │
  ▼
Load Tokenizer
  │
  ▼
Apply LoRA Configuration
  │
  ▼
Freeze Base Model Weights
  │
  ▼
Tokenize Instruction–Response Data
  │
  ▼
Create Trainer and TrainingArguments
  │
  ▼
Train Only LoRA Adapter Parameters
  │
  ▼
Save LoRA Adapter Checkpoint
  │
  ▼
Load Adapter for Inference (Optional)
  │
  ▼
Generate Responses with Fine-Tuned Model
  │
  ▼
End
```

### Workflow Diagram

```text
data/train.jsonl
        │
        ▼
   datasets.load_dataset()
        │
        ▼
 AutoTokenizer
        │
        ▼
 AutoModelForCausalLM
        │
        ▼
   LoraConfig
        │
        ▼
 get_peft_model()
        │
        ▼
 Tokenisation
        │
        ▼
     Trainer
        │
        ▼
   trainer.train()
        │
        ▼
 outputs/lora-adapter/
```


## What the Script Does

### 1. Loads the Dataset

Reads the instruction-response examples from `data/train.jsonl`.

### 2. Loads the Pretrained Model

```python
AutoModelForCausalLM.from_pretrained("distilgpt2")
```

### 3. Applies LoRA

```python
LoraConfig(
    r=8,
    lora_alpha=16,
    lora_dropout=0.1
)
```

### 4. Trains Only the Adapter Parameters

The original model weights remain frozen.

### 5. Saves the LoRA Adapter

```text
outputs/lora-adapter/
```

---

## Expected Output

During training you will see logs similar to:

```text
trainable params: 294,912
all params: 81,000,000
trainable%: 0.36%

{'loss': 2.84, 'epoch': 1.0}
{'loss': 2.31, 'epoch': 2.0}
{'loss': 1.95, 'epoch': 3.0}

LoRA fine-tuning complete.
```

Notice that **less than 1% of the parameters are trained**.

---

## Why LoRA Is Useful

| Full Fine-Tuning        | LoRA                        |
| ----------------------- | --------------------------- |
| Updates all parameters  | Updates only small adapters |
| High GPU memory usage   | Low GPU memory usage        |
| Large model checkpoints | Tiny adapter checkpoints    |
| Slow training           | Faster training             |

---

## Output Directory

After training:

```text
outputs/
└── lora-adapter/
    ├── adapter_config.json
    ├── adapter_model.safetensors
    ├── tokenizer.json
    └── tokenizer_config.json
```