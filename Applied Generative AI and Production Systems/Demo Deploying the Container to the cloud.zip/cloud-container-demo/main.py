import os

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from groq import Groq

load_dotenv()

app = FastAPI(
    title="GenAI Docker Demo",
    description="A containerised Generative AI application using FastAPI and Groq",
    version="1.0.0"
)


class MessageRequest(BaseModel):
    prompt: str


@app.get("/")
def home():
    return {
        "message": "GenAI Docker API is running",
        "status": "success"
    }


@app.get("/health")
def health_check():
    return {
        "status": "healthy"
    }


@app.post("/generate")
def generate_text(request: MessageRequest):

    api_key = os.getenv("GROQ_API_KEY")

    if not api_key:
        raise HTTPException(
            status_code=500,
            detail="GROQ_API_KEY is missing"
        )

    if not request.prompt.strip():
        raise HTTPException(
            status_code=400,
            detail="Prompt cannot be empty"
        )

    try:
        client = Groq(api_key=api_key)

        response = client.chat.completions.create(
            model="openai/gpt-oss-20b",
            messages=[
                {
                    "role": "user",
                    "content": request.prompt
                }
            ],
            temperature=0.7,
            max_tokens=300
        )

        return {
            "model": "openai/gpt-oss-20b",
            "prompt": request.prompt,
            "response": response.choices[0].message.content
        }

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Groq API error: {str(error)}"
        )