# Giving a Chain Access to Tools

## Overview

This project demonstrates how to give a LangChain chain access to external tools.
The chain can call Python functions such as a calculator and a date provider while generating responses.

---

## Project Structure

```text
giving-chain-access-to-tools/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```


---

## Project Workflow

```text
User Question
       │
       ▼
LangChain Model
       │
       ▼
Check Available Tools
       │
 ┌───────────────┐
 │ Calculator    │
 │ Current Date  │
 └───────────────┘
       │
       ▼
Execute Tool
       │
       ▼
Tool Result Returned
       │
       ▼
Generate Final Answer
```