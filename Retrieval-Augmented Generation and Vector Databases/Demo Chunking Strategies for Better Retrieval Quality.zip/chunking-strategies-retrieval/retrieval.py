import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


model = SentenceTransformer("all-MiniLM-L6-v2")


def retrieve(query, chunks, top_k=2):
    chunk_embeddings = model.encode(chunks)
    query_embedding = model.encode([query])

    similarity_scores = cosine_similarity(
        query_embedding,
        chunk_embeddings
    )[0]

    ranked_indices = np.argsort(similarity_scores)[::-1][:top_k]

    results = []
    for idx in ranked_indices:
        results.append((chunks[idx], similarity_scores[idx]))

    return results