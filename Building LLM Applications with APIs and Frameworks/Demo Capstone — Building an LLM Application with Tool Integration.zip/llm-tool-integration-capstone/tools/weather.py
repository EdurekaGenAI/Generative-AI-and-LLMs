import requests


def get_weather(city: str) -> str:
    try:
        url = f"https://wttr.in/{city}?format=3"

        response = requests.get(url, timeout=10)

        if response.status_code == 200:
            return response.text

        return "Unable to fetch weather information."

    except Exception as error:
        return f"Weather service error: {error}"