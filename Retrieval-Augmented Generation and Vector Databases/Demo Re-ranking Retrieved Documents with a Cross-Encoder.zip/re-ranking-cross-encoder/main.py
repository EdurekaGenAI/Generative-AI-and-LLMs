from sentence_transformers import CrossEncoder

# --------------------------------------------------
# Sample query
# --------------------------------------------------
query = "What is deep learning?"

# --------------------------------------------------
# Documents retrieved from a first-stage retriever
# --------------------------------------------------
documents = [
    "Machine learning enables computers to learn from data.",
    "Python is a popular programming language for AI.",
    "Deep learning uses neural networks with many layers.",
    "Artificial intelligence includes machine learning and deep learning techniques."
]

# --------------------------------------------------
# Display original retrieval order
# --------------------------------------------------
print("\nOriginal Retrieved Documents:\n")
for i, doc in enumerate(documents, start=1):
    print(f"{i}. {doc}")

# --------------------------------------------------
# Load Cross-Encoder model
# --------------------------------------------------
print("\nLoading Cross-Encoder model...")

model = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")

# --------------------------------------------------
# Create (query, document) pairs
# --------------------------------------------------
pairs = [(query, doc) for doc in documents]

# --------------------------------------------------
# Predict relevance scores
# --------------------------------------------------
print("Scoring documents...")
scores = model.predict(pairs)

# --------------------------------------------------
# Combine documents with scores
# --------------------------------------------------
ranked_results = list(zip(documents, scores))

# Sort by score in descending order
ranked_results.sort(key=lambda x: x[1], reverse=True)

# --------------------------------------------------
# Display re-ranked documents
# --------------------------------------------------
print("\nRe-ranked Documents:\n")

for rank, (doc, score) in enumerate(ranked_results, start=1):
    print(f"{rank}. {doc}")
    print(f"   Relevance Score: {score:.4f}\n")

# --------------------------------------------------
# Best document
# --------------------------------------------------
best_doc, best_score = ranked_results[0]

print("Top Ranked Document:")
print(best_doc)
print(f"Score: {best_score:.4f}")