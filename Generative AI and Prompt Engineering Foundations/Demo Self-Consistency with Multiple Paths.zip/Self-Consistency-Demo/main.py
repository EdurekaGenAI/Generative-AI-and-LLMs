import os
from collections import Counter

from dotenv import load_dotenv
from groq import Groq

# -------------------------------------------------------------------
# Load Environment Variables
# -------------------------------------------------------------------

load_dotenv()

api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    raise ValueError("GROQ_API_KEY not found. Please check your .env file.")

client = Groq(api_key=api_key)

# -------------------------------------------------------------------
# Configuration
# -------------------------------------------------------------------

MODEL = "llama-3.3-70b-versatile"
NUM_REASONING_PATHS = 5
TEMPERATURE = 0.8

QUESTION = """
Roger has 5 tennis balls.

He buys 2 more cans of tennis balls.

Each can contains 3 tennis balls.

How many tennis balls does Roger have now?

Reason through the problem step by step.

At the end of your response, write exactly one line using this format:

Final Answer: <number>
"""

# -------------------------------------------------------------------
# Generate One Reasoning Path
# -------------------------------------------------------------------

def generate_reasoning_path(question):
    """Generate one independent reasoning path."""

    response = client.chat.completions.create(
        model=MODEL,
        temperature=TEMPERATURE,
        messages=[
            {
                "role": "user",
                "content": question
            }
        ]
    )

    return response.choices[0].message.content.strip()


# -------------------------------------------------------------------
# Extract Final Answer
# -------------------------------------------------------------------

def extract_final_answer(response_text):
    """Extract the final answer from the model response."""

    for line in response_text.splitlines():
        if line.strip().startswith("Final Answer:"):
            return line.split("Final Answer:")[-1].strip()

    return "Unknown"


# -------------------------------------------------------------------
# Main Program
# -------------------------------------------------------------------

def main():

    print("=" * 70)
    print("SELF-CONSISTENCY WITH MULTIPLE PATHS")
    print("=" * 70)

    collected_answers = []

    for path in range(1, NUM_REASONING_PATHS + 1):

        print(f"\nReasoning Path {path}")
        print("-" * 70)

        response = generate_reasoning_path(QUESTION)

        print(response)

        answer = extract_final_answer(response)

        print(f"\nExtracted Answer : {answer}")

        collected_answers.append(answer)

    print("\n" + "=" * 70)
    print("MAJORITY VOTING RESULTS")
    print("=" * 70)

    vote_counter = Counter(collected_answers)

    for answer, votes in vote_counter.items():
        print(f"Answer {answer:<10} -> {votes} vote(s)")

    winning_answer, winning_votes = vote_counter.most_common(1)[0]

    print("\n" + "-" * 70)
    print("Most Consistent Answer")
    print("-" * 70)
    print(f"Final Answer : {winning_answer}")
    print(f"Votes        : {winning_votes}/{NUM_REASONING_PATHS}")


if __name__ == "__main__":
    main()