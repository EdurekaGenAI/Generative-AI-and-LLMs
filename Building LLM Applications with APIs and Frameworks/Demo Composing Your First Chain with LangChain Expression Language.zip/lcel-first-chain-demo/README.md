# Composing Your First Chain with LangChain Expression Language

## Overview

This project demonstrates how to build your **first LangChain Expression Language chain** using **LangChain + Groq API**.

The chain combines:

- **Prompt Template** → formats the user input
- **Groq LLM** → generates the response
- **Output Parser** → converts the model output into plain text

LCEL allows you to connect these components using the **pipe (`|`) operator**, making chain composition simple and readable.

---

## Project Structure

```text
lcel-first-chain-demo/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

## Project Workflow

```text
+-------------+
| User Input  |
+-------------+
        |
        v
+----------------------+
| ChatPromptTemplate   |
| Format the prompt    |
+----------------------+
        |
        v
+----------------------+
| Groq Llama Model     |
| Generate response    |
+----------------------+
        |
        v
+----------------------+
| StrOutputParser      |
| Convert to text      |
+----------------------+
        |
        v
+----------------------+
| Final Output         |
+----------------------+
```