from prometheus_client import Counter, Histogram


REQUEST_COUNT = Counter(
    "genai_requests_total",
    "Total number of GenAI requests",
)

ERROR_COUNT = Counter(
    "genai_errors_total",
    "Total number of GenAI errors",
)

TOKEN_USAGE = Counter(
    "genai_tokens_total",
    "Total number of tokens consumed",
)

REQUEST_LATENCY = Histogram(
    "genai_request_latency_seconds",
    "GenAI request latency in seconds",
)