# Streaming Responses and Measuring Token Usage and Cost

## Overview

This project demonstrates how to use the **Groq API** to:

- Stream LLM responses in real time
- Display generated text token-by-token
- Measure **prompt tokens**, **completion tokens**, and **total tokens**
- Estimate the **cost of an API request**
- Understand how production AI applications monitor **latency, token usage, and operational cost**

The project is designed as a **hands-on Generative AI demo** for learning streaming APIs and token accounting.

---

## Project Structure

```text
streaming-token-usage-demo/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

### File Description

- **.env** → Stores the Groq API key securely
- **.gitignore** → Prevents secrets and virtual environment files from being committed
- **README.md** → Project documentation and workflow
- **requirements.txt** → Python dependencies required for the project
- **main.py** → Implements streaming responses, token measurement, and cost estimation

---

## Project Workflow

```text
+------------------------+
| User Prompt            |
+-----------+------------+
            |
            v
+------------------------+
| Load Environment       |
| Variables (.env)       |
+-----------+------------+
            |
            v
+------------------------+
| Initialize Groq Client |
+-----------+------------+
            |
            v
+------------------------+
| Send Streaming Request |
+-----------+------------+
            |
            v
+------------------------+
| Receive Text Chunks    |
| in Real Time           |
+-----------+------------+
            |
            v
+------------------------+
| Combine Full Response  |
+-----------+------------+
            |
            v
+------------------------+
| Estimate Prompt Tokens |
+-----------+------------+
            |
            v
+------------------------+
| Estimate Completion    |
| Tokens                 |
+-----------+------------+
            |
            v
+------------------------+
| Calculate Total Tokens |
+-----------+------------+
            |
            v
+------------------------+
| Estimate API Cost      |
+-----------+------------+
            |
            v
+------------------------+
| Display Final Report   |
+------------------------+
```