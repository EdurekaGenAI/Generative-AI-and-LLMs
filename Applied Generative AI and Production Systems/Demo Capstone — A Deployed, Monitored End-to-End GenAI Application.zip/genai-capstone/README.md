# GenAI Capstone — A Deployed and Monitored End-to-End GenAI Application

## Overview

This capstone project demonstrates how to build, containerise, run, and monitor an end-to-end Generative AI application.

The application is built with FastAPI and integrates the GPT-OSS 20B model through the Groq API. It provides a REST API where users can submit prompts and receive AI-generated responses.

The application also includes monitoring and observability using Prometheus. Key application metrics are collected during API requests, including request count, errors, token usage, and request latency.

The complete workflow combines GenAI integration, API development, Docker containerisation, and application monitoring into a single end-to-end project.

---

## Project Structure

```text
genai-capstone/
│
├── app/
│   ├── __init__.py
│   ├── main.py
│   └── metrics.py
│
├── .env
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── prometheus.yml
├── requirements.txt
└── README.md
```

### `app/`

Contains the main application source code.

### `app/main.py`

Contains the FastAPI application, API endpoints, request validation, Groq integration, health check, and Prometheus metrics endpoint.

### `app/metrics.py`

Defines the Prometheus metrics used to monitor the GenAI application.

### `.env`

Stores environment variables such as the Groq API key and model name.

The `.env` file should never be committed to a public repository.

### `.gitignore`

Specifies files and directories that should not be tracked by Git, including environment files, virtual environments, and Python cache files.

### `Dockerfile`

Defines the Docker image used to package and run the FastAPI application.

### `docker-compose.yml`

Defines and runs the FastAPI application and Prometheus monitoring service together.

### `prometheus.yml`

Contains the Prometheus configuration used to collect metrics from the FastAPI application.

### `requirements.txt`

Contains the Python dependencies required by the application.

### `README.md`

Contains the project documentation, setup instructions, architecture, workflow, and usage information.

---

## Application Architecture

The application consists of two main Docker services:

```text
┌───────────────────────┐
│        Client         │
│   Browser / Swagger   │
└───────────┬───────────┘
            │
            │ HTTP Request
            ▼
┌───────────────────────┐
│    FastAPI Service    │
│                       │
│      /generate        │
│       /health         │
│      /metrics         │
└───────────┬───────────┘
            │
            │ API Request
            ▼
┌───────────────────────┐
│       Groq API        │
│                       │
│     GPT-OSS 20B       │
└───────────┬───────────┘
            │
            │ AI Response
            ▼
┌───────────────────────┐
│    FastAPI Response   │
└───────────────────────┘

            │
            │ Metrics
            ▼

┌───────────────────────┐
│      Prometheus       │
│                       │
│ Requests              │
│ Errors                │
│ Token Usage           │
│ Latency               │
└───────────────────────┘
```

---

## Project Workflow

The project follows an end-to-end workflow from user input to monitoring.

### Step 1: User Request

A user sends a prompt through the REST API.

For example:

```json
{
  "prompt": "Explain Generative AI in simple terms.",
  "max_completion_tokens": 300,
  "temperature": 0.6,
  "reasoning_effort": "medium"
}
```

### Step 2: FastAPI Receives the Request

FastAPI receives the request through the `/generate` endpoint.

Pydantic validates the incoming request and checks parameters such as:

* Prompt length
* Maximum completion tokens
* Temperature
* Reasoning effort

### Step 3: Request Sent to Groq

After validation, the application sends the request to the Groq API.

The configured model is:

```text
openai/gpt-oss-20b
```

### Step 4: GPT-OSS 20B Generates the Response

The model processes the prompt and generates the requested response.

The response is returned to the FastAPI application.

### Step 5: Response Returned to the User

FastAPI returns the generated response along with information such as:

* Model name
* Prompt tokens
* Completion tokens
* Total tokens
* Request latency

### Step 6: Metrics Are Collected

During each request, the application records monitoring information.

The project tracks:

```text
genai_requests_total
genai_errors_total
genai_tokens_total
genai_request_latency_seconds
```

### Step 7: Prometheus Scrapes the Metrics

Prometheus periodically calls:

```text
/metrics
```

and collects the application's metrics.

### Step 8: Application Monitoring

The collected metrics can be viewed and queried through the Prometheus interface.

This makes it possible to observe:

* Request volume
* Application errors
* Token consumption
* API response latency

---

## API Endpoints

The application provides the following endpoints.

| Endpoint    | Method | Purpose                   |
| ----------- | ------ | ------------------------- |
| `/`         | GET    | Application information   |
| `/health`   | GET    | Health check              |
| `/generate` | POST   | Generate AI response      |
| `/metrics`  | GET    | Prometheus metrics        |
| `/docs`     | GET    | Swagger API documentation |

---

## Environment Configuration

Create a `.env` file in the project root:

```env
GROQ_API_KEY=your_groq_api_key_here
GROQ_MODEL=openai/gpt-oss-20b
```

Replace `your_groq_api_key_here` with your actual Groq API key.

Do not commit the `.env` file to GitHub.

---

## Local Setup

Create a Python virtual environment:

```bash
python -m venv .venv
```

Activate the environment on Windows:

```bash
.venv\Scripts\activate
```

Install the required dependencies:

```bash
pip install -r requirements.txt
```

---

## Run the Application Locally

Start the FastAPI application:

```bash
uvicorn app.main:app --reload
```

The application will be available at:

```text
http://localhost:8000
```

---

## Swagger Documentation

FastAPI automatically provides interactive API documentation.

Open:

```text
http://localhost:8000/docs
```

From Swagger, you can test the `/generate`, `/health`, and other endpoints.

---

## Generate an AI Response

Use the `/generate` endpoint.

Example request:

```json
{
  "prompt": "What is a transformer in Generative AI?",
  "max_completion_tokens": 300,
  "temperature": 0.6,
  "reasoning_effort": "medium"
}
```

The API sends the request to GPT-OSS 20B through Groq and returns the generated response.

---

## Health Check

The health endpoint can be used to verify that the application is running.

Open:

```text
http://localhost:8000/health
```

Example response:

```json
{
  "status": "healthy",
  "model": "openai/gpt-oss-20b"
}
```

---

## Monitoring

The application exposes Prometheus metrics through:

```text
http://localhost:8000/metrics
```

The main metrics include:

### Request Count

```text
genai_requests_total
```

Tracks the total number of GenAI API requests.

### Error Count

```text
genai_errors_total
```

Tracks the total number of application or generation errors.

### Token Usage

```text
genai_tokens_total
```

Tracks the total number of tokens consumed.

### Request Latency

```text
genai_request_latency_seconds
```

Measures the time required to process GenAI requests.

---

## Docker Setup

Build the Docker image:

```bash
docker build -t genai-capstone .
```

Check the created image:

```bash
docker images
```

---

## Run with Docker

Run the FastAPI application inside Docker:

```bash
docker run --env-file .env -p 8000:8000 genai-capstone
```

Open:

```text
http://localhost:8000
```

---

## Run with Docker Compose

Docker Compose is used to run the complete application stack.

Start the services:

```bash
docker compose up --build
```

This starts:

```text
FastAPI
   ↓
GenAI Application Container

Prometheus
   ↓
Monitoring Container
```

---

## Docker Services

### FastAPI Service

The FastAPI container runs the GenAI application.

```text
Container: genai-api
Port: 8000
```

### Prometheus Service

The Prometheus container collects application metrics.

```text
Container: genai-prometheus
Port: 9090
```

---

## Access the Application

After running Docker Compose, the following services are available.

### Application

```text
http://localhost:8000
```

### Swagger

```text
http://localhost:8000/docs
```

### Health Check

```text
http://localhost:8000/health
```

### Metrics

```text
http://localhost:8000/metrics
```

### Prometheus

```text
http://localhost:9090
```

---

## Prometheus Configuration

Prometheus is configured to scrape the FastAPI application every five seconds.

The target is:

```text
api:8000
```

The Docker Compose service name `api` allows Prometheus to communicate with the FastAPI container through the Docker network.

The metrics endpoint is:

```text
/metrics
```

---

## Verify Running Containers

Use:

```bash
docker ps
```

You should see the two services:

```text
genai-api
genai-prometheus
```

---

## Stop the Application

To stop the Docker Compose services:

```bash
docker compose down
```

---

## Rebuild the Application

After making changes to the source code:

```bash
docker compose down
docker compose up --build
```

---

## End-to-End Workflow

```text
┌──────────────┐
│     User     │
└──────┬───────┘
       │
       │ Prompt
       ▼
┌──────────────────┐
│     FastAPI      │
│   /generate      │
└────────┬─────────┘
         │
         │ Validated Request
         ▼
┌──────────────────┐
│    Groq API      │
│                  │
│  GPT-OSS 20B     │
└────────┬─────────┘
         │
         │ Generated Response
         ▼
┌──────────────────┐
│     FastAPI      │
└────────┬─────────┘
         │
         │ Response
         ▼
┌──────────────┐
│     User     │
└──────────────┘

         │
         │ Metrics
         ▼
┌──────────────────┐
│    Prometheus    │
│                  │
│ Requests         │
│ Errors           │
│ Tokens           │
│ Latency          │
└──────────────────┘
```

---

## Deployment Workflow

The capstone is designed to support the following deployment lifecycle:

```text
Development
     ↓
Local Testing
     ↓
FastAPI Application
     ↓
Docker Containerisation
     ↓
Docker Compose
     ↓
Prometheus Monitoring
     ↓
Cloud Deployment
     ↓
Production Monitoring
```

---

## Error Handling

The application handles errors during GenAI requests and records them using Prometheus.

If an error occurs, the API returns an appropriate HTTP error response.

Errors are also counted through:

```text
genai_errors_total
```

This allows application failures to be monitored instead of silently ignored.

---

## Observability

The application provides basic observability through four important metrics:

```text
Request Volume
      ↓
How many requests are being received?

Error Rate
      ↓
How many requests are failing?

Token Usage
      ↓
How many tokens are being consumed?

Latency
      ↓
How long are requests taking?
```

These metrics provide a foundation for monitoring a production GenAI application.

---

## Security Considerations

The Groq API key is stored in the `.env` file instead of directly inside the source code.

The `.env` file is excluded through `.gitignore`.

For production deployment, secrets should be stored using a secure cloud secret-management solution rather than committing credentials to source control.

---

## Final Capstone Architecture

```text
                    ┌──────────────┐
                    │     User     │
                    └──────┬───────┘
                           │
                           ▼
                ┌────────────────────┐
                │   FastAPI / Docker │
                │                    │
                │    GenAI API       │
                └─────────┬──────────┘
                          │
                          ▼
                ┌────────────────────┐
                │      Groq API      │
                │                    │
                │    GPT-OSS 20B     │
                └─────────┬──────────┘
                          │
                          ▼
                ┌────────────────────┐
                │  Generated Output  │
                └────────────────────┘

                          │
                          │ Metrics
                          ▼

                ┌────────────────────┐
                │    Prometheus      │
                │                    │
                │  Requests          │
                │  Errors            │
                │  Tokens            │
                │  Latency           │
                └────────────────────┘
```

---