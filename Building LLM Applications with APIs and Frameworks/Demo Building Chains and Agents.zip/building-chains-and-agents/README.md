# Building Chains and Agents

This project demonstrates the difference between a **LangChain Chain** and a **LangChain Agent** using the **Groq API**.

## Overview

- Build a simple **LLM Chain**
- Create **custom tools**
- Build an **AI Agent** that automatically selects tools
- Understand the difference between **Chains** and **Agents**

---

## Project Structure

```text
building-chains-and-agents/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

---

## Project Workflow

```text
User Input
    │
    ▼
LangChain Chain
    │
    ▼
LLM Response


User Query
    │
    ▼
LangChain Agent
    │
    ├── Calculator Tool
    └── Weather Tool
            │
            ▼
      Final Response
```