import time
import numpy as np
import faiss

# --------------------------------------------------
# Generate sample vectors
# --------------------------------------------------

num_vectors = 1000
dimension = 64

np.random.seed(42)

vectors = np.random.random((num_vectors, dimension)).astype(np.float32)

# --------------------------------------------------
# Build IVF index
# --------------------------------------------------

nlist = 20

quantizer = faiss.IndexFlatL2(dimension)

index = faiss.IndexIVFFlat(
    quantizer,
    dimension,
    nlist,
    faiss.METRIC_L2
)

# --------------------------------------------------
# Train the index
# --------------------------------------------------

index.train(vectors)
index.add(vectors)

print("IVF Index trained")

# --------------------------------------------------
# Tune search parameter
# --------------------------------------------------

index.nprobe = 5

# --------------------------------------------------
# Query vector
# --------------------------------------------------

query = np.random.random((1, dimension)).astype(np.float32)

start = time.time()

distances, indices = index.search(query, 5)

end = time.time()

# --------------------------------------------------
# Display results
# --------------------------------------------------

print("Top 5 nearest neighbours:")

for idx, dist in zip(indices[0], distances[0]):
    print(f"ID: {idx}  Distance: {dist:.4f}")

print(f"Search time: {(end - start) * 1000:.2f} ms")