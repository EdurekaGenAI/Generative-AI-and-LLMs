# Chunking Strategies for Better Retrieval Quality

## Overview

This project demonstrates how different **chunking strategies** affect retrieval quality in Retrieval-Augmented Generation (RAG) systems. It compares:

- Fixed-size chunking
- Sentence-based chunking
- Overlapping chunking

The project generates embeddings for each chunk, compares them with a user query, and retrieves the most relevant chunks using **cosine similarity**.

---

## Project Structure

```text
chunking-strategies-retrieval/
│
├── .gitignore
├── README.md
├── requirements.txt
├── main.py
├── chunking.py
├── retrieval.py
└── sample_document.txt
```

---

## Project Workflow

```text
Input Document
      │
      ▼
Chunking Strategies
 ├── Fixed-size
 ├── Sentence-based
 └── Overlapping
      │
      ▼
Generate Embeddings
      │
      ▼
User Query Embedding
      │
      ▼
Cosine Similarity
      │
      ▼
Retrieve Top Relevant Chunks
```

