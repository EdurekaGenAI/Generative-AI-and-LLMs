import os
import warnings

# -----------------------------------------------------------------------------
# Suppress Hugging Face warnings and unnecessary console messages
# -----------------------------------------------------------------------------
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN_WARNING"] = "1"
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

warnings.filterwarnings("ignore")


# -----------------------------------------------------------------------------
# Import required libraries
# -----------------------------------------------------------------------------
import numpy as np
from sentence_transformers import SentenceTransformer


# -----------------------------------------------------------------------------
# Utility function: cosine similarity
# -----------------------------------------------------------------------------
def cosine_similarity(vector_a, vector_b):
    """Compute cosine similarity between two embedding vectors."""
    return np.dot(vector_a, vector_b) / (
        np.linalg.norm(vector_a) * np.linalg.norm(vector_b)
    )


# -----------------------------------------------------------------------------
# Utility function: display embedding information
# -----------------------------------------------------------------------------
def display_embedding_info(index, text, embedding):
    """Print embedding details in a clean format."""
    print(f"Text {index}: {text}")
    print(f"Embedding dimension: {len(embedding)}")
    print(f"First 10 values: {np.round(embedding[:10], 4)}")
    print()


# -----------------------------------------------------------------------------
# Main application
# -----------------------------------------------------------------------------
def main():
    print("Text Embedding Generation Demo")
    print("=" * 60)

    # Load embedding model
    print("\nLoading embedding model...")

    model = SentenceTransformer("all-MiniLM-L6-v2")

    # Sample sentences
    texts = [
        "Artificial Intelligence is transforming education.",
        "Machine learning enables computers to learn from data.",
        "I enjoy playing football on weekends."
    ]

    # Generate embeddings
    print("Generating embeddings...\n")

    embeddings = model.encode(
        texts,
        show_progress_bar=False
    )

    # Display embedding details
    print("Embedding Details")
    print("-" * 60)

    for i, (text, embedding) in enumerate(zip(texts, embeddings), start=1):
        display_embedding_info(i, text, embedding)

    # Compute similarities
    similarity_ai_ml = cosine_similarity(embeddings[0], embeddings[1])
    similarity_ai_football = cosine_similarity(embeddings[0], embeddings[2])

    # Display similarity results
    print("Similarity Results")
    print("-" * 60)
    print(f"AI vs Machine Learning : {similarity_ai_ml:.4f}")
    print(f"AI vs Football         : {similarity_ai_football:.4f}")

    # Interpretation section
    print("\nInterpretation")
    print("-" * 60)
    print("• Higher similarity indicates semantically related text.")
    print("• Lower similarity indicates semantically unrelated text.")
    print("• Embeddings capture semantic meaning rather than simple keyword matching.")

    print("\nDemo completed successfully.")


# -----------------------------------------------------------------------------
# Entry point
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    main()