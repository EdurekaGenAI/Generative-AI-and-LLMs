import re


def fixed_size_chunks(text, size=180):
    return [
        text[i:i + size].strip()
        for i in range(0, len(text), size)
    ]


def sentence_based_chunks(text, max_sentences=2):
    sentences = re.split(r'(?<=[.!?])\\s+', text.strip())
    chunks = []

    for i in range(0, len(sentences), max_sentences):
        chunk = " ".join(sentences[i:i + max_sentences]).strip()
        if chunk:
            chunks.append(chunk)

    return chunks


def overlapping_chunks(text, size=180, overlap=50):
    chunks = []
    start = 0

    while start < len(text):
        end = start + size
        chunk = text[start:end].strip()

        if chunk:
            chunks.append(chunk)

        start += size - overlap

    return chunks