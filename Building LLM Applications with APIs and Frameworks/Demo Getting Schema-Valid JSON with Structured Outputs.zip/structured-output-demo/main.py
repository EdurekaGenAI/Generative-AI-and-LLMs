import json
import os
from dotenv import load_dotenv
from groq import Groq

# --------------------------------------------------
# Load environment variables
# --------------------------------------------------
load_dotenv()

api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    raise ValueError("GROQ_API_KEY not found in .env file")

client = Groq(api_key=api_key)


# --------------------------------------------------
# JSON Schema Definition
# --------------------------------------------------
profile_schema = {
    "type": "object",
    "properties": {
        "name": {
            "type": "string",
            "description": "Full name of the candidate"
        },
        "role": {
            "type": "string",
            "description": "Current job role"
        },
        "skills": {
            "type": "array",
            "items": {
                "type": "string"
            },
            "description": "List of technical skills"
        },
        "experience_years": {
            "type": "integer",
            "description": "Total years of professional experience"
        },
        "available_for_remote": {
            "type": "boolean",
            "description": "Whether the candidate is available for remote work"
        }
    },
    "required": [
        "name",
        "role",
        "skills",
        "experience_years",
        "available_for_remote"
    ]
}


# --------------------------------------------------
# User Prompt
# --------------------------------------------------
prompt = """
Create a realistic AI Software Engineer profile for a modern technology company.

The profile must include:
- Full name
- Job role
- 4 to 6 relevant technical skills
- Years of experience
- Remote work availability

Return ONLY valid JSON matching the provided schema.
Do not include markdown, explanations, headings, or extra text.
"""


# --------------------------------------------------
# Generate Structured Output
# --------------------------------------------------
print("Generating schema-valid JSON...\n")

response = client.chat.completions.create(
    model="openai/gpt-oss-120b",
    messages=[
        {
            "role": "system",
            "content": (
                "You are a strict JSON generator. "
                "Always return syntactically valid JSON only. "
                "Do not return markdown code blocks, comments, or explanations."
            )
        },
        {
            "role": "user",
            "content": prompt
        }
    ],
    response_format={
        "type": "json_schema",
        "json_schema": {
            "name": "ai_engineer_profile",
            "schema": profile_schema
        }
    },
    temperature=0.3,
    max_completion_tokens=300
)


# --------------------------------------------------
# Parse and Validate JSON
# --------------------------------------------------
try:
    structured_data = json.loads(response.choices[0].message.content)

    print("Schema-valid JSON generated successfully:\n")
    print(json.dumps(structured_data, indent=4))

except json.JSONDecodeError as error:
    print("Failed to parse JSON:")
    print(error)