import os

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from groq import Groq

load_dotenv()

app = FastAPI(
    title="GenAI Docker Demo",
    description="A containerised Generative AI application using Groq",
    version="1.0.0"
)

groq_api_key = os.getenv("GROQ_API_KEY")

if not groq_api_key:
    raise RuntimeError("GROQ_API_KEY is not configured.")

client = Groq(api_key=groq_api_key)


class PromptRequest(BaseModel):
    prompt: str


@app.get("/")
def home():
    return {
        "message": "GenAI application is running inside Docker."
    }


@app.get("/health")
def health():
    return {
        "status": "healthy"
    }


@app.post("/generate")
def generate_text(request: PromptRequest):

    if not request.prompt.strip():
        raise HTTPException(
            status_code=400,
            detail="Prompt cannot be empty."
        )

    try:
        response = client.chat.completions.create(
            model="openai/gpt-oss-20b",
            messages=[
                {
                    "role": "user",
                    "content": request.prompt
                }
            ],
            temperature=0.7,
            max_tokens=300
        )

        generated_text = response.choices[0].message.content

        return {
            "prompt": request.prompt,
            "response": generated_text
        }

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Generation failed: {str(error)}"
        )