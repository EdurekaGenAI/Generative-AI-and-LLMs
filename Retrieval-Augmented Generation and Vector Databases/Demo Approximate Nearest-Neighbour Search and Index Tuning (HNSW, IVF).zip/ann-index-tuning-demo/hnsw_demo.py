import time
import numpy as np
import hnswlib

# --------------------------------------------------
# Generate sample vectors
# --------------------------------------------------

num_vectors = 1000
dimension = 64

np.random.seed(42)

vectors = np.random.random((num_vectors, dimension)).astype(np.float32)

# --------------------------------------------------
# Create HNSW index
# --------------------------------------------------

index = hnswlib.Index(space="l2", dim=dimension)

index.init_index(
    max_elements=num_vectors,
    ef_construction=200,
    M=16
)

index.add_items(vectors)

# --------------------------------------------------
# Tune search parameter
# --------------------------------------------------

index.set_ef(50)

print("HNSW Index created")

# --------------------------------------------------
# Query vector
# --------------------------------------------------

query = np.random.random((1, dimension)).astype(np.float32)

start = time.time()

labels, distances = index.knn_query(query, k=5)

end = time.time()

# --------------------------------------------------
# Display results
# --------------------------------------------------

print("Top 5 nearest neighbours:")

for idx, dist in zip(labels[0], distances[0]):
    print(f"ID: {idx}  Distance: {dist:.4f}")

print(f"Search time: {(end - start) * 1000:.2f} ms")