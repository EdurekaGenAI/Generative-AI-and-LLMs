# Managing Conversation Memory with LangChain

This project demonstrates how to maintain **conversation memory** in a LangChain application using **Groq Llama 3.3 70B**. The chatbot remembers previous user messages and uses them as context for future responses.

---

## Overview

This demo shows how to:

- Build a conversational chatbot with **LangChain**
- Use **Groq** as the LLM provider
- Store user and AI messages in memory
- Maintain context across multiple conversation turns
- Create a simple memory-enabled AI assistant

---

## Project Structure

```text
managing-conversation-memory/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```


## Project Workflow

```text
Start Application
        |
        v
Load Environment Variables
        |
        v
Initialize Groq LLM
        |
        v
Create Conversation Memory
        |
        v
Receive User Message
        |
        v
Store User Message
        |
        v
Send Full Conversation to LLM
        |
        v
Generate AI Response
        |
        v
Store AI Response
        |
        v
Display Response
        |
        v
Continue Until User Types 'exit'
```