# Exposing Python Functions to a Model with Tool Calling

## Overview

This project demonstrates **Tool Calling (Function Calling)** using the **Groq API**.
The model can decide when to call a Python function, pass structured arguments, and use the returned result to generate a final natural-language response.

In this demo, Python functions are exposed to the model so that it can interact with external logic safely and in a controlled way.

### Features

- Expose Python functions as **tools**
- Allow the model to choose a tool automatically
- Pass structured JSON arguments to Python functions
- Execute the function locally
- Return the function output back to the model
- Generate a final user-friendly response

---

## Project Structure

```text
tool-calling-demo/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

### File Description

| File | Purpose |
|------|---------|
| `.env` | Stores the Groq API key securely |
| `.gitignore` | Prevents sensitive and unnecessary files from being committed |
| `README.md` | Project documentation |
| `requirements.txt` | Python dependencies |
| `main.py` | Main application containing tool definitions and execution logic |

---

## Project Workflow

```text
┌────────────────────┐
│   User Question    │
└─────────┬──────────┘
          │
          ▼
┌────────────────────┐
│ Send Prompt to LLM │
└─────────┬──────────┘
          │
          ▼
┌────────────────────────────┐
│ LLM Detects Required Tool │
└─────────┬──────────────────┘
          │
          ▼
┌────────────────────────────┐
│ Extract Tool Arguments    │
└─────────┬──────────────────┘
          │
          ▼
┌────────────────────────────┐
│ Execute Python Function   │
└─────────┬──────────────────┘
          │
          ▼
┌────────────────────────────┐
│ Return Tool Result to LLM│
└─────────┬──────────────────┘
          │
          ▼
┌────────────────────────────┐
│ Generate Final Response  │
└─────────┬──────────────────┘
          │
          ▼
┌────────────────────────────┐
│     Display to User      │
└────────────────────────────┘
```