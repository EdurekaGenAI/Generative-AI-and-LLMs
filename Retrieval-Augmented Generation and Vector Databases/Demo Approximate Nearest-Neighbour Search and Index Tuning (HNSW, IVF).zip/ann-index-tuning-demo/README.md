# Approximate Nearest-Neighbour Search and Index Tuning (HNSW, IVF)

## Overview

This project demonstrates **Approximate Nearest-Neighbour (ANN) search** using two popular indexing techniques:

- **HNSW** (Hierarchical Navigable Small World)
- **IVF** (Inverted File Index)

These indexes are commonly used in **vector databases**, **semantic search**, **recommendation systems**, and **Retrieval-Augmented Generation (RAG)** pipelines.

---

## Project Structure

```
ann-index-tuning-demo/
├── data/
│   └── sample_vectors.csv
├── hnsw_demo.py
├── ivf_demo.py
├── requirements.txt
├── README.md
└── .gitignore
```
## Project Workflow

          ┌──────────────────────┐
          │  Generate Vectors    │
          │ (NumPy sample data)   │
          └──────────┬───────────┘
                     │
                     ▼
          ┌──────────────────────┐
          │   Build ANN Index    │
          │   HNSW or IVF         │
          └──────────┬───────────┘
                     │
                     ▼
          ┌──────────────────────┐
          │   Train Index (IVF)  │
          │  or Create Graph      │
          │      (HNSW)           │
          └──────────┬───────────┘
                     │
                     ▼
          ┌──────────────────────┐
          │    Add All Vectors   │
          │    to the Index       │
          └──────────┬───────────┘
                     │
                     ▼
          ┌──────────────────────┐
          │   Tune Search Params │
          │ ef_search / nprobe   │
          └──────────┬───────────┘
                     │
                     ▼
          ┌──────────────────────┐
          │    Create Query      │
          │      Vector           │
          └──────────┬───────────┘
                     │
                     ▼
          ┌──────────────────────┐
          │ Perform ANN Search   │
          │   Retrieve Top-K      │
          └──────────┬───────────┘
                     │
                     ▼
          ┌──────────────────────┐
          │ Measure Latency      │
          │ and Compare Results   │
          └──────────────────────┘
---

## Create Virtual Environment

### Windows

```bash
python -m venv .venv
.venv\\Scripts\\activate
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
```

---

## Install Dependencies

```bash
pip install -r requirements.txt
```

---

## Run the HNSW Demo

```bash
python hnsw_demo.py
```

---

## Run the IVF Demo

```bash
python ivf_demo.py
```

---

## Example Output

### HNSW

```text
HNSW Index created
Top 5 nearest neighbours:
ID: 42  Distance: 0.1842
ID: 91  Distance: 0.2011
Search time: 0.42 ms
```

### IVF

```text
IVF Index trained
Top 5 nearest neighbours:
ID: 42  Distance: 0.1842
ID: 91  Distance: 0.2011
Search time: 0.31 ms
```

---

## Important Parameters

### HNSW

| Parameter | Purpose |
|-----------|---------|
| `M` | Controls graph connectivity |
| `ef_construction` | Improves index build quality |
| `ef_search` | Improves recall during search |

### IVF

| Parameter | Purpose |
|-----------|---------|
| `nlist` | Number of vector clusters |
| `nprobe` | Number of clusters searched |

---

## Suggested Experiments

### Increase HNSW accuracy

```python
index.set_ef(100)
```

### Faster HNSW search

```python
index.set_ef(20)
```

### Improve IVF recall

```python
index.nprobe = 10
```

### Increase IVF partitioning

```python
nlist = 50
```

Observe how **search latency** changes compared to the **retrieved neighbours**.

---

## When to Use Each Index

| Dataset Size | Recommended Index |
|--------------|------------------|
| < 100K vectors | Flat search |
| 100K – 10M | HNSW |
| 10M – 100M | IVF |
| 100M+ | IVF + Product Quantization (PQ) |

---
