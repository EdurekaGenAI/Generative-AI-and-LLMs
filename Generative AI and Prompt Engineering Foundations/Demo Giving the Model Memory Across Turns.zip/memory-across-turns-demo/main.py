import os

from dotenv import load_dotenv
from groq import Groq

# -------------------------------------------------------------------
# Load Environment Variables
# -------------------------------------------------------------------

load_dotenv()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

MODEL = "llama-3.3-70b-versatile"

# -------------------------------------------------------------------
# System Prompt
# -------------------------------------------------------------------

SYSTEM_PROMPT = """
You are a helpful AI assistant.

You remember information only from the current conversation by using
the conversation history provided to you.

Whenever the user shares personal information, acknowledge it naturally.

If the user later asks about something they shared earlier,
answer using the previous conversation.

Never claim to remember conversations from previous sessions.

Be conversational, friendly, and concise.
"""

conversation = [
    {
        "role": "system",
        "content": SYSTEM_PROMPT
    }
]

# -------------------------------------------------------------------
# Header
# -------------------------------------------------------------------

print("=" * 70)
print("PROMPT ENGINEERING DEMO")
print("Giving the Model Memory Across Turns")
print("=" * 70)

print("\nThis chatbot remembers information during the current session.")
print("Type 'exit' anytime to quit.\n")

# -------------------------------------------------------------------
# Conversation Loop
# -------------------------------------------------------------------

while True:

    user_input = input("You: ").strip()

    if user_input.lower() == "exit":
        print("\nThank you for trying the demo!")
        break

    conversation.append(
        {
            "role": "user",
            "content": user_input
        }
    )

    try:

        response = client.chat.completions.create(
            model=MODEL,
            messages=conversation,
            temperature=0.6,
            max_tokens=300
        )

        assistant_reply = response.choices[0].message.content

        print(f"\nAssistant: {assistant_reply}\n")

        conversation.append(
            {
                "role": "assistant",
                "content": assistant_reply
            }
        )

    except Exception as e:
        print(f"\nError: {e}\n")