import json
from pathlib import Path
from datetime import datetime


class InstructionDatasetPreparer:
    """
    Professional utility for preparing instruction-tuning datasets
    for supervised fine-tuning of Large Language Models (LLMs).
    """

    def __init__(self, input_file: str, output_file: str):
        self.input_path = Path(input_file)
        self.output_path = Path(output_file)

    # --------------------------------------------------
    # Load raw examples
    # --------------------------------------------------
    def load_examples(self):
        if not self.input_path.exists():
            raise FileNotFoundError(
                f"Input file not found: {self.input_path}"
            )

        with open(self.input_path, "r", encoding="utf-8") as file:
            data = json.load(file)

        if not isinstance(data, list):
            raise ValueError("Dataset must contain a list of examples.")

        return data

    # --------------------------------------------------
    # Validate a single example
    # --------------------------------------------------
    @staticmethod
    def validate_example(example, index):
        required_fields = ["instruction", "input", "output"]

        for field in required_fields:
            if field not in example:
                raise ValueError(
                    f"Missing field '{field}' in example #{index}"
                )

    # --------------------------------------------------
    # Convert examples into instruction-tuning format
    # --------------------------------------------------
    def format_examples(self, examples):
        formatted_dataset = []

        for idx, item in enumerate(examples, start=1):
            self.validate_example(item, idx)

            prompt = f"""### Instruction:
{item['instruction']}

### Input:
{item['input']}

### Response:"""

            formatted_dataset.append(
                {
                    "prompt": prompt.strip(),
                    "response": item["output"].strip(),
                    "metadata": {
                        "example_id": idx,
                        "created_at": datetime.utcnow().isoformat() + "Z",
                    },
                }
            )

        return formatted_dataset

    # --------------------------------------------------
    # Save formatted dataset
    # --------------------------------------------------
    def save_dataset(self, dataset):
        with open(self.output_path, "w", encoding="utf-8") as file:
            json.dump(dataset, file, indent=2, ensure_ascii=False)

    # --------------------------------------------------
    # Display dataset statistics
    # --------------------------------------------------
    @staticmethod
    def show_statistics(dataset):
        total_examples = len(dataset)

        avg_prompt_length = sum(
            len(item["prompt"]) for item in dataset
        ) / total_examples

        avg_response_length = sum(
            len(item["response"]) for item in dataset
        ) / total_examples

        print("\nDATASET STATISTICS")
        print("-" * 40)
        print(f"Total examples        : {total_examples}")
        print(f"Average prompt length : {avg_prompt_length:.1f} characters")
        print(f"Average response length: {avg_response_length:.1f} characters")

    # --------------------------------------------------
    # Execute complete workflow
    # --------------------------------------------------
    def run(self):
        print("Starting instruction-tuning dataset preparation...")

        examples = self.load_examples()
        print(f"Loaded {len(examples)} raw examples.")

        formatted_dataset = self.format_examples(examples)
        print("Examples formatted successfully.")

        self.save_dataset(formatted_dataset)
        print(f"Formatted dataset saved to: {self.output_path}")

        self.show_statistics(formatted_dataset)

        print("\nSample formatted example:")
        print("-" * 40)
        print(json.dumps(formatted_dataset[0], indent=2, ensure_ascii=False))

        print("\nInstruction-tuning dataset preparation completed successfully.")


if __name__ == "__main__":
    preparer = InstructionDatasetPreparer(
        input_file="data/raw_examples.json",
        output_file="instruction_dataset.json",
    )

    preparer.run()