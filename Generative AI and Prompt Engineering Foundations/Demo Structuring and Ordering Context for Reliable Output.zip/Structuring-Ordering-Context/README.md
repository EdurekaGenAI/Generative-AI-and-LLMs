# Structuring and Ordering Context for Reliable Output

## Overview

Large Language Models (LLMs) perform best when the information they receive is organised logically. A prompt that mixes instructions, context, and constraints together can lead to inconsistent or incomplete responses. By structuring the prompt into clearly defined sections, the model can better understand the task, identify the relevant information, and generate more reliable outputs.

In this project, you will compare two approaches to prompting:

- **Unstructured Prompt:** Context and instructions are provided as plain text without any organisation.
- **Structured Prompt:** Information is organised into sections such as **Role**, **Task**, **Customer Details**, **Company Policy**, **Customer Question**, and **Response Guidelines**.

By comparing the responses generated from these two prompts, you will observe how prompt structure influences the quality, clarity, and consistency of LLM outputs.

---

# Project Structure

```text
Structuring-Ordering-Context/
│
├── .env                 # Stores the Groq API key
├── .gitignore           # Files and folders ignored by Git
├── README.md            # Project documentation
├── requirements.txt     # Project dependencies
└── main.py              # Main application
```

---

# Project Workflow

```text
                    Start
                      │
                      ▼
          Load Environment Variables
                      │
                      ▼
             Initialise Groq Client
                      │
                      ▼
        Create Unstructured Prompt
                      │
                      ▼
        Send Prompt to Groq API
                      │
                      ▼
       Display Unstructured Response
                      │
                      ▼
         Create Structured Prompt
                      │
                      ▼
        Send Prompt to Groq API
                      │
                      ▼
        Display Structured Response
                      │
                      ▼
      Compare the Two Responses
                      │
                      ▼
     Observe Improvements in Output
                      │
                      ▼
                     End
```