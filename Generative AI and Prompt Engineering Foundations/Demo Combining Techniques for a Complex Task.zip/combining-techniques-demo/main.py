import os
from dotenv import load_dotenv
from groq import Groq

# ==========================================================
# Load Environment Variables
# ==========================================================

load_dotenv()

api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    raise ValueError(
        "GROQ_API_KEY not found. Please add it to your .env file."
    )

client = Groq(api_key=api_key)

MODEL = "llama-3.3-70b-versatile"

# ==========================================================
# Job Description
# ==========================================================

JOB_DESCRIPTION = """
Position: Software Development Engineer

Required Skills:
- Python
- Java
- SQL
- Data Structures & Algorithms
- REST APIs
- Git & GitHub
- AWS
- Docker
- Kubernetes
- CI/CD
- Problem Solving

Experience:
3+ years

Responsibilities:
- Design scalable backend systems.
- Develop REST APIs.
- Work with cloud infrastructure.
- Collaborate with cross-functional teams.
- Write clean, maintainable code.
"""

# ==========================================================
# Candidate Resume
# ==========================================================

CANDIDATE_RESUME = """
Name: John Smith

Experience:
4 years as Full Stack Developer

Technical Skills:
- Python
- Java
- SQL
- JavaScript
- React
- REST APIs
- AWS
- Docker
- Git
- Linux

Projects:

AI Search Engine
Built an AI-powered search engine using Python,
FastAPI, OpenAI APIs and Redis.

Inventory Management System
Developed backend REST APIs using Python,
PostgreSQL and Docker.

Certifications:
AWS Cloud Practitioner

Achievements:
Employee of the Quarter
"""

# ==========================================================
# Combined Prompt Engineering Prompt
# ==========================================================

PROMPT = f"""
You are a Senior Technical Recruiter with more than 15 years of hiring experience
at top technology companies.

############################################################
ROLE
############################################################

Act as an expert recruiter who evaluates software engineering
candidates objectively.

############################################################
TASK
############################################################

Your task is to evaluate the candidate against the job description.

Use the following techniques while solving the task:

1. Carefully understand the Job Description.
2. Carefully analyse the Resume.
3. Think step-by-step before producing the final answer.
4. Compare every required skill.
5. Compare the experience.
6. Identify strengths.
7. Identify weaknesses.
8. Suggest whether the candidate should be interviewed.

############################################################
FEW SHOT EXAMPLE
############################################################

Job:

Python Developer

Required Skills

Python
SQL
Docker

Resume

Python
SQL
JavaScript

Expected Evaluation

Technical Match: 67%

Missing Skills:
- Docker

Recommendation:
Shortlist

Reason:
Strong Python knowledge with one missing skill.

############################################################
JOB DESCRIPTION
############################################################

{JOB_DESCRIPTION}

############################################################
CANDIDATE RESUME
############################################################

{CANDIDATE_RESUME}

############################################################
OUTPUT FORMAT
############################################################

Return ONLY this format.

==================================================
AI RESUME SCREENING REPORT
==================================================

Candidate Name:

Overall Match Score:

Technical Skills Match:

Experience Match:

Matching Skills:

Missing Skills:

Strengths:

Weaknesses:

Interview Recommendation:

Hiring Decision:

Reasoning:

Learning Suggestions:
"""

# ==========================================================
# Send Request
# ==========================================================

print("=" * 70)
print("COMBINING PROMPT ENGINEERING TECHNIQUES")
print("=" * 70)
print("\nEvaluating Candidate...\n")

response = client.chat.completions.create(
    model=MODEL,
    temperature=0.2,
    messages=[
        {
            "role": "system",
            "content": (
                "You are an expert Technical Recruiter. "
                "Always analyse carefully and provide professional evaluations."
            )
        },
        {
            "role": "user",
            "content": PROMPT
        }
    ]
)

# ==========================================================
# Output
# ==========================================================

print(response.choices[0].message.content)