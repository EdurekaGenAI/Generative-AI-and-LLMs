from dotenv import load_dotenv
from langchain_core.tools import tool
from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage, ToolMessage
from datetime import datetime

# Load environment variables
load_dotenv()

# -----------------------------
# Tool Definitions
# -----------------------------

@tool
def calculator(expression: str) -> str:
    """Evaluate a mathematical expression."""
    try:
        result = eval(expression)
        return str(result)
    except Exception as e:
        return f"Error: {e}"


@tool
def current_date(_: str = "") -> str:
    """Return today's date."""
    return datetime.now().strftime("%Y-%m-%d")


tools = [calculator, current_date]

# -----------------------------
# Create LLM
# -----------------------------

llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    temperature=0
)

# Give the model access to tools
llm_with_tools = llm.bind_tools(tools)

# -----------------------------
# User Question
# -----------------------------

question = "What is 25 * 18 + 42?"

print(f"Question: {question}\\n")

messages = [HumanMessage(content=question)]

# First response from the model
response = llm_with_tools.invoke(messages)
messages.append(response)

# -----------------------------
# Execute Tool Calls
# -----------------------------

if response.tool_calls:
    for tool_call in response.tool_calls:

        tool_name = tool_call["name"]
        tool_args = tool_call["args"]

        # Find the matching tool
        selected_tool = next(t for t in tools if t.name == tool_name)

        # Execute the tool
        result = selected_tool.invoke(tool_args)

        print(f"Tool Used: {tool_name}")
        print(f"Tool Result: {result}\\n")

        # Add tool result back to conversation
        messages.append(
            ToolMessage(
                content=result,
                tool_call_id=tool_call["id"]
            )
        )

    # Final response after tool execution
    final_response = llm_with_tools.invoke(messages)

    print("Final Answer:")
    print(final_response.content)

else:
    print("Answer:")
    print(response.content)