import os
from dotenv import load_dotenv
from groq import Groq

# --------------------------------------------------
# Load Environment Variables
# --------------------------------------------------
load_dotenv()

api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    raise ValueError("GROQ_API_KEY not found. Please check your .env file.")

# --------------------------------------------------
# Create Groq Client
# --------------------------------------------------
client = Groq(api_key=api_key)

MODEL = "llama-3.3-70b-versatile"


# --------------------------------------------------
# Function to Generate LLM Response
# --------------------------------------------------
def generate_response(prompt):
    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0.3
        )

        return response.choices[0].message.content.strip()

    except Exception as error:
        return f"Error: {error}"


# --------------------------------------------------
# Main Function
# --------------------------------------------------
def main():

    question = (
        "A shopkeeper buys an item for ₹800 and sells it for ₹960. "
        "What is the profit percentage?"
    )

    print("=" * 80)
    print("DEMO: COMPARING DIRECT AND CHAIN-OF-THOUGHT ANSWERS")
    print("=" * 80)

    print("\nQuestion:")
    print(question)

    # --------------------------------------------------
    # Direct Prompt
    # --------------------------------------------------
    direct_prompt = f"""
Answer the following question.

Rules:
- Give only the final answer.
- Do not explain your reasoning.
- Respond in plain text.

Question:
{question}
"""

    print("\n" + "=" * 80)
    print("DIRECT PROMPT RESPONSE")
    print("=" * 80)

    direct_answer = generate_response(direct_prompt)
    print(direct_answer)

    # --------------------------------------------------
    # Chain-of-Thought Style Prompt
    # --------------------------------------------------
    cot_prompt = f"""
Solve the following problem.

Rules:
- Explain the calculation briefly.
- Show the important steps.
- End with "Final Answer:".
- Respond in plain text only.

Question:
{question}
"""

    print("\n" + "=" * 80)
    print("CHAIN-OF-THOUGHT STYLE RESPONSE")
    print("=" * 80)

    cot_answer = generate_response(cot_prompt)
    print(cot_answer)


if __name__ == "__main__":
    main()