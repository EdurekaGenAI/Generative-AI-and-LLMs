# Query Transformation — Rewriting, Multi-Query, and HyDE

## Overview

This project demonstrates three important **query transformation techniques** used in **Retrieval-Augmented Generation (RAG)** systems.

### Techniques Covered

* **Query Rewriting** — rewrites a user question into a clearer and more searchable form.
* **Multi-Query Retrieval** — generates multiple semantic variations of the same question to improve document recall.
* **HyDE (Hypothetical Document Embeddings)** — creates a hypothetical answer first and retrieves documents using that generated text.

These techniques help improve retrieval quality when user queries are **ambiguous, incomplete, or use different vocabulary from the stored documents**.

---

## Project Structure

```text
query-transformation-demo/
├── .gitignore
├── README.md
├── requirements.txt
├── knowledge_base.txt
└── main.py
```

### File Description

* **README.md** — project documentation and workflow explanation.
* **requirements.txt** — Python dependencies required for the demo.
* **.gitignore** — ignores virtual environments, cache files, and vector database files.
* **knowledge_base.txt** — sample knowledge base used for semantic retrieval.
* **main.py** — implements query rewriting, multi-query retrieval, and HyDE retrieval.

---

## Project Workflow

The following workflow shows how the system processes a user query using three different transformation strategies before retrieval.

```text
                User Query
                     │
                     ▼
        +------------------------+
        | Query Transformation   |
        +------------------------+
          │         │         │
          │         │         │
          ▼         ▼         ▼
     Rewriting  Multi-Query   HyDE
          │         │         │
          │         │         ▼
          │         │   Generate Hypothetical
          │         │         Answer
          │         │         │
          └─────────┴─────────┘
                    │
                    ▼
         Convert Text to Embeddings
                    │
                    ▼
          Chroma Vector Database
                    │
                    ▼
          Semantic Similarity Search
                    │
                    ▼
        Retrieve Relevant Documents
                    │
                    ▼
              Display Results
```