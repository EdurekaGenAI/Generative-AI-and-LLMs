# Image Captioning with a Vision-Language Model

## Overview

This project demonstrates how a **Vision-Language Model (VLM)** can automatically generate a natural language description for an image.

The demo uses **BLIP (Bootstrapping Language-Image Pre-training)** from Hugging Face, which combines computer vision and language understanding in a single model.

The application:

* Loads an image from disk
* Preprocesses the image for the model
* Uses a pretrained BLIP model to understand the visual content
* Generates a descriptive caption in natural language
* Displays the generated caption to the user

This project is useful for understanding the fundamentals of **multimodal AI**, where both **images and text** are processed together in a single workflow.

---

## Project Structure

```text
image-captioning-vlm/
├── sample_images/
│   ├── sample.jpg
│   └── README.md
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

### File Description

* **sample_images/** → Stores input images used for caption generation.
* **sample.jpg** → Example image for testing the model.
* **main.py** → Contains the image loading, preprocessing, model inference, and caption generation logic.
* **requirements.txt** → Lists all required Python dependencies.
* **README.md** → Project documentation and usage instructions.
* **.gitignore** → Prevents virtual environments and temporary files from being committed to version control.

---

## Project Workflow

```text
Start
   |
   v
Load Input Image
   |
   v
Convert Image to RGB Format
   |
   v
Preprocess Image with BLIP Processor
   |
   v
Load Pretrained BLIP Vision-Language Model
   |
   v
Generate Caption Tokens
   |
   v
Decode Tokens into Human-Readable Text
   |
   v
Display Final Caption
   |
   v
End
```