import os
import time

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field
from groq import Groq
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST

from app.metrics import (
    REQUEST_COUNT,
    REQUEST_LATENCY,
    ERROR_COUNT,
    TOKEN_USAGE,
)


load_dotenv()


MODEL_NAME = os.getenv(
    "GROQ_MODEL",
    "openai/gpt-oss-20b",
)

GROQ_API_KEY = os.getenv("GROQ_API_KEY")


if not GROQ_API_KEY:
    raise RuntimeError(
        "GROQ_API_KEY is not configured. "
        "Add it to your .env file."
    )


client = Groq(
    api_key=GROQ_API_KEY
)


app = FastAPI(
    title="GenAI Capstone Application",
    description=(
        "A deployed and monitored end-to-end "
        "Generative AI application using FastAPI, "
        "Groq GPT-OSS 20B, Docker and Prometheus."
    ),
    version="1.0.0",
)


class GenerateRequest(BaseModel):
    prompt: str = Field(
        ...,
        min_length=1,
        max_length=10000,
        description="Prompt sent to the GenAI model",
    )

    max_completion_tokens: int = Field(
        default=500,
        ge=1,
        le=4096,
        description="Maximum number of output tokens",
    )

    temperature: float = Field(
        default=0.6,
        ge=0.0,
        le=2.0,
        description="Controls response randomness",
    )

    reasoning_effort: str = Field(
        default="medium",
        description="GPT-OSS reasoning effort",
    )


class GenerateResponse(BaseModel):
    response: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    latency_seconds: float


@app.get("/")
def root():
    return {
        "application": "GenAI Capstone Application",
        "status": "running",
        "model": MODEL_NAME,
        "monitoring": "/metrics",
        "health": "/health",
        "docs": "/docs",
    }


@app.get("/health")
def health():
    return {
        "status": "healthy",
        "model": MODEL_NAME,
    }


@app.get("/metrics")
def metrics():
    return Response(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST,
    )


@app.post(
    "/generate",
    response_model=GenerateResponse,
)
def generate_text(request: GenerateRequest):

    REQUEST_COUNT.inc()

    start_time = time.perf_counter()

    try:

        if request.reasoning_effort not in [
            "low",
            "medium",
            "high",
        ]:
            raise HTTPException(
                status_code=400,
                detail=(
                    "reasoning_effort must be "
                    "'low', 'medium', or 'high'."
                ),
            )

        completion = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a helpful Generative AI "
                        "assistant. Provide accurate, clear "
                        "and concise answers."
                    ),
                },
                {
                    "role": "user",
                    "content": request.prompt,
                },
            ],
            temperature=request.temperature,
            max_completion_tokens=(
                request.max_completion_tokens
            ),
            reasoning_effort=request.reasoning_effort,
            include_reasoning=False,
        )

        latency = time.perf_counter() - start_time

        REQUEST_LATENCY.observe(latency)

        usage = completion.usage

        prompt_tokens = (
            usage.prompt_tokens
            if usage
            else 0
        )

        completion_tokens = (
            usage.completion_tokens
            if usage
            else 0
        )

        total_tokens = (
            usage.total_tokens
            if usage
            else 0
        )

        TOKEN_USAGE.inc(total_tokens)

        response_text = (
            completion.choices[0]
            .message
            .content
        )

        return GenerateResponse(
            response=response_text,
            model=MODEL_NAME,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            latency_seconds=round(
                latency,
                4,
            ),
        )

    except HTTPException:
        ERROR_COUNT.inc()
        raise

    except Exception as exc:

        ERROR_COUNT.inc()

        raise HTTPException(
            status_code=500,
            detail=f"Generation failed: {str(exc)}",
        )