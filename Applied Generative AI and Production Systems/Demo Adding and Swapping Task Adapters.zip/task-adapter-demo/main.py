class SentimentAdapter:
    """Performs simple rule-based sentiment analysis."""

    POSITIVE_WORDS = {
        "love",
        "great",
        "excellent",
        "exciting",
        "good",
        "amazing",
        "awesome",
        "fantastic",
    }

    def process(self, text: str) -> str:
        score = sum(word in text.lower() for word in self.POSITIVE_WORDS)

        if score > 0:
            return "Positive"

        return "Neutral or Negative"


class SummarizationAdapter:
    """Generates a short extractive summary."""

    def process(self, text: str) -> str:
        words = text.split()

        if len(words) <= 14:
            return text

        return " ".join(words[:14]) + "..."


class TranslationAdapter:
    """Simulates translation for demonstration purposes."""

    def process(self, text: str) -> str:
        return f"[Hindi Translation] {text}"


class TaskManager:
    """
    Central manager responsible for selecting and executing
    task adapters.
    """

    def __init__(self):
        self._adapter = None

    def set_adapter(self, adapter) -> None:
        """Assign the active adapter."""
        self._adapter = adapter

    def execute(self, text: str) -> str:
        """Execute the currently selected adapter."""

        if self._adapter is None:
            raise RuntimeError("No task adapter has been selected.")

        return self._adapter.process(text)


def display_section(title: str) -> None:
    """Display a formatted section header."""

    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


def main() -> None:
    """Run the adapter-swapping demonstration."""

    sample_text = (
        "I absolutely love learning Generative AI because it is exciting, "
        "practical, and highly valuable for modern software development."
    )

    manager = TaskManager()

    display_section("ORIGINAL INPUT TEXT")
    print(sample_text)

    adapters = [
        ("SENTIMENT ANALYSIS ADAPTER", SentimentAdapter()),
        ("SUMMARIZATION ADAPTER", SummarizationAdapter()),
        ("TRANSLATION ADAPTER", TranslationAdapter()),
    ]

    for title, adapter in adapters:
        display_section(title)
        manager.set_adapter(adapter)
        result = manager.execute(sample_text)
        print(result)

    display_section("DEMO COMPLETED SUCCESSFULLY")
    print("Task adapters were added and swapped dynamically at runtime.")


if __name__ == "__main__":
    main()