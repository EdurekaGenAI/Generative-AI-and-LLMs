# Capstone — Building a Document-Based Knowledge Assistant

## Overview

This project demonstrates how to build a **Document-Based Knowledge Assistant** using **LangChain**, **ChromaDB**, **Hugging Face embeddings**, and **Ollama with Llama 3.2**.

The assistant loads local documents, converts them into vector embeddings, retrieves the most relevant content for a user query, and generates grounded answers based only on the retrieved context.

---

## Project Structure

```text
document-knowledge-assistant/
├── knowledge_base/
│   ├── company_policy.txt
│   ├── product_manual.txt
│   └── faq.txt
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```


## Project Workflow

```text
+------------------+
|  Local Documents |
+------------------+
          |
          v
+------------------+
|  Load Text Files |
+------------------+
          |
          v
+----------------------+
| Split into Chunks    |
+----------------------+
          |
          v
+----------------------+
| Generate Embeddings  |
+----------------------+
          |
          v
+----------------------+
| Store in ChromaDB    |
+----------------------+
          |
          v
+----------------------+
| Retrieve Top Chunks  |
+----------------------+
          |
          v
+----------------------+
| Build Grounded Prompt|
+----------------------+
          |
          v
+----------------------+
| Llama 3.2 via Ollama |
+----------------------+
          |
          v
+----------------------+
|  Final Answer        |
+----------------------+
```