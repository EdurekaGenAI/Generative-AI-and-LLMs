from transformers import BlipProcessor, BlipForConditionalGeneration
from PIL import Image


def generate_caption(image_path):
    """
    Generate a caption for an input image using the
    BLIP Vision-Language Model from Hugging Face.
    """

    print("Image Captioning Demo with BLIP")
    print("-" * 50)

    # Step 1: Load the image
    print("Loading image...")
    image = Image.open(image_path).convert("RGB")

    # Step 2: Load the BLIP processor and model
    print("Loading BLIP vision-language model...")

    processor = BlipProcessor.from_pretrained(
        "Salesforce/blip-image-captioning-base"
    )

    model = BlipForConditionalGeneration.from_pretrained(
        "Salesforce/blip-image-captioning-base"
    )

    # Step 3: Preprocess the image
    print("Processing image for caption generation...")
    inputs = processor(images=image, return_tensors="pt")

    # Step 4: Generate caption tokens
    print("Generating caption...")
    output = model.generate(
        **inputs,
        max_new_tokens=30,
        num_beams=5
    )

    # Step 5: Decode the generated tokens
    caption = processor.decode(
        output[0],
        skip_special_tokens=True
    )

    # Step 6: Display the result
    print("\nGenerated Caption:")
    print(f"{caption}")


if __name__ == "__main__":
    # Input image path
    image_path = "sample_images/dog.png"

    # Run caption generation
    generate_caption(image_path)