from fastapi import FastAPI
from app.models import PromptRequest, PromptResponse

app = FastAPI(
    title="GenAI FastAPI API",
    description="A simple Generative AI API built with FastAPI",
    version="1.0.0"
)


@app.get("/")
def root():
    return {"message": "GenAI FastAPI API is running"}


@app.post("/generate", response_model=PromptResponse)
def generate_text(request: PromptRequest):
    prompt = request.prompt

    generated_text = (
        f"AI Response: This is a simulated response for the prompt: '{prompt}'. "
        "In a real application, this is where you would connect an LLM such as "
        "Gemini, OpenAI, Hugging Face, or another Generative AI model."
    )

    return PromptResponse(
        prompt=prompt,
        generated_text=generated_text
    )