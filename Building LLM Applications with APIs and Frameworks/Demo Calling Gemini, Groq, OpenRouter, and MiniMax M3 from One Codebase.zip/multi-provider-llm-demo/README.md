# Multi-Provider LLM Demo

This project demonstrates how to call **Gemini 3.5 Flash**, **Groq**, **OpenRouter GPT-OSS**, and **MiniMax M3 (via NVIDIA NIM)** from **one Python codebase**.

The goal is to show how multiple AI providers can be integrated through a **single application** while keeping the code simple, reusable, and easy to extend.

---

## Overview

Modern AI applications often use more than one LLM provider for **cost optimisation**, **performance comparison**, **fallback support**, or **model experimentation**.

This project sends the **same prompt** to all four providers and displays the responses side by side.

---

## Project Structure

```text
multi-provider-llm-demo/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

---

## Project Workflow

```text
+---------------------+
|     User Prompt     |
+---------------------+
           |
           v
+---------------------+
|       main.py       |
|  Receive User Input |
+---------------------+
           |
           v
+---------------------+
| Load API Keys (.env)|
+---------------------+
           |
           v
+---------------------+
| Send Prompt to All  |
|      Providers      |
+---------------------+
   |        |         |
   |        |         |
   v        v         v
+--------+ +--------+ +--------------------+
| Gemini | |  Groq  | | OpenRouter         |
| 3.5    | | Llama  | | ChatGPT OSS 20B    |
| Flash  | | 3.1    | +--------------------+
+--------+ +--------+            |
                                 v
                     +--------------------+
                     | NVIDIA NIM API     |
                     | MiniMax M3         |
                     +--------------------+
                                 |
                                 v
                     +--------------------+
                     | Collect Responses  |
                     +--------------------+
                                 |
                                 v
                     +--------------------+
                     | Display Comparison |
                     +--------------------+
```