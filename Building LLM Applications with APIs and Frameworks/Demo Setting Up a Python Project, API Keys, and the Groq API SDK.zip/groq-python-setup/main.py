import os
from dotenv import load_dotenv
from groq import Groq


def print_banner():
    print("=" * 70)
    print("GROQ API SDK - PYTHON PROJECT SETUP")
    print("Setting Up a Python Project, API Keys, and the Groq API SDK")
    print("=" * 70)


def load_api_key():
    """Load the Groq API key from the .env file."""
    load_dotenv()

    api_key = os.getenv("GROQ_API_KEY")

    if not api_key:
        raise ValueError(
            "GROQ_API_KEY not found. Please add it to your .env file."
        )

    return api_key


def create_client(api_key):
    """Create and return a Groq client instance."""
    return Groq(api_key=api_key)


def generate_response(client, prompt):
    """Send a prompt to the Groq API and return the generated response."""

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a helpful Python and Generative AI tutor. "
                    "Provide clear, beginner-friendly explanations with practical examples."
                ),
            },
            {
                "role": "user",
                "content": prompt,
            },
        ],
        temperature=0.7,
        max_tokens=300,
    )

    return response.choices[0].message.content


def main():
    print_banner()

    try:
        api_key = load_api_key()
        client = create_client(api_key)

        print("\nGroq client initialised successfully.")

        default_prompt = (
            "Explain why virtual environments are important in Python and "
            "how they help manage project dependencies."
        )

        print("\nSending prompt to the Groq API...")

        answer = generate_response(client, default_prompt)

        print("\n" + "=" * 70)
        print("AI RESPONSE")
        print("=" * 70)
        print(answer)
        print("=" * 70)

    except Exception as error:
        print("\nAn error occurred while running the project:")
        print(error)


if __name__ == "__main__":
    main()

