import pandas as pd
import numpy as np


def load_csv(path):
    return pd.read_csv(path)


def print_section(title):
    print("\n" + "=" * 50)
    print(title)
    print("=" * 50)


def format_number(value):
    return round(float(value), 4)


def calculate_mean_std(series):
    return {
        "mean": np.mean(series),
        "std": np.std(series),
    }