from dotenv import load_dotenv
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_groq import ChatGroq

# Load environment variables
load_dotenv()

# Create Groq LLM
llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    temperature=0.7
)

# Create Prompt Template
prompt = ChatPromptTemplate.from_template(
    "Explain the concept of {topic} in simple words with a real-world example."
)

# Create Output Parser
parser = StrOutputParser()

# Compose the LCEL Chain
chain = prompt | llm | parser

# Run the chain
topic = input("Enter a topic: ")

response = chain.invoke({"topic": topic})

print("\n--- LCEL Chain Response ---\n")
print(response)