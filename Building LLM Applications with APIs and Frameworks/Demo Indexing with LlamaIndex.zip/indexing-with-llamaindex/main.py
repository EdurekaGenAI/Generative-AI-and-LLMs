import os
from dotenv import load_dotenv

from llama_index.core import (
    Settings,
    SimpleDirectoryReader,
    VectorStoreIndex,
)

from llama_index.llms.groq import Groq
from llama_index.embeddings.huggingface import HuggingFaceEmbedding


def configure_models():
    """Configure the LLM and embedding model."""

    groq_api_key = os.getenv("GROQ_API_KEY")

    if not groq_api_key:
        raise ValueError(
            "GROQ_API_KEY not found. Please add it to the .env file."
        )

    # Configure Groq LLM
    Settings.llm = Groq(
        model="llama-3.3-70b-versatile",
        api_key=groq_api_key,
    )

    # Configure local embedding model
    Settings.embed_model = HuggingFaceEmbedding(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )


def load_documents(data_folder="data"):
    """Load documents from the specified folder."""

    if not os.path.exists(data_folder):
        raise FileNotFoundError(
            f"Data folder '{data_folder}' was not found."
        )

    documents = SimpleDirectoryReader(data_folder).load_data()

    print(f"Loaded {len(documents)} document(s).")

    return documents


def create_index(documents):
    """Create a vector index from the loaded documents."""

    print("Creating vector index...")

    index = VectorStoreIndex.from_documents(documents)

    print("Index created successfully!")

    return index


def query_index(index, question):
    """Query the index using a natural language question."""

    query_engine = index.as_query_engine()

    response = query_engine.query(question)

    print("\n" + "=" * 60)
    print(f"Question: {question}")
    print("=" * 60)
    print("Answer:")
    print(response)
    print("=" * 60)


def main():
    """Main application workflow."""

    print("LlamaIndex Indexing Demo")
    print("-" * 60)

    # Load environment variables
    load_dotenv()

    # Configure models
    configure_models()

    # Load documents
    documents = load_documents("data")

    # Create index
    index = create_index(documents)

    # Ask a question
    question = "What is indexing in LlamaIndex?"
    query_index(index, question)


if __name__ == "__main__":
    main()