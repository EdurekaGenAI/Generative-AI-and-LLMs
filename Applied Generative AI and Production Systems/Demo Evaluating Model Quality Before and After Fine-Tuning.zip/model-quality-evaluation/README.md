# Evaluating Model Quality Before and After Fine-Tuning

## Overview

This project demonstrates how to **evaluate model quality before and after fine-tuning** using a simple similarity-based scoring method.

The project compares:

* evaluation prompts,
* reference answers,
* outputs generated before fine-tuning,
* outputs generated after fine-tuning,
* similarity scores,
* average quality improvement.

---

## Project Structure

```text
model-quality-evaluation/
├── data/
│   ├── evaluation_prompts.txt
│   └── reference_answers.txt
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

---

## Project Workflow

```text
Start
   |
   v
Load Evaluation Prompts
   |
   v
Load Reference Answers
   |
   v
Generate Base Model Outputs
   |
   v
Calculate Similarity Scores
   |
   v
Generate Fine-Tuned Model Outputs
   |
   v
Calculate Similarity Scores Again
   |
   v
Compare Average Scores
   |
   v
Measure Improvement Percentage
   |
   v
Display Evaluation Report
   |
   v
End
```

---

## Expected Output

```text
=== Model Quality Evaluation ===

Prompt 1: Explain what a neural network is in simple terms.
Before Fine-Tuning Score : 0.63
After Fine-Tuning Score  : 1.00
------------------------------------------------------------

...

=== Average Results ===
Average Before Fine-Tuning : 0.67
Average After Fine-Tuning  : 1.00
Improvement                : 49.25%
```

---
