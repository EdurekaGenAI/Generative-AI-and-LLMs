# Working with Managed Vector Databases — Pinecone and Weaviate

## Overview

This project demonstrates how to use **managed vector databases** for semantic search and Retrieval-Augmented Generation (RAG) workflows.

The demo compares two popular platforms:

* **Pinecone** — fully managed serverless vector database
* **Weaviate** — open-source vector database with managed cloud support

Both examples use the **Sentence Transformers** embedding model to generate vector representations of text documents and perform similarity search.

---

## Project Structure

```text
managed-vector-databases-demo/
├── data/
│   └── sample_docs.txt
├── .env
├── managed_vector_demo.py
├── requirements.txt
├── README.md
└── .gitignore
```

---

## Environment Variables

Create a file named **.env** in the project root and add your credentials:

```env
PINECONE_API_KEY=your_pinecone_api_key
WEAVIATE_URL=https://your-cluster-name.weaviate.network
WEAVIATE_API_KEY=your_weaviate_api_key
```

---

## Setup Instructions

### 1. Create a Virtual Environment

#### Windows

```bash
python -m venv venv
venv\Scripts\activate
```

#### macOS / Linux

```bash
python3 -m venv venv
source venv/bin/activate
```

---

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

---

## Pinecone Setup

1. Create an account at **https://www.pinecone.io**
2. Copy your API key from the Pinecone console.
3. Add the API key to the `.env` file.

### Run

```bash
python managed_vector_demo.py
```

---

## Weaviate Setup

1. Create a cluster at **https://console.weaviate.cloud**
2. Copy your cluster URL and API key.
3. Add them to the `.env` file.

### Run

```bash
python managed_vector_demo.py
```

---

## Project Workflow

```text
Start
   │
   ▼
Load Environment Variables (.env)
   │
   ▼
Load Sentence Transformer Model
   │
   ▼
Read Sample Documents
   │
   ▼
Generate Text Embeddings
   │
   ├───────────────► Pinecone
   │                   │
   │                   ▼
   │             Create / Connect Index
   │                   │
   │                   ▼
   │             Upload Vectors
   │                   │
   │                   ▼
   │             Semantic Query
   │
   └───────────────► Weaviate
                       │
                       ▼
                 Create / Connect Collection
                       │
                       ▼
                 Upload Vectors
                       │
                       ▼
                 Near-Vector Query
                       │
                       ▼
            Display Side-by-Side Results
                       │
                       ▼
                     Finish
```
