import os
from dotenv import load_dotenv
from groq import Groq

# ---------------------------------------
# Load Environment Variables
# ---------------------------------------
load_dotenv()

api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    raise ValueError("GROQ_API_KEY not found.")

client = Groq(api_key=api_key)

MODEL = "llama-3.3-70b-versatile"

# ---------------------------------------
# Tree-of-Thought Prompt
# ---------------------------------------

prompt = """
You are an expert problem solver.

Use the Tree-of-Thought reasoning approach.

Problem:
A company has $50,000 to improve customer satisfaction.

Possible investments:
1. Improve Customer Support
2. Build New Features
3. Improve Mobile App Performance
4. Increase Marketing

Follow these steps.

STEP 1
Generate at least three different solution branches.

STEP 2
For every branch explain:
- Benefits
- Risks
- Estimated customer impact

STEP 3
Score each branch out of 10.

STEP 4
Compare all branches.

STEP 5
Choose the best branch.

STEP 6
Explain why the other branches were rejected.

Return the answer using this format:

============================
Branch 1
Benefits:
Risks:
Score:

Branch 2
Benefits:
Risks:
Score:

Branch 3
Benefits:
Risks:
Score:

============================
Comparison

============================
Final Decision

============================
Reason
"""

response = client.chat.completions.create(
    model=MODEL,
    temperature=0.7,
    messages=[
        {
            "role": "system",
            "content": "You are an expert AI reasoning assistant."
        },
        {
            "role": "user",
            "content": prompt
        }
    ]
)

print("\n")
print("=" * 70)
print("TREE OF THOUGHT RESULT")
print("=" * 70)
print(response.choices[0].message.content)