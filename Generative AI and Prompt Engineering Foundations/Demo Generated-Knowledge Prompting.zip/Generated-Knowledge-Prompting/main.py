import os
from dotenv import load_dotenv
from groq import Groq

# Load environment variables
load_dotenv()

api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    raise ValueError("GROQ_API_KEY not found. Please check your .env file.")

client = Groq(api_key=api_key)

MODEL = "llama-3.3-70b-versatile"


def generate_response(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0.3
    )

    return response.choices[0].message.content


def main():
    print("=" * 70)
    print("GENERATED-KNOWLEDGE PROMPTING DEMO")
    print("=" * 70)

    question = (
        "Why are electric vehicles becoming more popular around the world?"
    )

    print("\nQuestion:")
    print(question)

    # ---------------------------------------------------
    # Direct Prompt
    # ---------------------------------------------------
    direct_prompt = f"""
Answer the following question clearly.

Question:
{question}
"""

    direct_answer = generate_response(direct_prompt)

    print("\n" + "=" * 70)
    print("DIRECT ANSWER")
    print("=" * 70)
    print(direct_answer)

    # ---------------------------------------------------
    # Step 1: Generate Knowledge
    # ---------------------------------------------------
    knowledge_prompt = f"""
Before answering the question, generate useful background knowledge.

Question:
{question}

Instructions:
- Generate 5 concise factual points.
- Keep each point to one sentence.
- Do not answer the question directly.
"""

    generated_knowledge = generate_response(knowledge_prompt)

    print("\n" + "=" * 70)
    print("GENERATED KNOWLEDGE")
    print("=" * 70)
    print(generated_knowledge)

    # ---------------------------------------------------
    # Step 2: Final Answer
    # ---------------------------------------------------
    final_prompt = f"""
Use the generated knowledge below to answer the question.

Generated Knowledge:
{generated_knowledge}

Question:
{question}

Instructions:
- Write a well-structured explanation.
- Use the generated knowledge naturally.
- Keep the answer around 200 words.
"""

    final_answer = generate_response(final_prompt)

    print("\n" + "=" * 70)
    print("ANSWER USING GENERATED KNOWLEDGE")
    print("=" * 70)
    print(final_answer)


if __name__ == "__main__":
    main()