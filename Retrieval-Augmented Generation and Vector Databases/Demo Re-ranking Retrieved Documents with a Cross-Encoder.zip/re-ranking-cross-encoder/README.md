## Re-ranking Retrieved Documents with a Cross-Encoder

### Overview

This project demonstrates how **Cross-Encoders** can improve retrieval quality by **re-ranking candidate documents** returned by a first-stage retriever.

A typical retrieval pipeline works in two stages:

1. **Initial Retrieval** → Fast bi-encoder or vector search returns the top-k candidate documents.
2. **Re-ranking** → A Cross-Encoder scores each `(query, document)` pair more accurately and sorts the results by semantic relevance.

Cross-Encoders are slower than vector search but usually provide **much better ranking quality**, which is why they are commonly used in **RAG (Retrieval-Augmented Generation)** systems.

---

### Project Workflow

```text
User Query
     |
     v
Initial Retrieved Documents
     |
     v
Create (query, document) pairs
     |
     v
Cross-Encoder Scoring
     |
     v
Sort by Relevance Score
     |
     v
Final Re-ranked Results
```
