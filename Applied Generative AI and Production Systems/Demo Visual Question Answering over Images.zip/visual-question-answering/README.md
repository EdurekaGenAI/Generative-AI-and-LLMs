# Visual Question Answering over Images

## Overview

This project demonstrates **Visual Question Answering (VQA)** using a pre-trained multimodal transformer model from **Hugging Face**.

The application accepts an **image** and a **natural language question**, processes both inputs together, and generates an **answer based on the visual content of the image**.

The project is useful for understanding how modern AI systems combine **computer vision** and **natural language understanding** to perform reasoning tasks over images.

---

## Project Structure

```text
visual-question-answering/
├── images/
│   └── sample.jpg
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

---

## Project Workflow

```text
        +------------------+
        |   Input Image    |
        +------------------+
                  |
                  v
        +------------------+
        | User Question    |
        +------------------+
                  |
                  v
        +------------------------------+
        | Pre-trained VQA Transformer  |
        | (ViLT fine-tuned on VQA)     |
        +------------------------------+
                  |
                  v
        +------------------+
        | Predicted Answer |
        +------------------+
                  |
                  v
        +------------------+
        | Display Result   |
        +------------------+
```

---

### Example Flow

```text
Image: sample.jpg
Question: "What is in the image?"
        |
        v
Model analyses image + question
        |
        v
Answer: "dog"
```

This workflow shows how the VQA model jointly analyses **visual information** and **textual input** to produce a meaningful answer.