# Benchmarking Candidate Models on Cost, Latency, and Quality

## Overview

This project benchmarks multiple LLM candidate models across three practical dimensions:

- **Cost** – estimated API cost per request
- **Latency** – response time in milliseconds
- **Quality** – simple heuristic score based on output characteristics

The benchmark sends the same prompt to each model, measures execution time, estimates token usage, computes a quality score, and generates a comparative report.

---

## Project Structure

```text
benchmarking-candidate-models/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

---

## Project Workflow

```text
            ┌──────────────────────┐
            │  Load Environment    │
            │   Variables (.env)   │
            └──────────┬───────────┘
                       │
                       ▼
            ┌──────────────────────┐
            │   Define Test Prompt │
            └──────────┬───────────┘
                       │
                       ▼
            ┌──────────────────────┐
            │   Send Request to    │
            │     Candidate LLM    │
            └──────────┬───────────┘
                       │
         ┌─────────────┼─────────────┐
         ▼             ▼             ▼
┌─────────────┐ ┌─────────────┐ ┌─────────────┐
│ Measure     │ │ Estimate    │ │ Evaluate    │
│ Latency     │ │ Token Cost  │ │ Quality     │
└──────┬──────┘ └──────┬──────┘ └──────┬──────┘
       └───────────────┼───────────────┘
                       ▼
            ┌──────────────────────┐
            │ Aggregate Benchmark  │
            │       Results        │
            └──────────┬───────────┘
                       ▼
            ┌──────────────────────┐
            │ Display Comparison   │
            │     and Ranking      │
            └──────────────────────┘
```

## Example Output

```text
📊 Benchmarking Candidate Models

Running benchmark for: llama-3.3-70b-versatile
Running benchmark for: llama-3.1-8b-instant
Running benchmark for: mixtral-8x7b-32768

🏆 Benchmark Results

+---------------------------+----------------+----------+-----------------+-----------------+
| Model                     | Latency (ms)   | Tokens   | Est. Cost ($)   | Quality (/10)   |
+===========================+================+==========+=================+=================+
| llama-3.3-70b-versatile  | 842.51         | 148      | 0.000133        | 10              |
| mixtral-8x7b-32768       | 601.23         | 142      | 0.000085        | 9               |
| llama-3.1-8b-instant     | 325.77         | 121      | 0.000024        | 8               |
+---------------------------+----------------+----------+-----------------+-----------------+

🎯 Recommended Model
Model   : llama-3.3-70b-versatile
Quality : 10/10
Latency : 842.51 ms
Cost    : $0.000133
```

---