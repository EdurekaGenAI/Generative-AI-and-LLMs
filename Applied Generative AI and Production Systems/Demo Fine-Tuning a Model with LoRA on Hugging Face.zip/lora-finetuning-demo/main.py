import os
import warnings
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
)
from peft import LoraConfig, get_peft_model


# --------------------------------------------------
# Clean console output
# --------------------------------------------------
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
warnings.filterwarnings("ignore")


# --------------------------------------------------
# Sample instruction-tuning dataset
# --------------------------------------------------
examples = [
    {
        "instruction": "Explain what machine learning is.",
        "response": "Machine learning is a branch of artificial intelligence that enables systems to learn patterns from data and make predictions or decisions without being explicitly programmed for every task.",
    },
    {
        "instruction": "What is LoRA fine-tuning?",
        "response": "LoRA is a parameter-efficient fine-tuning technique that trains small adapter matrices instead of updating all the parameters of a large language model.",
    },
    {
        "instruction": "Why is parameter-efficient tuning useful?",
        "response": "Parameter-efficient tuning reduces memory usage, training time, and computational cost while still adapting a model to a new task.",
    },
]


# --------------------------------------------------
# Convert to training text format
# --------------------------------------------------
def format_example(example):
    return {
        "text": f"""### Instruction:
{example['instruction']}

### Response:
{example['response']}"""
    }


dataset = Dataset.from_list(examples)
dataset = dataset.map(format_example)


# --------------------------------------------------
# Load tokenizer and base model
# --------------------------------------------------
MODEL_NAME = "gpt2"

print("Loading tokenizer and model...")

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)


# --------------------------------------------------
# Apply LoRA configuration
# --------------------------------------------------
lora_config = LoraConfig(
    r=8,
    lora_alpha=16,
    target_modules=["c_attn"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM",
)

model = get_peft_model(model, lora_config)

print("LoRA adapters attached successfully.")


# --------------------------------------------------
# Tokenization
# --------------------------------------------------
def tokenize_function(example):
    return tokenizer(
        example["text"],
        truncation=True,
        padding="max_length",
        max_length=128,
    )


tokenized_dataset = dataset.map(tokenize_function, batched=True)


# --------------------------------------------------
# Training configuration
# --------------------------------------------------
training_args = TrainingArguments(
    output_dir="./lora_output",
    per_device_train_batch_size=1,
    num_train_epochs=3,
    learning_rate=5e-5,
    logging_steps=1,
    save_strategy="no",
    report_to="none",
    dataloader_pin_memory=False,
    disable_tqdm=True,
)


# --------------------------------------------------
# Data collator
# --------------------------------------------------
data_collator = DataCollatorForLanguageModeling(
    tokenizer=tokenizer,
    mlm=False,
)


# --------------------------------------------------
# Trainer
# --------------------------------------------------
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_dataset,
    data_collator=data_collator,
)


# --------------------------------------------------
# Start training
# --------------------------------------------------
print("\nStarting LoRA fine-tuning...")

train_result = trainer.train()


# --------------------------------------------------
# Save LoRA adapter
# --------------------------------------------------
SAVE_PATH = "lora_adapter"

model.save_pretrained(SAVE_PATH)
tokenizer.save_pretrained(SAVE_PATH)


# --------------------------------------------------
# Clean and professional summary
# --------------------------------------------------
trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
total_params = sum(p.numel() for p in model.parameters())
percentage = (trainable_params / total_params) * 100

print("\n" + "=" * 55)
print("LoRA Fine-Tuning Results")
print("=" * 55)
print(f"Trainable Parameters : {trainable_params:,}")
print(f"Total Parameters     : {total_params:,}")
print(f"Trainable Percentage : {percentage:.4f}%")
print(f"Epochs Completed     : {training_args.num_train_epochs}")
print(f"Final Training Loss  : {train_result.training_loss:.4f}")
print(f"Adapter Saved To     : {SAVE_PATH}/")
print("\nLoRA fine-tuning completed successfully.")
print("The model is now ready for inference.")
print("=" * 55)


# --------------------------------------------------
# Simple inference test
# --------------------------------------------------
print("\nTesting the fine-tuned adapter...")

prompt = "### Instruction: Explain LoRA in simple terms.\n\n### Response:"

inputs = tokenizer(prompt, return_tensors="pt")

output = model.generate(
    **inputs,
    max_new_tokens=40,
    temperature=0.7,
    do_sample=True,
    pad_token_id=tokenizer.eos_token_id,
)

generated_text = tokenizer.decode(output[0], skip_special_tokens=True)

print("\nGenerated Response:\n")
print(generated_text)