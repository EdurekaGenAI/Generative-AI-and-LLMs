## Building the Retriever and Retrieval Chain

### Overview

This project demonstrates how a Retriever and Retrieval Chain work together in a Retrieval-Augmented Generation (RAG) workflow.

The application:

* Loads a text-based knowledge base
* Splits the content into smaller chunks
* Generates semantic embeddings
* Stores the embeddings in a FAISS vector database
* Retrieves the most relevant chunks for a user query
* Passes the retrieved context into a simple retrieval chain

---

### Project Structure

```text
retriever-and-retrieval-chain/
│
├── .gitignore
├── README.md
├── requirements.txt
├── main.py
├── retriever.py
├── retrieval_chain.py
└── knowledge_base.txt
```

---

### Project Workflow

```text
User Question
      │
      ▼
Load Knowledge Base
      │
      ▼
Split into Chunks
      │
      ▼
Generate Embeddings
      │
      ▼
Store in FAISS Vector Database
      │
      ▼
Retriever Searches Similar Chunks
      │
      ▼
Retrieval Chain Combines Context
      │
      ▼
Return Context-Aware Answer
```
