import os
import warnings

# Hide unnecessary warnings
warnings.filterwarnings("ignore")
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

from langchain_text_splitters import CharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma

# --------------------------------------------------
# Load knowledge base manually
# --------------------------------------------------

with open("knowledge_base.txt", "r", encoding="utf-8") as file:
    text = file.read()

# --------------------------------------------------
# Split text into chunks
# --------------------------------------------------

splitter = CharacterTextSplitter(
    chunk_size=200,
    chunk_overlap=30
)

chunks = splitter.split_text(text)

# --------------------------------------------------
# Create embeddings
# --------------------------------------------------

embedding_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

# --------------------------------------------------
# Create vector database
# --------------------------------------------------

vectorstore = Chroma.from_texts(
    texts=chunks,
    embedding=embedding_model,
    persist_directory="chroma_db"
)

retriever = vectorstore.as_retriever(search_kwargs={"k": 2})

# --------------------------------------------------
# Original query
# --------------------------------------------------

query = "How can transformer models remember previous words?"

print("\n" + "=" * 60)
print("ORIGINAL QUERY")
print("=" * 60)
print(query)

# --------------------------------------------------
# Query Rewriting
# --------------------------------------------------

rewritten_query = (
    "How do transformer models use attention and context from previous tokens?"
)

print("\n" + "=" * 60)
print("QUERY REWRITING")
print("=" * 60)
print(f"Original : {query}")
print(f"Rewritten: {rewritten_query}")

rewrite_results = retriever.invoke(rewritten_query)

print("\nRetrieved Documents:")
for doc in rewrite_results:
    print(f"- {doc.page_content}")

# --------------------------------------------------
# Multi-Query Retrieval
# --------------------------------------------------

multi_queries = [
    "How do transformers use previous tokens?",
    "What mechanism allows transformers to capture context?",
    "How does self-attention help language models remember earlier words?"
]

print("\n" + "=" * 60)
print("MULTI-QUERY RETRIEVAL")
print("=" * 60)

all_results = []

for mq in multi_queries:
    print(f"Query: {mq}")
    results = retriever.invoke(mq)

    for r in results:
        if r.page_content not in all_results:
            all_results.append(r.page_content)

print("\nCombined Results:")
for content in all_results:
    print(f"- {content}")

# --------------------------------------------------
# HyDE Retrieval
# --------------------------------------------------

hypothetical_answer = (
    "Transformer models use self-attention to connect each token with previous "
    "tokens and build contextual understanding across a sequence."
)

print("\n" + "=" * 60)
print("HyDE RETRIEVAL")
print("=" * 60)

print("Hypothetical Answer:")
print(hypothetical_answer)

hyde_results = retriever.invoke(hypothetical_answer)

print("\nRetrieved Documents:")
for doc in hyde_results:
    print(f"- {doc.page_content}")

print("\n" + "=" * 60)
print("DEMO COMPLETED SUCCESSFULLY")
print("=" * 60)