## Designing Grounded Retrieval Prompts with Citations and Safe No-Answer Responses

This project demonstrates how to design **grounded retrieval prompts** for Retrieval-Augmented Generation (RAG) systems. The goal is to ensure that responses are generated **only from retrieved documents**, include **citations**, and return a **safe no-answer response** when the required information is unavailable.

---

## Learning Objectives

* Build a retrieval pipeline with LangChain
* Ground responses using retrieved context
* Add source citations to generated answers
* Prevent hallucinations with strict prompt rules
* Implement safe no-answer behaviour

---

## Project Structure

```
grounded-rag-prompting/
│
├── .gitignore
├── README.md
├── requirements.txt
├── main.py
└── knowledge_base.txt
```

---

## Project Workflow

```
Knowledge Base
       │
       ▼
Load Documents
       │
       ▼
Split into Chunks
       │
       ▼
Generate Embeddings
       │
       ▼
Store in Chroma Vector Database
       │
       ▼
Retrieve Relevant Chunks
       │
       ▼
Build Grounded Prompt
       │
       ▼
Generate Answer with Citations
       │
       ▼
Safe No-Answer Response (if information is missing)
```