# Measuring Retrieval Quality with Ranking Metrics

## Overview

This project demonstrates how to evaluate the quality of a retrieval system using **ranking metrics** commonly used in search engines, recommendation systems, and Retrieval-Augmented Generation (RAG) pipelines.

The project measures how effectively relevant documents are ranked near the top of the retrieved results by calculating:

* **Precision@k**
* **Recall@k**
* **Mean Reciprocal Rank (MRR)**
* **Normalized Discounted Cumulative Gain (NDCG@k)**

This implementation is lightweight, beginner-friendly, and ideal for understanding retrieval evaluation fundamentals before integrating with vector databases, semantic search systems, or RAG frameworks.

---

## Project Structure

```text
retrieval-ranking-metrics/
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

### File Description

| File                 | Purpose                                                                                      |
| -------------------- | -------------------------------------------------------------------------------------------- |
| **README.md**        | Project documentation and workflow explanation                                               |
| **requirements.txt** | Python dependencies required to run the project                                              |
| **main.py**          | Implements the ranking metric calculations and displays the evaluation results               |
| **.gitignore**       | Excludes virtual environments, cache files, and other unnecessary files from version control |

---

## Project Workflow

```text
User Query
     │
     ▼
Retrieve Ranked Documents
     │
     ▼
Ground-Truth Relevant Documents
     │
     ▼
Compare Retrieved vs Relevant Documents
     │
     ▼
Calculate Ranking Metrics
     │
 ┌────────────┼────────────┬────────────┐
 ▼            ▼            ▼            ▼
Precision@k  Recall@k     MRR        NDCG@k
     │
     ▼
Evaluate Retrieval Quality
```