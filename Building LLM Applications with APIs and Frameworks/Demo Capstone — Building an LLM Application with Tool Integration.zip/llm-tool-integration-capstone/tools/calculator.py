import re


def calculate(expression: str) -> str:
    try:
        # Remove words and unwanted characters
        expression = expression.lower()
        expression = expression.replace("calculate", "")

        # Keep only numbers and math operators
        expression = re.sub(r"[^0-9+\-*/(). ]", "", expression)
        expression = expression.strip()

        if not expression:
            return "Please provide a valid mathematical expression."

        result = eval(expression)

        return f"Result: {result}"

    except Exception as error:
        return f"Calculation error: {error}"