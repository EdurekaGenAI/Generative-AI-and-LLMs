# Compressing and Summarising Context to Fit Limits

## Overview

Large Language Models (LLMs) have a limited context window, meaning they can only process a certain amount of information at one time. When documents become too large, developers must reduce the amount of context without losing the key information.

In this project, you will build a simple application that compresses a long document into a concise summary before asking another question. This demonstrates one of the most common techniques used in Retrieval-Augmented Generation (RAG), AI assistants, and document-based chatbots.

---

# Project Structure

```
context-compression-demo/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

---

# Project Workflow

```text
                 Start
                   │
                   ▼
       Load Environment Variables
                   │
                   ▼
         Connect to Groq API
                   │
                   ▼
      Load Long Document/Text
                   │
                   ▼
      Generate Compressed Summary
                   │
                   ▼
      Display Original Context
                   │
                   ▼
     Display Compressed Context
                   │
                   ▼
        Ask Follow-up Question
                   │
                   ▼
      Use Summary as Context
                   │
                   ▼
      Generate Final AI Response
                   │
                   ▼
                  End
```