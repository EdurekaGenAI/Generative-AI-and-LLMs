import os
from dotenv import load_dotenv
from groq import Groq

# =====================================================
# Load environment variables
# =====================================================
load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if not GROQ_API_KEY:
    raise ValueError("GROQ_API_KEY not found in .env file")


# =====================================================
# Initialize Groq Client
# =====================================================
client = Groq(api_key=GROQ_API_KEY)


# =====================================================
# Generic LLM Call Function
# =====================================================
def call_llm(prompt, temperature=0.7, max_tokens=300, top_p=1.0, stop=None):
    """
    Send a prompt to the Groq API and return the generated response.
    """

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a senior AI assistant that provides clear, "
                    "structured, and professional responses."
                )
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        stop=stop
    )

    return response.choices[0].message.content.strip()


# =====================================================
# Step 1 - Generate Detailed Explanation
# =====================================================
def generate_explanation(topic):
    prompt = f"""
    Explain the following topic in a professional but beginner-friendly manner.

    Topic: {topic}

    Include:
    - A simple definition
    - Why the topic is important
    - A real-world example
    - Key benefits or use cases

    Keep the explanation concise but informative.
    """

    return call_llm(
        prompt=prompt,
        temperature=0.5,
        max_tokens=350
    )


# =====================================================
# Step 2 - Summarize the Explanation
# =====================================================
def summarize_explanation(explanation):
    prompt = f"""
    Summarize the following explanation in exactly 4 concise sentences.

    Explanation:
    {explanation}
    """

    return call_llm(
        prompt=prompt,
        temperature=0.3,
        max_tokens=150
    )


# =====================================================
# Step 3 - Create an Action Plan
# =====================================================
def create_action_plan(summary):
    prompt = f"""
    Based on the summary below, create 5 practical action steps for a student who wants to learn this topic.

    Summary:
    {summary}

    Format the response as numbered points.

    End the response with ###END###
    """

    return call_llm(
        prompt=prompt,
        temperature=0.6,
        max_tokens=220,
        top_p=0.9,
        stop=["###END###"]
    )


# =====================================================
# Step 4 - Generate Quiz Questions
# =====================================================
def generate_quiz(topic):
    prompt = f"""
    Create 3 short beginner-level quiz questions about the topic below.

    Topic: {topic}

    Keep the questions simple and educational.
    """

    return call_llm(
        prompt=prompt,
        temperature=0.4,
        max_tokens=180
    )


# =====================================================
# Main Multi-Step Chain Workflow
# =====================================================
def main():
    print("\n=== API Integration + Parameter Tuning + Multi-Step Chain ===\n")

    topic = input("Enter a topic: ").strip()

    if not topic:
        print("Please enter a valid topic.")
        return

    # ---------------- Step 1 ----------------
    print("\n[STEP 1] Generating Detailed Explanation...\n")
    explanation = generate_explanation(topic)

    print("EXPLANATION")
    print("-" * 60)
    print(explanation)

    # ---------------- Step 2 ----------------
    print("\n[STEP 2] Summarizing the Explanation...\n")
    summary = summarize_explanation(explanation)

    print("SUMMARY")
    print("-" * 60)
    print(summary)

    # ---------------- Step 3 ----------------
    print("\n[STEP 3] Creating an Action Plan...\n")
    action_plan = create_action_plan(summary)

    print("ACTION PLAN")
    print("-" * 60)
    print(action_plan)

    # ---------------- Step 4 ----------------
    print("\n[STEP 4] Generating Quiz Questions...\n")
    quiz = generate_quiz(topic)

    print("QUIZ QUESTIONS")
    print("-" * 60)
    print(quiz)

    # ---------------- Final Message ----------------
    print("\nMulti-step AI workflow completed successfully!")


# =====================================================
# Program Entry Point
# =====================================================
if __name__ == "__main__":
    main()