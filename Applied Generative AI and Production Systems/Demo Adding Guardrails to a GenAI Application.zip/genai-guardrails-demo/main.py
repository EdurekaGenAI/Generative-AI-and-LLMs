from better_profanity import profanity
import re


# -------------------------------
# Input Guardrails
# -------------------------------
def validate_input(user_input):
    if not user_input.strip():
        return False, "Input cannot be empty."

    if profanity.contains_profanity(user_input):
        return False, "Inappropriate language detected."

    blocked_patterns = [
        r"ignore previous instructions",
        r"reveal system prompt",
        r"delete all data",
        r"shutdown",
    ]

    for pattern in blocked_patterns:
        if re.search(pattern, user_input, re.IGNORECASE):
            return False, "Potential prompt injection detected."

    return True, "Input accepted."


# -------------------------------
# Mock GenAI Model
# -------------------------------
def generate_response(prompt):
    return f"AI Response: {prompt}"


# -------------------------------
# Output Guardrails
# -------------------------------
def validate_output(output):
    sensitive_patterns = [
        r"password",
        r"api[_-]?key",
        r"secret",
        r"token",
    ]

    for pattern in sensitive_patterns:
        if re.search(pattern, output, re.IGNORECASE):
            return False, "Sensitive information detected in output."

    return True, output


# -------------------------------
# Main Application
# -------------------------------
def main():
    profanity.load_censor_words()

    print("=== Adding Guardrails to a GenAI Application ===")

    user_input = input("Enter your prompt: ")

    # Step 1: Validate input
    valid_input, message = validate_input(user_input)

    if not valid_input:
        print(f"Input Blocked: {message}")
        return

    print(f"Input Check: {message}")

    # Step 2: Generate response
    raw_output = generate_response(user_input)

    # Step 3: Validate output
    valid_output, final_output = validate_output(raw_output)

    if not valid_output:
        print(f"Output Blocked: {final_output}")
        return

    print("\nFinal Safe Output:")
    print(final_output)


if __name__ == "__main__":
    main()