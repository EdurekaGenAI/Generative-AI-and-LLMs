# API Integration, Parameter Tuning & Building a Multi-Step Chain

## Overview

This project demonstrates how to build a **multi-step Generative AI workflow** using the **Groq API** and Python. It combines three important concepts used in modern AI applications:

* **API Integration** – Connecting Python with an external LLM service.
* **Parameter Tuning** – Controlling model behaviour using parameters such as `temperature`, `max_tokens`, `top_p`, and `stop`.
* **Multi-Step Chaining** – Passing the output of one AI step into the next step to create a structured workflow.

The application performs the following tasks:

1. Accepts a topic from the user.
2. Generates a professional explanation.
3. Creates a concise summary.
4. Produces an actionable learning plan.
5. Generates a short quiz for self-assessment.

This project is suitable for students learning **LLM application development, prompt engineering, and AI workflow orchestration**.

---

## Project Structure

```text
api-integration-multi-step-chain/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

### File Description

| File               | Purpose                                                       |
| ------------------ | ------------------------------------------------------------- |
| `.env`             | Stores the Groq API key securely                              |
| `.gitignore`       | Prevents sensitive and unnecessary files from being committed |
| `README.md`        | Project documentation                                         |
| `requirements.txt` | Lists Python dependencies                                     |
| `main.py`          | Contains the complete multi-step AI workflow                  |

---

## Project Workflow

```text
            User Input
                 │
                 ▼
      ┌───────────────────┐
      │ Enter a Topic     │
      └───────────────────┘
                 │
                 ▼
      ┌───────────────────┐
      │ Step 1            │
      │ Generate          │
      │ Explanation       │
      └───────────────────┘
                 │
                 ▼
      ┌───────────────────┐
      │ Step 2            │
      │ Summarise         │
      │ Explanation       │
      └───────────────────┘
                 │
                 ▼
      ┌───────────────────┐
      │ Step 3            │
      │ Create Action     │
      │ Plan              │
      └───────────────────┘
                 │
                 ▼
      ┌───────────────────┐
      │ Step 4            │
      │ Generate Quiz     │
      └───────────────────┘
                 │
                 ▼
      ┌───────────────────┐
      │ Structured AI     │
      │ Learning Output   │
      └───────────────────┘
```

### API Integration

The project connects to the **Groq LLM API** using the official Python SDK and sends prompts programmatically.

### Parameter Tuning

Different steps use different parameter values:

| Parameter     | Purpose                                  |
| ------------- | ---------------------------------------- |
| `temperature` | Controls creativity                      |
| `max_tokens`  | Limits response length                   |
| `top_p`       | Controls token diversity                 |
| `stop`        | Stops generation at a specified sequence |
