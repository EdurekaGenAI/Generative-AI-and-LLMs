from retriever import build_retriever
from retrieval_chain import retrieval_chain


def main():
    print("Building retriever...\n")

    retriever = build_retriever()

    while True:
        query = input("Ask a question (or type 'exit'): ")

        if query.lower() == "exit":
            print("Exiting application.")
            break

        print("\nSearching knowledge base...\n")

        answer = retrieval_chain(retriever, query)

        print(answer)
        print("-" * 60)


if __name__ == "__main__":
    main()