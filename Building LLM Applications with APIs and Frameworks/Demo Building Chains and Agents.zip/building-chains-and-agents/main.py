from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate

# ---------------------------------------------------
# Load environment variables
# ---------------------------------------------------
load_dotenv()

# ---------------------------------------------------
# Create Groq LLM
# ---------------------------------------------------
llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    temperature=0
)

# ===================================================
# PART 1 — BUILDING A CHAIN
# ===================================================
print("\n" + "=" * 60)
print("PART 1 — BUILDING A CHAIN")
print("=" * 60)

prompt = PromptTemplate.from_template(
    "Explain the concept of {topic} in simple beginner-friendly terms."
)

chain = prompt | llm

response = chain.invoke({"topic": "recursion"})

print("\nChain Response:\n")
print(response.content)

# ===================================================
# PART 2 — SIMPLE TOOL FUNCTIONS
# ===================================================
print("\n" + "=" * 60)
print("PART 2 — SIMPLE TOOLS")
print("=" * 60)

def calculator(expression: str) -> str:
    """Evaluate a mathematical expression."""
    try:
        return str(eval(expression))
    except Exception as e:
        return f"Error: {e}"

def weather(city: str) -> str:
    """Return mock weather information."""
    data = {
        "bangalore": "Sunny and 26°C",
        "delhi": "Cloudy and 31°C",
        "mumbai": "Rainy and 28°C",
        "chennai": "Humid and 30°C"
    }
    return data.get(city.lower(), "Weather information unavailable")

print("Calculator Tool Loaded")
print("Weather Tool Loaded")

# ===================================================
# PART 3 — BUILDING A SIMPLE AGENT
# ===================================================
print("\n" + "=" * 60)
print("PART 3 — BUILDING A SIMPLE AGENT")
print("=" * 60)

def simple_agent(query: str) -> str:
    """
    A lightweight agent that chooses which tool to use
    based on the user query.
    """

    query_lower = query.lower()

    # Weather tool
    if "weather" in query_lower:
        for city in ["bangalore", "delhi", "mumbai", "chennai"]:
            if city in query_lower:
                return weather(city)
        return "Please specify a supported city."

    # Calculator tool
    if any(symbol in query for symbol in ["+", "-", "*", "/"]):
        expression = query.replace("Calculate", "").strip()
        return calculator(expression)

    # Otherwise use the LLM directly
    response = llm.invoke(query)
    return response.content

# ---------------------------------------------------
# Example 1 — Weather
# ---------------------------------------------------
query1 = "What is the weather in Bangalore?"

print(f"\nUser Query 1: {query1}")
print("Agent Response:\n")
print(simple_agent(query1))

# ---------------------------------------------------
# Example 2 — Calculator
# ---------------------------------------------------
query2 = "Calculate 45 * 12 + 100"

print(f"\nUser Query 2: {query2}")
print("Agent Response:\n")
print(simple_agent(query2))

# ---------------------------------------------------
# Example 3 — General AI Query
# ---------------------------------------------------
query3 = "Explain why AI agents are useful in modern applications."

print(f"\nUser Query 3: {query3}")
print("Agent Response:\n")
print(simple_agent(query3))

# ===================================================
# COMPLETION MESSAGE
# ===================================================
print("\n" + "=" * 60)
print("DEMO COMPLETED SUCCESSFULLY")
print("=" * 60)

print("""
This project demonstrated:

✓ LangChain Chains using LCEL
✓ Reusable Prompt Templates
✓ Custom Tool Functions
✓ Simple Agent-Style Tool Selection
✓ LLM + Tool Integration

You have successfully built both a Chain and an Agent-style
workflow using the Groq API and modern LangChain components.
""")