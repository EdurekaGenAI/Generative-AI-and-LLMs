# Integrating Speech-to-Text and Text-to-Speech

## Overview

This project demonstrates how to integrate **Speech-to-Text (STT)** and **Text-to-Speech (TTS)** in a single Python application.

The program:

- accepts a **WAV audio file** as input,
- converts the spoken audio into **text** using `SpeechRecognition`,
- processes the recognised text,
- converts the text back into **speech** using `gTTS`,
- saves the generated audio as an **MP3 file**.

This workflow is commonly used in **voice assistants, accessibility tools, conversational AI systems, and speech-enabled applications**.

---

## Project Structure

```text
speech-text-integration/
├── audio/
│   └── sample_input.wav
├── output/
│   └── response.mp3
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

### File Description

- **audio/** — stores the input WAV audio file.
- **output/** — stores the generated MP3 response.
- **main.py** — contains the Speech-to-Text and Text-to-Speech logic.
- **requirements.txt** — lists the required Python libraries.
- **README.md** — project documentation.
- **.gitignore** — excludes unnecessary files from version control.

---

## Project Workflow

```text
          +-------------------+
          |  Input WAV Audio  |
          +---------+---------+
                    |
                    v
        +----------------------+
        |  Speech Recognition |
        |   (Speech-to-Text)  |
        +----------+-----------+
                   |
                   v
        +----------------------+
        |   Recognized Text   |
        +----------+-----------+
                   |
                   v
        +----------------------+
        |  Generate Response  |
        +----------+-----------+
                   |
                   v
        +----------------------+
        |   Text-to-Speech    |
        |       (gTTS)        |
        +----------+-----------+
                   |
                   v
        +----------------------+
        |    Output MP3 File  |
        +----------------------+
```