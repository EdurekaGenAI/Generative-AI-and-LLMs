import numpy as np
from scipy.stats import wasserstein_distance


def simulate_baseline_predictions(size):
    np.random.seed(42)
    return np.random.normal(loc=0.45, scale=0.08, size=size)


def simulate_current_predictions(size):
    np.random.seed(7)
    return np.random.normal(loc=0.63, scale=0.10, size=size)


def calculate_model_drift(
    baseline_predictions,
    current_predictions,
    threshold=0.12,
):
    score = wasserstein_distance(
        baseline_predictions,
        current_predictions,
    )

    status = "WARNING" if score > threshold else "STABLE"

    return {
        "baseline_mean": np.mean(baseline_predictions),
        "current_mean": np.mean(current_predictions),
        "drift_score": score,
        "status": status,
    }


def print_model_drift_report(result):
    print("\nMODEL DRIFT REPORT")
    print("-" * 50)
    print(f"Baseline Prediction Mean: {result['baseline_mean']:.4f}")
    print(f"Current Prediction Mean : {result['current_mean']:.4f}")
    print(f"Prediction Drift Score  : {result['drift_score']:.4f}")
    print(f"Status                  : {result['status']}")
    print("-" * 50)