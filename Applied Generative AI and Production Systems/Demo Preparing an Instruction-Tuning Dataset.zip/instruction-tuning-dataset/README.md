## Preparing an Instruction-Tuning Dataset

### Overview

This project demonstrates how to transform raw task examples into a **structured instruction-tuning dataset** suitable for training or fine-tuning Large Language Models (LLMs).

The video covers:

* Creating raw instruction examples
* Separating **instruction**, **input**, and **output**
* Formatting prompts consistently
* Exporting a clean JSON dataset for instruction tuning

---

## Project Structure

```text
instruction-tuning-dataset/
├── data/
│   └── raw_examples.json
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

## Expected Output

```text
Instruction-tuning dataset prepared successfully!
Saved to: instruction_dataset.json
```

A new file named `instruction_dataset.json` will be created.

---

## Example Formatted Entry

```json
{
  "prompt": "### Instruction:\nExplain what a database is.\n\n### Input:\n\n\n### Response:",
  "response": "A database is an organised collection of data that can be stored, managed, and retrieved efficiently."
}
```
