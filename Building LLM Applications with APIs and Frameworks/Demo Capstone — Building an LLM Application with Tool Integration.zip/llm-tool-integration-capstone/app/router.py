import re
from tools.calculator import calculate
from tools.weather import get_weather


def route_query(user_input: str):
    text = user_input.lower().strip()

    # Weather query
    if "weather" in text:
        # Extract city name and remove punctuation
        match = re.search(r"weather.*?in\s+([a-zA-Z\s]+)", text)

        if match:
            city = match.group(1).strip()
        else:
            city = "Bangalore"

        return True, get_weather(city)

    # Calculator query
    if any(op in user_input for op in ["+", "-", "*", "/"]):
        return True, calculate(user_input)

    return False, None