from difflib import SequenceMatcher


def similarity_score(reference, prediction):
    return SequenceMatcher( None, reference.lower(), prediction.lower() ).ratio()


# Load prompts
with open( "data/evaluation_prompts.txt", "r", encoding="utf-8" ) as file:
    prompts = [line.strip() for line in file if line.strip()]

# Load reference answers
with open( "data/reference_answers.txt", "r", encoding="utf-8" ) as file:
    references = [line.strip() for line in file if line.strip()]


# Simulated outputs BEFORE fine-tuning
before_outputs = [
    "Neural networks are computer programs that process information.",
    "Tokenization splits text into pieces.",
    "Training learns from data and inference predicts results.",
    "Fine-tuning changes a model for a task.",
    "Overfitting is when a model learns too much from training data."
]

# Simulated outputs AFTER fine-tuning
after_outputs = [
    "A neural network is a computer system inspired by the human brain that learns patterns from data.",
    "Tokenization converts text into smaller units such as words or subwords so models can process language.",
    "Training is the process of learning from data, while inference is using the trained model to make predictions.",
    "Fine-tuning adapts a pre-trained model to a specific task or domain using additional training data.",
    "Overfitting happens when a model memorizes training data and performs poorly on new unseen data."
]


before_scores = []
after_scores = []

print("\n=== Model Quality Evaluation ===\n")

for index, prompt in enumerate(prompts):

    before_score = similarity_score( references[index], before_outputs[index] )

    after_score = similarity_score( references[index], after_outputs[index] )

    before_scores.append(before_score)
    after_scores.append(after_score)

    print(f"Prompt {index + 1}: {prompt}")
    print(f"Before Fine-Tuning Score : {before_score:.2f}")
    print(f"After Fine-Tuning Score  : {after_score:.2f}")
    print("-" * 60)


average_before = sum(before_scores) / len(before_scores)
average_after = sum(after_scores) / len(after_scores)

print("\n=== Average Results ===")
print(f"Average Before Fine-Tuning : {average_before:.2f}")
print(f"Average After Fine-Tuning  : {average_after:.2f}")

improvement = ( (average_after - average_before) / average_before ) * 100

print(f"Improvement                : {improvement:.2f}%")