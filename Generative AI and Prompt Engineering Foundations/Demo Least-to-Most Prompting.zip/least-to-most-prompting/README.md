# Demo: Least-to-Most Prompting

## Overview

This project demonstrates **Least-to-Most Prompting**, an advanced prompt engineering technique that enables a Large Language Model (LLM) to solve complex problems by breaking them into a sequence of simpler, manageable subtasks. Instead of expecting the model to generate the complete solution in a single response, the prompt guides it through a logical progression of intermediate steps, where each step builds upon the previous one.

In this project, we use the **Groq API** with the **Llama 3.3 70B Versatile** model to implement Least-to-Most Prompting. The application sends a carefully designed prompt to the model, allowing it to reason incrementally and produce a well-structured, accurate final answer.

---

# Project Structure

```text
Least-to-Most-Prompting/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

---

# Project Workflow

```text
                                   Start
                                      │
                                      ▼
                     Create Project Directory
                                      │
                                      ▼
                 Create Virtual Environment
                                      │
                                      ▼
                Install Required Libraries
                                      │
                                      ▼
             Configure the `.env` File
             (Store the Groq API Key)
                                      │
                                      ▼
           Load Environment Variables
                                      │
                                      ▼
              Initialise the Groq Client
                                      │
                                      ▼
      Select the Llama 3.3 70B Versatile Model
                                      │
                                      ▼
         Define the Complex Reasoning Problem
                                      │
                                      ▼
       Construct the Least-to-Most Prompt
      (Break the Problem into Smaller Steps)
                                      │
                                      ▼
              Send Prompt to Groq API
                                      │
                                      ▼
      LLM Solves Each Subtask Sequentially
                                      │
                                      ▼
       Combine Intermediate Reasoning Steps
                                      │
                                      ▼
          Generate the Final Structured Answer
                                      │
                                      ▼
             Display the Output in Terminal
                                      │
                                      ▼
                                      End
```

---