from chunking import (
    fixed_size_chunks,
    sentence_based_chunks,
    overlapping_chunks
)
from retrieval import retrieve


with open("sample_document.txt", "r", encoding="utf-8") as file:
    document = file.read()


query = "How does overlapping chunking preserve context?"


strategies = {
    "Fixed-size Chunking": fixed_size_chunks(document),
    "Sentence-based Chunking": sentence_based_chunks(document),
    "Overlapping Chunking": overlapping_chunks(document)
}


print("User Query:", query)

for strategy_name, chunks in strategies.items():
    print("\\n" + "=" * 60)
    print(strategy_name)
    print("=" * 60)

    results = retrieve(query, chunks)

    for rank, (chunk, score) in enumerate(results, start=1):
        print(f"\\n{rank}. Similarity Score: {score:.4f}")
        print(chunk)