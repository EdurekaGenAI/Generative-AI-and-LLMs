import os
import speech_recognition as sr
from gtts import gTTS


def speech_to_text(audio_file):
    recognizer = sr.Recognizer()

    with sr.AudioFile(audio_file) as source:
        print("Converting audio into text...")
        audio = recognizer.record(source)

    try:
        text = recognizer.recognize_google(audio)
        print(f"Recognized Text: {text}")
        return text

    except sr.UnknownValueError:
        print("Could not understand the audio.")
        return ""

    except sr.RequestError as error:
        print(f"Speech recognition service error: {error}")
        return ""


def text_to_speech(text, output_file):
    tts = gTTS(text=text, lang="en")
    tts.save(output_file)
    print(f"Audio generated successfully: {output_file}")


if __name__ == "__main__":
    os.makedirs("output", exist_ok=True)

    input_audio = "audio/sample.wav"
    output_audio = "output/user_response.mp3"

    print("===== STEP 1: Speech-to-Text =====")
    converted_text = speech_to_text(input_audio)

    print("\n===== STEP 2: Text-to-Speech =====")
    user_text = input("Enter any text to convert into speech: ")

    if user_text.strip():
        text_to_speech(user_text, output_audio)
    else:
        print("No text entered.")