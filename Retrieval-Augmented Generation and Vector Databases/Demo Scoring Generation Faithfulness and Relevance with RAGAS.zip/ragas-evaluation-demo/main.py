import os

# Disable ChromaDB telemetry warnings
os.environ["ANONYMIZED_TELEMETRY"] = "False"

from dotenv import load_dotenv
load_dotenv()

from datasets import Dataset
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy

from langchain_groq import ChatGroq
from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma


# ==================================================
# Load knowledge base
# ==================================================

loader = TextLoader("knowledge_base.txt", encoding="utf-8")
documents = loader.load()


# ==================================================
# Split documents into chunks
# ==================================================

splitter = CharacterTextSplitter(
    chunk_size=300,
    chunk_overlap=50
)

chunks = splitter.split_documents(documents)


# ==================================================
# Create HuggingFace embeddings
# ==================================================

embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)


# ==================================================
# Create Chroma vector store
# ==================================================

vectorstore = Chroma.from_documents(
    documents=chunks,
    embedding=embeddings,
    persist_directory="chroma_db"
)


# ==================================================
# User question
# ==================================================

question = "What is Retrieval-Augmented Generation?"


# ==================================================
# Retrieve relevant context
# ==================================================

retriever = vectorstore.as_retriever(search_kwargs={"k": 2})
retrieved_docs = retriever.invoke(question)

contexts = [doc.page_content for doc in retrieved_docs]


# ==================================================
# Generated answer
# ==================================================

generated_answer = (
    "Retrieval-Augmented Generation combines information retrieval "
    "with a language model to generate grounded responses using "
    "external knowledge sources."
)


# ==================================================
# Create dataset for RAGAS
# ==================================================

dataset = Dataset.from_dict({
    "question": [question],
    "answer": [generated_answer],
    "contexts": [contexts]
})


# ==================================================
# Configure Groq LLM
# ==================================================

llm = ChatGroq(
    model_name="llama-3.1-8b-instant",
    groq_api_key=os.getenv("GROQ_API_KEY")
)


# ==================================================
# Evaluate using RAGAS
# ==================================================

result = evaluate(
    dataset=dataset,
    metrics=[faithfulness, answer_relevancy],
    llm=llm,
    embeddings=embeddings
)


# ==================================================
# Display results
# ==================================================

print("\n" + "=" * 60)
print("RAGAS EVALUATION DEMO (GROQ)")
print("=" * 60)

print("\nQuestion:")
print(question)

print("\nGenerated Answer:")
print(generated_answer)

print("\nRetrieved Context:")
for i, context in enumerate(contexts, start=1):
    print(f"\nContext {i}:")
    print(context)


# Convert result to DataFrame
scores = result.to_pandas()

print("\n" + "-" * 60)
print("RAGAS EVALUATION SCORES")
print("-" * 60)

print(f"Faithfulness      : {scores['faithfulness'][0]:.4f}")
print(f"Answer Relevancy  : {scores['answer_relevancy'][0]:.4f}")

print("-" * 60)