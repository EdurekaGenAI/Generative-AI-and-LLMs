from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


def calculate_similarity(model, sentence1, sentence2):
    """Generate embeddings and compute cosine similarity."""

    embeddings = model.encode([sentence1, sentence2])

    score = cosine_similarity(
        [embeddings[0]],
        [embeddings[1]]
    )[0][0]

    return score


def main():
    print("Semantic Similarity in Vector Space")
    print("-" * 50)

    print("Loading embedding model...")

    # Lightweight and widely used embedding model
    model = SentenceTransformer("all-MiniLM-L6-v2")

    print("Model loaded successfully.\n")

    # Example sentence pairs
    examples = [
        (
            "Artificial intelligence is transforming education.",
            "AI is changing the way students learn."
        ),
        (
            "Artificial intelligence is transforming education.",
            "The weather is sunny today."
        ),
        (
            "I enjoy reading books about machine learning.",
            "Studying artificial intelligence through books is enjoyable."
        ),
        (
            "Python is a popular programming language.",
            "Many developers use Python for software development."
        )
    ]

    print("Measuring semantic similarity...\n")

    for index, (sentence1, sentence2) in enumerate(examples, start=1):
        score = calculate_similarity(model, sentence1, sentence2)

        print(f"Example {index}")
        print(f"Sentence 1 : {sentence1}")
        print(f"Sentence 2 : {sentence2}")
        print(f"Similarity  : {score:.2f}")

        if score >= 0.75:
            print("Interpretation : Highly similar")
        elif score >= 0.40:
            print("Interpretation : Moderately similar")
        else:
            print("Interpretation : Semantically different")

        print("-" * 50)

    # Interactive section
    print("\nTry your own sentences")
    print("-" * 50)

    sentence1 = input("Enter the first sentence: ")
    sentence2 = input("Enter the second sentence: ")

    score = calculate_similarity(model, sentence1, sentence2)

    print("\nResult")
    print("-" * 50)
    print(f"Sentence 1 : {sentence1}")
    print(f"Sentence 2 : {sentence2}")
    print(f"Similarity Score : {score:.2f}")

    if score >= 0.75:
        print("These sentences express very similar meanings.")
    elif score >= 0.40:
        print("These sentences share some related meaning.")
    else:
        print("These sentences are mostly unrelated in meaning.")


if __name__ == "__main__":
    main()