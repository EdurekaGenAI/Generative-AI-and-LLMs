# Demo: Defending Against Prompt Injection

## Overview

Prompt injection is a technique where a user attempts to manipulate a Large Language Model (LLM) by providing instructions that override or conflict with the application's intended behaviour. These attacks often aim to reveal hidden system prompts, bypass safety rules, or force the model to perform unintended actions.

In this project, you will build a secure LLM application using the **Groq API** and the **Llama 3.3 70B Versatile** model. The application uses a carefully designed **system prompt** that establishes fixed security rules before processing any user input. The project compares the model's behaviour when handling a legitimate request and a prompt injection attempt, demonstrating how instruction hierarchy helps protect LLM-powered applications.

---

# Project Structure

```text
defending-against-prompt-injection/
│
├── .env
├── .gitignore
├── main.py
├── README.md
└── requirements.txt
```
---

# Project Workflow

```text
                                    START
                                      │
                                      ▼
                      Load Environment Variables (.env)
                                      │
                                      ▼
                          Retrieve Groq API Key
                                      │
                                      ▼
                         Create the Groq API Client
                                      │
                                      ▼
                     Configure the Llama 3.3 70B Model
                                      │
                                      ▼
                     Define the Secure System Prompt
                                      │
                                      ▼
                Prepare the Normal User Question
                                      │
                                      ▼
              Prepare the Prompt Injection Attempt
                                      │
                                      ▼
           Send System Prompt + User Prompt to Groq
                                      │
                                      ▼
                 LLM Processes Both Instructions
                                      │
                                      ▼
                System Prompt Takes Highest Priority
                                      │
                                      ▼
                    Is the User Prompt Malicious?
                           ┌──────────┴──────────┐
                           │                     │
                         Yes                     No
                           │                     │
                           ▼                     ▼
          Reject the Prompt Injection     Generate a Helpful
                  Attempt                    Response
                           │                     │
                           └──────────┬──────────┘
                                      │
                                      ▼
                    Display the Assistant Response
                                      │
                                      ▼
          Demonstrate Protection Against Prompt Injection
                                      │
                                      ▼
                                     END
```