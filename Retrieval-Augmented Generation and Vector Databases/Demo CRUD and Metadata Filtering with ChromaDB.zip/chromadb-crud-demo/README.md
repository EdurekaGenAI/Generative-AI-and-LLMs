# CRUD and Metadata Filtering with ChromaDB

## Overview

This project demonstrates how to use **ChromaDB** for:

* **Create** → Insert documents into a collection
* **Read** → Retrieve documents from the collection
* **Update** → Modify existing documents and metadata
* **Delete** → Remove documents from the collection
* **Metadata Filtering** → Retrieve documents using metadata conditions

ChromaDB is a lightweight **vector database** widely used in **Retrieval-Augmented Generation (RAG)** applications, semantic search systems, and AI-powered knowledge assistants.

---

## Project Structure

```text
chromadb-crud-demo/
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

## Project Workflow

```text
Start
   |
   v
Create ChromaDB Client
   |
   v
Create Collection
   |
   v
Insert Documents + Metadata
   |
   v
Read Documents
   |
   v
Similarity Search
   |
   v
Metadata Filtering
   |
   v
Update Document
   |
   v
Delete Document
   |
   v
Display Final Collection
   |
   v
End
```

---

## Example Documents

The project stores four sample documents:

| ID   | Department  | Level        |
| ---- | ----------- | ------------ |
| doc1 | Programming | Beginner     |
| doc2 | AI          | Intermediate |
| doc3 | AI          | Advanced     |
| doc4 | DevOps      | Intermediate |

Each document is stored together with its metadata.

---

## Expected Output

```text
========== CREATE ==========
Documents inserted successfully.

========== READ ==========
Total documents: 4

========== SIMILARITY SEARCH ==========
Result 1: Python supports object-oriented programming.

========== METADATA FILTER ==========
Document: ChromaDB is useful for vector search applications.

========== UPDATE ==========
Updated document:
ChromaDB enables efficient semantic vector search.

========== DELETE ==========
Remaining documents: 3

========== FINAL COLLECTION ==========
doc1 -> Python supports object-oriented programming.
doc2 -> ChromaDB enables efficient semantic vector search.
doc3 -> Machine learning models require quality data.
```

---

## CRUD Operations Explained

### Create

```python
collection.add(...)
```

Adds new documents, IDs, and metadata to the collection.

### Read

```python
collection.get()
```

Retrieves all stored documents and metadata.

### Update

```python
collection.update(...)
```

Updates an existing document and its associated metadata.

### Delete

```python
collection.delete(ids=["doc4"])
```

Removes a document permanently from the collection.

---

## Metadata Filtering

Metadata filtering allows retrieval of documents that match specific conditions.

Example:

```python
collection.get(where={"department": "AI"})
```

This returns only documents whose **department** metadata is **AI**.

---

## Semantic Similarity Search

The project performs semantic retrieval using:

```python
collection.query(
    query_texts=["What is object-oriented programming in Python?"],
    n_results=2
)
```

ChromaDB automatically converts both the query and documents into vector embeddings and returns the most semantically similar results.

---

