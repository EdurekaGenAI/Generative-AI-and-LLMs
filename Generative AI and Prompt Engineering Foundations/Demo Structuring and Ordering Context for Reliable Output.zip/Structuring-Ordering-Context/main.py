import os

from dotenv import load_dotenv
from groq import Groq

# ------------------------------------------------------------------
# Load Environment Variables
# ------------------------------------------------------------------

load_dotenv()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

MODEL = "llama-3.3-70b-versatile"


# ------------------------------------------------------------------
# Helper Functions
# ------------------------------------------------------------------

def generate_response(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0.2,
        max_tokens=700
    )

    return response.choices[0].message.content


def print_header():
    print("=" * 80)
    print("PROMPT ENGINEERING DEMO")
    print("Structuring and Ordering Context for Reliable Output")
    print("=" * 80)


def print_section(title):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)


# ------------------------------------------------------------------
# Main Program
# ------------------------------------------------------------------

def main():

    print_header()

    unstructured_prompt = """
A software company is launching an AI-powered meeting assistant.

It automatically records meetings.

It creates summaries.

It extracts action items.

Users include project managers, developers, HR teams and executives.

The application integrates with Zoom, Google Meet and Microsoft Teams.

Enterprise customers require end-to-end encryption.

The company follows GDPR.

The product supports English, Spanish and French.

The monthly subscription starts at $19.

The launch is planned for September.

Write a product overview.
"""

    structured_prompt = """
# ROLE

You are a senior technical content writer.

# TASK

Write a professional product overview for an AI-powered meeting assistant.

# PRODUCT INFORMATION

Product Name:
MeetMind AI

Core Features:
- Automatically records meetings
- Generates concise meeting summaries
- Extracts action items
- Identifies key discussion points

Target Users:
- Project Managers
- Software Developers
- HR Teams
- Business Executives

Integrations:
- Zoom
- Google Meet
- Microsoft Teams

Security:
- End-to-end encryption for enterprise customers
- GDPR compliant

Supported Languages:
- English
- Spanish
- French

Pricing:
- Starts at $19 per month

Launch Timeline:
- September

# RESPONSE REQUIREMENTS

Organise the response using the following headings:

1. Product Overview
2. Key Features
3. Target Audience
4. Security and Compliance
5. Pricing
6. Launch Information

Use a professional tone.
Keep the response concise.
"""

    print_section("SCENARIO 1 : UNSTRUCTURED CONTEXT")

    response_one = generate_response(unstructured_prompt)

    print(response_one)

    print_section("SCENARIO 2 : STRUCTURED CONTEXT")

    response_two = generate_response(structured_prompt)

    print(response_two)

    print_section("OBSERVATIONS")

    print("""
Compare both responses carefully.

Notice how the structured prompt provides:

• Better organisation of information
• More complete coverage of important details
• Improved readability
• Consistent formatting
• Reduced ambiguity
• Higher quality output

The information supplied to the model is almost identical.

The primary difference is how the context has been organised before sending it to the LLM.
""")

    print_section("KEY LEARNING")

    print("""
A well-structured prompt typically follows this sequence:

1. Define the role.
2. Clearly describe the task.
3. Organise the context into logical sections.
4. Group related information together.
5. Specify the desired output format.
6. Add any constraints or response guidelines.

Better prompt structure often leads to more reliable, consistent, and professional responses.
""")


if __name__ == "__main__":
    main()