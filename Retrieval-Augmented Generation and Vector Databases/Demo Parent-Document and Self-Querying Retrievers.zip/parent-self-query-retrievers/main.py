from pathlib import Path

from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma

# --------------------------------------------------
# Load documents
# --------------------------------------------------

docs = [
    Document(
        page_content=Path("documents/ai_search.txt").read_text(encoding="utf-8"),
        metadata={"topic": "retrieval", "level": "intermediate"},
    ),
    Document(
        page_content=Path("documents/llm_memory.txt").read_text(encoding="utf-8"),
        metadata={"topic": "memory", "level": "beginner"},
    ),
    Document(
        page_content=Path("documents/vector_databases.txt").read_text(encoding="utf-8"),
        metadata={"topic": "database", "level": "beginner"},
    ),
]

# --------------------------------------------------
# Split documents into chunks
# --------------------------------------------------

splitter = RecursiveCharacterTextSplitter(
    chunk_size=150,
    chunk_overlap=30,
)

chunks = splitter.split_documents(docs)

# --------------------------------------------------
# Embedding model
# --------------------------------------------------

embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

# --------------------------------------------------
# Create Chroma vector store
# --------------------------------------------------

vectorstore = Chroma.from_documents(
    documents=chunks,
    embedding=embeddings,
    persist_directory="chroma_db",
)

# --------------------------------------------------
# Parent-style semantic retrieval
# --------------------------------------------------

print("\n=== Parent-Style Retrieval ===")

results = vectorstore.similarity_search(
    "Explain semantic search and hybrid retrieval",
    k=2,
)

for i, doc in enumerate(results, start=1):
    print(f"\nResult {i}:")
    print(f"Metadata: {doc.metadata}")
    print(doc.page_content.strip())

# --------------------------------------------------
# Self-query style metadata filtering
# --------------------------------------------------

print("\n=== Self-Query Style Retrieval ===")

filtered_results = vectorstore.similarity_search(
    "memory",
    k=2,
    filter={"topic": "memory"},
)

for i, doc in enumerate(filtered_results, start=1):
    print(f"\nFiltered Result {i}:")
    print(f"Metadata: {doc.metadata}")
    print(doc.page_content.strip())

print("\nDemo completed successfully.")