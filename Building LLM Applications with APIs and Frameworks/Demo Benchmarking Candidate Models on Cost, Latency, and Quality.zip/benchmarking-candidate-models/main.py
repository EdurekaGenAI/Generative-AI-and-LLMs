import os
import time
import requests
from dotenv import load_dotenv
from groq import Groq
from tabulate import tabulate
from google import genai


# ---------------------------------------------------
# Load environment variables
# ---------------------------------------------------
load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
NVIDIA_API_KEY = os.getenv("NVIDIA_API_KEY")


# ---------------------------------------------------
# Configure clients
# ---------------------------------------------------
groq_client = Groq(api_key=GROQ_API_KEY)
gemini_client = genai.Client(api_key=GEMINI_API_KEY)


# ---------------------------------------------------
# Benchmark prompt
# ---------------------------------------------------
PROMPT = (
    "Explain the importance of benchmarking AI models for "
    "production systems in about 100 words."
)


# ---------------------------------------------------
# Simple quality heuristic
# ---------------------------------------------------
def quality_score(text: str) -> int:
    words = len(text.split())

    score = 0

    if 70 <= words <= 130:
        score += 4

    if "benchmark" in text.lower():
        score += 2

    if "production" in text.lower():
        score += 2

    if text.strip().endswith("."):
        score += 2

    return min(score, 10)


# ---------------------------------------------------
# Groq benchmark
# ---------------------------------------------------
def benchmark_groq():
    start = time.perf_counter()

    response = groq_client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {"role": "user", "content": PROMPT}
        ],
        temperature=0.3,
        max_tokens=150,
    )

    latency = (time.perf_counter() - start) * 1000

    output = response.choices[0].message.content

    return {
        "Model": "Groq - Llama 3.1 8B",
        "Latency (ms)": round(latency, 2),
        "Tokens": response.usage.total_tokens,
        "Quality (/10)": quality_score(output),
    }


# ---------------------------------------------------
# OpenRouter benchmark
# ---------------------------------------------------
def benchmark_openrouter():
    start = time.perf_counter()

    response = requests.post(
        "https://openrouter.ai/api/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "Content-Type": "application/json",
        },
        json={
            "model": "meta-llama/llama-3.1-8b-instruct",
            "messages": [
                {"role": "user", "content": PROMPT}
            ],
        },
        timeout=60,
    )

    latency = (time.perf_counter() - start) * 1000

    data = response.json()
    output = data["choices"][0]["message"]["content"]

    return {
        "Model": "OpenRouter - Llama 3.1 8B",
        "Latency (ms)": round(latency, 2),
        "Tokens": len(output.split()),
        "Quality (/10)": quality_score(output),
    }


# ---------------------------------------------------
# Gemini benchmark
# ---------------------------------------------------
def benchmark_gemini():
    start = time.perf_counter()

    response = gemini_client.models.generate_content(
        model="gemini-3.5-flash",
        contents=PROMPT
    )

    latency = (time.perf_counter() - start) * 1000

    output = response.text

    return {
        "Model": "Gemini 3.5 Flash",
        "Latency (ms)": round(latency, 2),
        "Tokens": len(output.split()),
        "Quality (/10)": quality_score(output),
    }


# ---------------------------------------------------
# NVIDIA NIM - MiniMax M3 benchmark
# ---------------------------------------------------
def benchmark_nvidia_minimax():
    start = time.perf_counter()

    response = requests.post(
        "https://integrate.api.nvidia.com/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {NVIDIA_API_KEY}",
            "Content-Type": "application/json",
        },
        json={
            "model": "minimax/minimax-m3",
            "messages": [
                {"role": "user", "content": PROMPT}
            ],
            "temperature": 0.3,
            "max_tokens": 150,
        },
        timeout=60,
    )

    latency = (time.perf_counter() - start) * 1000

    data = response.json()
    output = data["choices"][0]["message"]["content"]

    return {
        "Model": "NVIDIA NIM - MiniMax M3",
        "Latency (ms)": round(latency, 2),
        "Tokens": len(output.split()),
        "Quality (/10)": quality_score(output),
    }


# ---------------------------------------------------
# Main benchmark runner
# ---------------------------------------------------
def main():
    print("\n📊 Benchmarking Candidate Models\n")

    results = []

    benchmarks = [
        ("Groq", benchmark_groq),
        ("OpenRouter", benchmark_openrouter),
        ("Gemini", benchmark_gemini),
        ("NVIDIA MiniMax M3", benchmark_nvidia_minimax),
    ]

    for name, func in benchmarks:
        print(f"Running benchmark for: {name}")

        try:
            results.append(func())

        except Exception as e:
            print(f"Error benchmarking {name}: {e}")

    if not results:
        print("No results available.")
        return

    ranked = sorted(
        results,
        key=lambda x: (-x["Quality (/10)"], x["Latency (ms)"])
    )

    print("\n🏆 Benchmark Results\n")

    print(tabulate(ranked, headers="keys", tablefmt="grid"))

    best = ranked[0]

    print("\n🎯 Recommended Model")
    print(f"Model   : {best['Model']}")
    print(f"Quality : {best['Quality (/10)']}/10")
    print(f"Latency : {best['Latency (ms)']} ms")


if __name__ == "__main__":
    main()