# Preparing a GenAI Container for Deployment

## Overview

This project demonstrates how to prepare a Generative AI application for deployment using Docker.

The application is built with **FastAPI** and integrates with the **Groq API** to generate responses from a large language model. Docker is used to package the application, its dependencies, and runtime configuration into a reproducible container.

The project covers the complete workflow from building the FastAPI service to creating a Docker image, running the container, exposing the API through a host port, and testing the containerised GenAI application.

The Groq API key is provided through an environment file so that sensitive credentials are not included in the Docker image.

## Project Structure

```text
cloud-container-demo/
│
├── main.py
├── requirements.txt
├── Dockerfile
├── .dockerignore
├── .env
└── README.md
```


## Project Workflow

```text
User Prompt
     ↓
FastAPI Application
     ↓
/generate Endpoint
     ↓
Groq API
     ↓
GPT-OSS-20B Model
     ↓
Generated Response
```

### Docker Workflow

```text
FastAPI Application
        ↓
requirements.txt
        ↓
Dockerfile
        ↓
Docker Build
        ↓
Docker Image
genai-groq-docker
        ↓
Docker Container
genai-app
        ↓
Port Mapping
8080 → 8000
        ↓
FastAPI Swagger UI
http://localhost:8080/docs
```

## API Endpoints

### GET `/`

Returns a basic message confirming that the GenAI API is running.

### GET `/health`

Returns the health status of the application.

### POST `/generate`

Accepts a prompt and sends it to the Groq model.

Example request:

```json
{
  "prompt": "Explain Generative AI in two sentences."
}
```

Example response:

```json
{
  "model": "openai/gpt-oss-20b",
  "prompt": "Explain Generative AI in two sentences.",
  "response": "Generative AI refers to..."
}
```

## Running the Project

Build the Docker image:

```bash
docker build -t genai-groq-docker .
```

Run the container:

```bash
docker run -d --env-file .env -p 8080:8000 --name genai-app genai-groq-docker
```

Check the running container:

```bash
docker ps
```

View application logs:

```bash
docker logs genai-app
```

Open the FastAPI documentation:

```text
http://localhost:8080/docs
```

## Environment Configuration

The `.env` file should contain:

```env
GROQ_API_KEY=your_actual_groq_api_key
```

The `.env` file is excluded from the Docker image through `.dockerignore`. The API key is supplied to the running container using the `--env-file` option.

## Expected Outcome

After starting the container, the FastAPI application should be accessible through the Swagger interface at:

```text
http://localhost:8080/docs
```

The `/health` endpoint confirms that the containerised application is running, while the `/generate` endpoint sends prompts to the Groq API and returns generated responses.
