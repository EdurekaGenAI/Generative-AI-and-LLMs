import numpy as np
from scipy.stats import wasserstein_distance


def calculate_feature_drift(baseline_df, production_df, threshold=0.15):
    report = []

    numeric_columns = baseline_df.select_dtypes(include=["number"]).columns

    for column in numeric_columns:
        baseline_values = baseline_df[column]
        production_values = production_df[column]

        baseline_mean = np.mean(baseline_values)
        production_mean = np.mean(production_values)

        drift_score = wasserstein_distance(
            baseline_values,
            production_values,
        )

        normalized_score = drift_score / (np.std(baseline_values) + 1e-6)

        status = "DRIFT DETECTED" if normalized_score > threshold else "STABLE"

        report.append(
            {
                "feature": column,
                "baseline_mean": baseline_mean,
                "production_mean": production_mean,
                "drift_score": normalized_score,
                "status": status,
            }
        )

    return report


def print_data_drift_report(report):
    print("\nDATA DRIFT REPORT")
    print("-" * 50)

    for item in report:
        print(f"Feature: {item['feature']}")
        print(f"Baseline Mean : {item['baseline_mean']:.2f}")
        print(f"Production Mean: {item['production_mean']:.2f}")
        print(f"Drift Score   : {item['drift_score']:.4f}")
        print(f"Status        : {item['status']}")
        print("-" * 50)