import chromadb

# Create ChromaDB client
client = chromadb.PersistentClient(path="chroma_db")

# Delete collection if it already exists
try:
    client.delete_collection("training_collection")
except:
    pass

# Create collection
collection = client.create_collection("training_collection")

# CREATE
print("\n========== CREATE ==========")

documents = [
    "Python supports object-oriented programming.",
    "ChromaDB is useful for vector search applications.",
    "Machine learning models require quality data.",
    "Docker helps package applications consistently."
]

ids = ["doc1", "doc2", "doc3", "doc4"]

metadatas = [
    {"department": "Programming", "level": "Beginner"},
    {"department": "AI", "level": "Intermediate"},
    {"department": "AI", "level": "Advanced"},
    {"department": "DevOps", "level": "Intermediate"}
]

collection.add(
    documents=documents,
    ids=ids,
    metadatas=metadatas
)

print("Documents inserted successfully.")

# READ
print("\n========== READ ==========")

all_docs = collection.get()
print(f"Total documents: {len(all_docs['ids'])}")

for doc_id, doc, meta in zip(
    all_docs["ids"],
    all_docs["documents"],
    all_docs["metadatas"]
):
    print(f"\nID: {doc_id}")
    print(f"Document: {doc}")
    print(f"Metadata: {meta}")

# SIMILARITY SEARCH
print("\n========== SIMILARITY SEARCH ==========")

results = collection.query(
    query_texts=["What is object-oriented programming in Python?"],
    n_results=2
)

for i, doc in enumerate(results["documents"][0], start=1):
    print(f"Result {i}: {doc}")

# METADATA FILTERING
print("\n========== METADATA FILTER ==========")

ai_docs = collection.get(where={"department": "AI"})

for doc, meta in zip(ai_docs["documents"], ai_docs["metadatas"]):
    print(f"Document: {doc}")
    print(f"Metadata: {meta}")

# UPDATE
print("\n========== UPDATE ==========")

collection.update(
    ids=["doc2"],
    documents=["ChromaDB enables efficient semantic vector search."],
    metadatas=[
        {
            "department": "AI",
            "level": "Advanced",
            "updated": True
        }
    ]
)

updated = collection.get(ids=["doc2"])

print("Updated document:")
print(updated["documents"][0])
print(updated["metadatas"][0])

# DELETE
print("\n========== DELETE ==========")

collection.delete(ids=["doc4"])

remaining = collection.get()
print(f"Remaining documents: {len(remaining['ids'])}")

# FINAL COLLECTION
print("\n========== FINAL COLLECTION ==========")

for doc_id, doc in zip(remaining["ids"], remaining["documents"]):
    print(f"{doc_id} -> {doc}")