import logging
import time
import uuid
from pathlib import Path

from fastapi import FastAPI
from pydantic import BaseModel


# ============================================================
# Logger Configuration
# ============================================================

LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

LOG_FILE = LOG_DIR / "genai_app.log"

logger = logging.getLogger("genai_monitoring")
logger.setLevel(logging.INFO)

formatter = logging.Formatter(
    "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)

file_handler = logging.FileHandler(LOG_FILE)
file_handler.setFormatter(formatter)

console_handler = logging.StreamHandler()
console_handler.setFormatter(formatter)

logger.addHandler(file_handler)
logger.addHandler(console_handler)


# ============================================================
# FastAPI Application
# ============================================================

app = FastAPI(
    title="GenAI Tracing and Monitoring Demo",
    description="A simple GenAI application with request tracing and monitoring.",
    version="1.0.0"
)


# ============================================================
# Request Model
# ============================================================

class PromptRequest(BaseModel):
    prompt: str


# ============================================================
# Monitoring Functions
# ============================================================

def trace_request(prompt: str):
    request_id = str(uuid.uuid4())[:8]

    start_time = time.time()

    logger.info(
        f"TRACE START | request_id={request_id}"
    )

    logger.info(
        f"PROMPT | request_id={request_id} | prompt={prompt}"
    )

    return request_id, start_time


def trace_response(
    request_id: str,
    start_time: float,
    response: str
):
    processing_time = round(
        time.time() - start_time,
        3
    )

    logger.info(
        f"RESPONSE | request_id={request_id} | response={response}"
    )

    logger.info(
        f"TRACE END | request_id={request_id} | "
        f"processing_time={processing_time}s"
    )

    return processing_time


# ============================================================
# Simple GenAI Response Function
# ============================================================

def generate_response(prompt: str) -> str:
    """
    Simulates a GenAI model response.

    The prompt is reversed so that the tracing and
    monitoring behaviour can be demonstrated without
    requiring an external AI API or API key.
    """

    return f"AI Response: {prompt[::-1]}"


# ============================================================
# Health Check Endpoint
# ============================================================

@app.get("/health")
def health_check():

    logger.info("HEALTH CHECK | Application is healthy")

    return {
        "status": "healthy",
        "message": "GenAI application is running"
    }


# ============================================================
# GenAI Generate Endpoint
# ============================================================

@app.post("/generate")
def generate(request: PromptRequest):

    request_id, start_time = trace_request(
        request.prompt
    )

    try:

        response = generate_response(
            request.prompt
        )

        processing_time = trace_response(
            request_id,
            start_time,
            response
        )

        return {
            "request_id": request_id,
            "prompt": request.prompt,
            "response": response,
            "processing_time_seconds": processing_time,
            "status": "success"
        }

    except Exception as error:

        logger.error(
            f"ERROR | request_id={request_id} | "
            f"error={str(error)}"
        )

        return {
            "request_id": request_id,
            "status": "error",
            "message": str(error)
        }


# ============================================================
# Application Startup
# ============================================================

@app.on_event("startup")
def startup_event():

    logger.info(
        "APPLICATION STARTED | "
        "GenAI monitoring service is running"
    )


@app.on_event("shutdown")
def shutdown_event():

    logger.info(
        "APPLICATION STOPPED | "
        "GenAI monitoring service has stopped"
    )