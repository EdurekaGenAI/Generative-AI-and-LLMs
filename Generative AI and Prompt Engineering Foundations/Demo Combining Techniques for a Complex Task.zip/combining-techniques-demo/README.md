# Overview

In enterprise AI applications, solving complex tasks often requires combining multiple prompt engineering techniques rather than relying on a single prompting strategy. This project demonstrates how to integrate several techniques into a unified workflow to build an intelligent **AI Resume Screening System**.

The application compares a candidate's resume with a job description, evaluates the candidate's qualifications, identifies strengths and weaknesses, calculates an overall match score, and generates a professional hiring recommendation.

To improve the quality and consistency of the generated response, the prompt combines multiple techniques including **Role Prompting**, **Delimiters**, **Few-Shot Prompting**, **Chain-of-Thought Guidance**, **Structured Output Formatting**, and **Temperature Control**. The application uses the **Groq API** with the **Llama 3.3 70B Versatile** model to perform the analysis.

---

# Project Structure

```text
combining-techniques-demo/
│
├── main.py              # Main application source code
├── README.md            # Project documentation
├── requirements.txt     # Python dependencies
├── .env                 # Groq API key
└── .gitignore           # Files ignored by Git
```

---

# Project Workflow

```text
                      Start
                        │
                        ▼
          Load Environment Variables
                        │
                        ▼
             Initialize Groq Client
                        │
                        ▼
        Define Job Description & Resume
                        │
                        ▼
     Build Combined Prompt Using Multiple
      Prompt Engineering Techniques
                        │
        ┌───────────────┼────────────────┐
        │               │                │
        ▼               ▼                ▼
  Role Prompting   Delimiters     Few-Shot Example
        │               │                │
        └───────────────┼────────────────┘
                        │
                        ▼
          Chain-of-Thought Guidance
                        │
                        ▼
       Structured Output Instructions
                        │
                        ▼
        Send Prompt to Groq API (Llama 3.3)
                        │
                        ▼
          AI Resume Screening Report
                        │
                        ▼
      Match Score • Strengths • Weaknesses
      Recommendation • Hiring Decision
                        │
                        ▼
                       End
```