from app.router import route_query
from app.llm import generate_response


def print_banner():
    print("=" * 55)
    print("  CAPSTONE — LLM APPLICATION WITH TOOL INTEGRATION")
    print("=" * 55)
    print("Available tools:")
    print("  • Weather information")
    print("  • Calculator")
    print("  • General AI assistant")
    print("Type 'exit' to quit.\\n")


def main():
    print_banner()

    while True:
        user_input = input("You > ").strip()

        if user_input.lower() in ["exit", "quit"]:
            print("\\nGoodbye!")
            break

        if not user_input:
            continue

        handled, result = route_query(user_input)

        if handled:
            print(f"\\nAssistant > {result}\\n")
        else:
            response = generate_response(user_input)
            print(f"\\nAssistant > {response}\\n")


if __name__ == "__main__":
    main()