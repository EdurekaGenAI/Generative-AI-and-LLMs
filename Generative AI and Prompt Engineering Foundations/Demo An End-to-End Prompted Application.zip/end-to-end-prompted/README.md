# End-to-End Prompted Application

## Overview

This project demonstrates how to build an **end-to-end AI application** using the **Groq API** and the **Llama 3.3 70B Versatile** model. Rather than relying on a single prompt, the application uses a sequence of prompts to complete a real-world content generation workflow.

The user provides a topic, and the application guides it through multiple AI-powered stages including article generation, AI review, article refinement, title generation, summarisation, keyword generation, and LinkedIn post creation. This project demonstrates how prompt engineering techniques can be combined to build practical, production-style AI applications.


# Project Structure

```text
end-to-end-prompted-application/
│
├── .env
├── .gitignore
├── README.md
├── requirements.txt
└── main.py
```

---

# Project Workflow

```text
                    +----------------------+
                    |      User Input      |
                    |     Enter Topic      |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |  Generate Article    |
                    |   (Prompt 1)         |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |   Review Article     |
                    |   (Prompt 2)         |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |  Improve Article     |
                    |   (Prompt 3)         |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |   Generate Title     |
                    |   (Prompt 4)         |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Generate Summary     |
                    |   (Prompt 5)         |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |   Generate Tags      |
                    |   (Prompt 6)         |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Generate LinkedIn    |
                    |      Post            |
                    |   (Prompt 7)         |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |   Display Results    |
                    +----------------------+
```