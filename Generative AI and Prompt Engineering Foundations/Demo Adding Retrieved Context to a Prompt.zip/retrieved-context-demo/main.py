import os

from dotenv import load_dotenv
from groq import Groq

# ==========================================================
# Load Environment Variables
# ==========================================================

load_dotenv()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

MODEL = "llama-3.3-70b-versatile"


# ==========================================================
# Load Knowledge Base
# ==========================================================

def load_documents(file_path):
    """
    Load the knowledge base.

    Each paragraph separated by a blank line is treated
    as an individual document.
    """
    with open(file_path, "r", encoding="utf-8") as file:
        return [
            document.strip()
            for document in file.read().split("\n\n")
            if document.strip()
        ]


# ==========================================================
# Retrieve Top-K Context
# ==========================================================

def retrieve_context(question, documents, top_k=3):
    """
    Retrieve the most relevant documents using
    simple keyword matching.
    """

    question_words = set(
        question.lower()
        .replace("?", "")
        .replace(",", "")
        .replace(".", "")
        .split()
    )

    scored_documents = []

    for document in documents:

        document_words = set(
            document.lower()
            .replace(",", "")
            .replace(".", "")
            .split()
        )

        score = len(question_words.intersection(document_words))

        if score > 0:
            scored_documents.append((score, document))

    if not scored_documents:
        return None

    scored_documents.sort(
        key=lambda item: item[0],
        reverse=True
    )

    return "\n\n".join(
        document
        for score, document in scored_documents[:top_k]
    )


# ==========================================================
# Generate Response
# ==========================================================

def generate_response(question, context):

    prompt = f"""
You are a helpful AI assistant.

Answer the user's question ONLY using the retrieved context.

If the answer cannot be found in the retrieved context, reply:

"I couldn't find that information in the retrieved context."

Retrieved Context
=================
{context}

User Question
=============
{question}

Answer:
"""

    response = client.chat.completions.create(
        model=MODEL,
        temperature=0.2,
        max_completion_tokens=500,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response.choices[0].message.content


# ==========================================================
# Display Header
# ==========================================================

def print_header():

    print("=" * 70)
    print("PROMPT ENGINEERING DEMO")
    print("Adding Retrieved Context to a Prompt")
    print("=" * 70)


# ==========================================================
# Main Program
# ==========================================================

def main():

    print_header()

    documents = load_documents("knowledge_base.txt")

    question = input("\nEnter your question: ")

    print("\nSearching the knowledge base...")

    context = retrieve_context(
        question,
        documents
    )

    if context is None:
        print("\nNo relevant context found.")
        return

    print("\nRetrieved Context")
    print("-" * 70)
    print(context)
    print("-" * 70)

    print("\nAdding retrieved context to the prompt...")

    print("\nGenerating response...\n")

    answer = generate_response(
        question,
        context
    )

    print("=" * 70)
    print("AI RESPONSE")
    print("=" * 70)
    print(answer)
    print("=" * 70)


if __name__ == "__main__":
    main()