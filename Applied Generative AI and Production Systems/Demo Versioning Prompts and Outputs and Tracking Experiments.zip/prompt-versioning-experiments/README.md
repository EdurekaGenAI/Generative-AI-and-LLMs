# README.md

# Versioning Prompts and Outputs and Tracking Experiments

## Overview

This project demonstrates how to **version prompts, store generated outputs, and track experiments** in a simple Generative AI workflow.

The project helps you:

* maintain multiple prompt versions,
* generate outputs for each version,
* compare experiment results,
* store metadata such as model name and temperature,
* create a reusable experiment log for future evaluation.

This project is useful for learning **prompt engineering iteration, output comparison, and experiment management** in AI applications.

---

## Project Structure

```text
prompt-versioning-experiments/
├── prompts/
│   ├── v1_prompt.txt
│   └── v2_prompt.txt
├── outputs/
│   └── .gitkeep
├── experiments/
│   └── experiment_log.csv
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

### Folder Description

* **prompts/** → Stores different prompt versions.
* **outputs/** → Stores generated outputs for each experiment.
* **experiments/** → Contains the experiment tracking CSV log.
* **main.py** → Runs experiments and records metadata.
* **requirements.txt** → Lists required Python packages.
* **.gitignore** → Excludes unnecessary files from Git tracking.

---

## Project Workflow

```text
Start
   |
   v
Load Prompt Files
   |
   v
Select Prompt Version
   |
   v
Generate Output
   |
   v
Save Output to outputs/
   |
   v
Record Experiment Details
   |
   v
Append Metadata to experiment_log.csv
   |
   v
Display Experiment Summary
   |
   v
End
```