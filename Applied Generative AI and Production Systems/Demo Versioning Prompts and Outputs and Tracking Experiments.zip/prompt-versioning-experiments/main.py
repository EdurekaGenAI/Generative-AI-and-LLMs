from pathlib import Path
import pandas as pd

# Create folders automatically
Path("outputs").mkdir(exist_ok=True)
Path("experiments").mkdir(exist_ok=True)


def run_experiment(exp_id, prompt_file, output_file):
    # Read prompt
    with open(f"prompts/{prompt_file}", "r", encoding="utf-8") as f:
        prompt = f.read()

    # Fake generated output
    output = f"Generated response for: {prompt.strip()}"

    # Save output
    with open(f"outputs/{output_file}", "w", encoding="utf-8") as f:
        f.write(output)

    # Save experiment log
    log = pd.DataFrame([
        {
            "experiment_id": exp_id,
            "prompt_version": prompt_file,
            "output_file": output_file
        }
    ])

    log_path = "experiments/experiment_log.csv"

    if Path(log_path).exists():
        old = pd.read_csv(log_path)
        log = pd.concat([old, log], ignore_index=True)

    log.to_csv(log_path, index=False)

    # Terminal output
    print(f"Running experiment: {exp_id}")
    print(f"Output saved to outputs/{output_file}")
    print("Experiment logged successfully.\n")


run_experiment("exp_001", "v1_prompt.txt", "v1_output.txt")
run_experiment("exp_002", "v2_prompt.txt", "v2_output.txt")

print("Experiment tracking completed.")