import os
from dotenv import load_dotenv
from groq import Groq

# Load environment variables
load_dotenv()

# Create Groq client
client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

MODEL = "llama-3.3-70b-versatile"


def generate_response(prompt, max_tokens=100, stop=None, top_p=1.0):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        max_tokens=max_tokens,
        stop=stop,
        top_p=top_p,
        temperature=0.8
    )

    return response.choices[0].message.content


# ------------------------------------------------
# MAX TOKENS
# ------------------------------------------------
print("\\n========== MAX TOKENS ==========")

prompt = "Explain artificial intelligence in simple terms."

result = generate_response(prompt, max_tokens=25)
print(result)


# ------------------------------------------------
# STOP SEQUENCE
# ------------------------------------------------
print("\\n========== STOP SEQUENCE ==========")

prompt = """
Create a short shopping list:

Milk
Bread
Eggs
END
Apples
Bananas
"""

result = generate_response(
    prompt,
    max_tokens=100,
    stop=["END"]
)

print(result)


# ------------------------------------------------
# TOP-P COMPARISON
# ------------------------------------------------
print("\\n========== TOP-P COMPARISON ==========")

prompt = "Write a creative slogan for an AI-powered learning platform."

print("\\n--- top_p = 1.0 ---")
print(generate_response(prompt, top_p=1.0))

print("\\n--- top_p = 0.4 ---")
print(generate_response(prompt, top_p=0.4))


# ------------------------------------------------
# COMBINED EXAMPLE
# ------------------------------------------------
print("\\n========== COMBINED CONTROL ==========")

prompt = """
Write 3 benefits of cloud computing.
Keep the answer concise.
END
"""

result = generate_response(
    prompt,
    max_tokens=60,
    stop=["END"],
    top_p=0.6
)

print(result)