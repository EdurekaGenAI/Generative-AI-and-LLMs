import os
from dotenv import load_dotenv

from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage, AIMessage

# Load environment variables
load_dotenv()

# Create Groq LLM instance
llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    temperature=0.7,
    api_key=os.getenv("GROQ_API_KEY")
)

# Conversation memory
conversation_history = []

print("Managing Conversation Memory with LangChain")
print("Type 'exit' to stop.\\n")

while True:
    user_input = input("You: ")

    if user_input.lower() == "exit":
        print("Conversation ended.")
        break

    # Store user message in memory
    conversation_history.append(HumanMessage(content=user_input))

    # Send full conversation history to the model
    response = llm.invoke(conversation_history)

    # Store AI response in memory
    conversation_history.append(AIMessage(content=response.content))

    print(f"AI: {response.content}\\n")