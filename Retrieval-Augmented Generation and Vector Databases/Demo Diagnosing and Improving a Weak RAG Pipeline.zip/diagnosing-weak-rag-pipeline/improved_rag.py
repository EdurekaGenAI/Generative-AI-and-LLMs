from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma


def simple_rerank(query, docs):
    query_words = set(query.lower().split())

    scored = []
    for doc in docs:
        content_words = set(doc.page_content.lower().split())
        score = len(query_words.intersection(content_words))
        scored.append((score, doc))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [doc for score, doc in scored]


def run_improved_pipeline(query):
    loader = TextLoader("knowledge_base.txt")
    documents = loader.load()

    # Better chunking strategy
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=200,
        chunk_overlap=50
    )

    chunks = splitter.split_documents(documents)

    # Add simple metadata
    for chunk in chunks:
        chunk.metadata["topic"] = "RAG"

    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory="chroma_db"
    )

    retriever = vectorstore.as_retriever(search_kwargs={"k": 5})
    retrieved_docs = retriever.invoke(query)

    reranked_docs = simple_rerank(query, retrieved_docs)

    print("\nIMPROVED RAG RESULTS\n")
    for i, doc in enumerate(reranked_docs[:3], 1):
        print(f"Document {i}:")
        print(doc.page_content)
        print("-" * 60)