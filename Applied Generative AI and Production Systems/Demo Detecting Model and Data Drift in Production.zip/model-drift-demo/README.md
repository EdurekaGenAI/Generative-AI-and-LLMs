# Detecting Model and Data Drift in Production

## Overview

This project demonstrates how to detect **data drift** and **model drift** in a production-style machine learning monitoring pipeline using Python.

The system:

- loads historical baseline data,
- loads incoming production data,
- compares feature distributions,
- simulates prediction distributions from two model versions,
- calculates drift scores,
- raises alerts when drift exceeds a threshold.

---

## Project Structure

```text
model-drift-demo/
│
├── data/
│   ├── baseline.csv
│   ├── production.csv
│   └── .gitkeep
│
├── app/
│   ├── main.py
│   ├── data_drift.py
│   ├── model_drift.py
│   └── utils.py
│
├── requirements.txt
├── README.md
└── .gitignore
```

---

## Project Workflow

```text
Start
   |
   v
Load Baseline Data
   |
   v
Load Production Data
   |
   v
Analyse Feature Distributions
   |
   v
Calculate Data Drift Scores
   |
   v
Simulate Baseline Model Predictions
   |
   v
Simulate Current Model Predictions
   |
   v
Calculate Model Drift Score
   |
   v
Check Drift Thresholds
   |
   +---- Yes ----> Raise Drift Alert
   |
   +---- No -----> Continue Monitoring
   |
   v
Generate Monitoring Report
   |
   v
End
```

---

## Example Output

```text
==================================================
DETECTING MODEL AND DATA DRIFT IN PRODUCTION
==================================================

==================================================
STEP 1 - DATA DRIFT ANALYSIS
==================================================

DATA DRIFT REPORT
--------------------------------------------------
Feature: age
Baseline Mean : 35.10
Production Mean: 42.20
Drift Score   : 0.6587
Status        : DRIFT DETECTED
--------------------------------------------------

==================================================
STEP 2 - MODEL DRIFT ANALYSIS
==================================================

MODEL DRIFT REPORT
--------------------------------------------------
Baseline Prediction Mean: 0.4860
Current Prediction Mean : 0.6274
Prediction Drift Score  : 0.1412
Status                  : WARNING
--------------------------------------------------

==================================================
STEP 3 - FINAL MONITORING SUMMARY
==================================================

ALERT: Drift detected in the production environment.
Recommended Action:
 - Review incoming production data
 - Validate model performance metrics
 - Consider retraining the model

Monitoring completed successfully.
```

---