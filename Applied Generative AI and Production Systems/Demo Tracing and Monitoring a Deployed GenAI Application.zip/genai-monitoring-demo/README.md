# Tracing and Monitoring a Deployed GenAI Application

## Overview

This project demonstrates how to trace and monitor a deployed Generative AI application using FastAPI and Python logging.

The application includes:

- API request tracing
- Unique request IDs
- Prompt logging
- Response logging
- Processing time measurement
- Persistent log files
- Health check endpoint

This setup is useful for observability, debugging, performance monitoring, and production support of GenAI applications.


## Project Workflow

```text
                ┌─────────────────────┐
                │   Client Request    │
                └──────────┬──────────┘
                           │
                           ▼
                ┌─────────────────────┐
                │  FastAPI Endpoint   │
                │    /generate        │
                └──────────┬──────────┘
                           │
                           ▼
                ┌─────────────────────┐
                │  Create Request ID  │
                │  Start Trace Timer  │
                └──────────┬──────────┘
                           │
                           ▼
                ┌─────────────────────┐
                │     Log Prompt      │
                │   trace_request()   │
                └──────────┬──────────┘
                           │
                           ▼
                ┌─────────────────────┐
                │   Generate AI       │
                │      Response       │
                └──────────┬──────────┘
                           │
                           ▼
                ┌─────────────────────┐
                │    Log Response     │
                │  trace_response()   │
                └──────────┬──────────┘
                           │
                           ▼
                ┌─────────────────────┐
                │ Calculate Duration  │
                │  Save Logs to File  │
                └──────────┬──────────┘
                           │
                           ▼
                ┌─────────────────────┐
                │  Return JSON API    │
                │      Response       │
                └─────────────────────┘
```

---

## Setup Instructions

### 1. Create a Virtual Environment

```bash
python -m venv venv
```

### 2. Activate the Environment

Windows

```bash
venv\Scripts\activate
```

Linux / macOS

```bash
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

---

## Run the Application

```bash
uvicorn app.main:app --reload
```

Server will run at:

```text
http://127.0.0.1:8000
```

---

## Test the API

### Health Check

```bash
curl http://127.0.0.1:8000/health
```

### Generate Response

```bash
curl -X POST http://127.0.0.1:8000/generate \
-H "Content-Type: application/json" \
-d '{"prompt":"Monitor this GenAI application"}'
```

---

## Example API Response

```json
{
  "request_id": "8a2c4d1f",
  "response": "AI Response: noitacilppa IAneG siht rotinoM",
  "processing_time_seconds": 0.001
}
```

---

## Example Log Output

```text
2026-08-12 10:20:15 | INFO | monitor | TRACE START | request_id=8a2c4d1f
2026-08-12 10:20:15 | INFO | monitor | PROMPT | request_id=8a2c4d1f | Monitor this GenAI application
2026-08-12 10:20:15 | INFO | monitor | RESPONSE | request_id=8a2c4d1f | AI Response: noitacilppa IAneG siht rotinoM
2026-08-12 10:20:15 | INFO | monitor | TRACE END | request_id=8a2c4d1f | duration=0.001s
```

---

## What This Demo Demonstrates

### Tracing

- Correlates each request with a unique request ID
- Tracks the complete lifecycle of a GenAI call

### Monitoring

- Records prompts and responses
- Measures processing latency
- Persists logs for later analysis

### Production Benefits

- Debug failed requests
- Monitor model performance
- Audit API usage
- Support observability pipelines
- Prepare for integration with tools such as OpenTelemetry, Prometheus, Grafana, or Datadog

---

## Expected Output

When the server is running and a request is sent:

- The API returns a JSON response with a request ID and processing time.
- A detailed trace is written to logs/genai_app.log.
- The console displays real-time monitoring information for every request.

This provides a simple but realistic foundation for tracing and monitoring deployed GenAI applications in production environments.