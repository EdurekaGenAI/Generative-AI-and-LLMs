from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import CharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma


def run_weak_pipeline(query):
    loader = TextLoader("knowledge_base.txt")
    documents = loader.load()

    # Poor chunking strategy
    splitter = CharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=0
    )

    chunks = splitter.split_documents(documents)

    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory="chroma_db"
    )

    retriever = vectorstore.as_retriever(search_kwargs={"k": 2})
    results = retriever.invoke(query)

    print("\nWEAK RAG RESULTS\n")
    for i, doc in enumerate(results, 1):
        print(f"Document {i}:")
        print(doc.page_content[:300])
        print("-" * 60)